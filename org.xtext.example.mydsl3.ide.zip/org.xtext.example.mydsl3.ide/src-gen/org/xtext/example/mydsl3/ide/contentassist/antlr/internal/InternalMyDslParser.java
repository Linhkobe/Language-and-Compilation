package org.xtext.example.mydsl3.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import org.xtext.example.mydsl3.services.MyDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalMyDslParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'EQUAL'", "'LESS'", "'LESS_OR_EQUAL'", "'GREATER_OR_EQUAL'", "'GREATER'", "'BAR'", "'LINE'", "'SCATTER'", "'CsvExtract'", "'{'", "'column'", "'}'", "'chart'", "'nameFile'", "','", "'filter'", "'Column'", "'dataType'", "'index'", "'Filter'", "'columnName'", "'rule'", "'value'", "'Chart'", "'chartType'", "'xLabel'", "'yLabel'", "'title'", "'color'", "'variable'", "'-'", "'legend'"
    };
    public static final int RULE_STRING=4;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__37=37;
    public static final int T__16=16;
    public static final int T__38=38;
    public static final int T__17=17;
    public static final int T__39=39;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__33=33;
    public static final int T__12=12;
    public static final int T__34=34;
    public static final int T__13=13;
    public static final int T__35=35;
    public static final int T__14=14;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_ID=5;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__20=20;
    public static final int T__42=42;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalMyDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalMyDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalMyDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalMyDsl.g"; }


    	private MyDslGrammarAccess grammarAccess;

    	public void setGrammarAccess(MyDslGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleCsvExtract"
    // InternalMyDsl.g:53:1: entryRuleCsvExtract : ruleCsvExtract EOF ;
    public final void entryRuleCsvExtract() throws RecognitionException {
        try {
            // InternalMyDsl.g:54:1: ( ruleCsvExtract EOF )
            // InternalMyDsl.g:55:1: ruleCsvExtract EOF
            {
             before(grammarAccess.getCsvExtractRule()); 
            pushFollow(FOLLOW_1);
            ruleCsvExtract();

            state._fsp--;

             after(grammarAccess.getCsvExtractRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCsvExtract"


    // $ANTLR start "ruleCsvExtract"
    // InternalMyDsl.g:62:1: ruleCsvExtract : ( ( rule__CsvExtract__Group__0 ) ) ;
    public final void ruleCsvExtract() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:66:2: ( ( ( rule__CsvExtract__Group__0 ) ) )
            // InternalMyDsl.g:67:2: ( ( rule__CsvExtract__Group__0 ) )
            {
            // InternalMyDsl.g:67:2: ( ( rule__CsvExtract__Group__0 ) )
            // InternalMyDsl.g:68:3: ( rule__CsvExtract__Group__0 )
            {
             before(grammarAccess.getCsvExtractAccess().getGroup()); 
            // InternalMyDsl.g:69:3: ( rule__CsvExtract__Group__0 )
            // InternalMyDsl.g:69:4: rule__CsvExtract__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getCsvExtractAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCsvExtract"


    // $ANTLR start "entryRuleEString"
    // InternalMyDsl.g:78:1: entryRuleEString : ruleEString EOF ;
    public final void entryRuleEString() throws RecognitionException {
        try {
            // InternalMyDsl.g:79:1: ( ruleEString EOF )
            // InternalMyDsl.g:80:1: ruleEString EOF
            {
             before(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getEStringRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalMyDsl.g:87:1: ruleEString : ( ( rule__EString__Alternatives ) ) ;
    public final void ruleEString() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:91:2: ( ( ( rule__EString__Alternatives ) ) )
            // InternalMyDsl.g:92:2: ( ( rule__EString__Alternatives ) )
            {
            // InternalMyDsl.g:92:2: ( ( rule__EString__Alternatives ) )
            // InternalMyDsl.g:93:3: ( rule__EString__Alternatives )
            {
             before(grammarAccess.getEStringAccess().getAlternatives()); 
            // InternalMyDsl.g:94:3: ( rule__EString__Alternatives )
            // InternalMyDsl.g:94:4: rule__EString__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__EString__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getEStringAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEString"


    // $ANTLR start "entryRuleColumn"
    // InternalMyDsl.g:103:1: entryRuleColumn : ruleColumn EOF ;
    public final void entryRuleColumn() throws RecognitionException {
        try {
            // InternalMyDsl.g:104:1: ( ruleColumn EOF )
            // InternalMyDsl.g:105:1: ruleColumn EOF
            {
             before(grammarAccess.getColumnRule()); 
            pushFollow(FOLLOW_1);
            ruleColumn();

            state._fsp--;

             after(grammarAccess.getColumnRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleColumn"


    // $ANTLR start "ruleColumn"
    // InternalMyDsl.g:112:1: ruleColumn : ( ( rule__Column__Group__0 ) ) ;
    public final void ruleColumn() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:116:2: ( ( ( rule__Column__Group__0 ) ) )
            // InternalMyDsl.g:117:2: ( ( rule__Column__Group__0 ) )
            {
            // InternalMyDsl.g:117:2: ( ( rule__Column__Group__0 ) )
            // InternalMyDsl.g:118:3: ( rule__Column__Group__0 )
            {
             before(grammarAccess.getColumnAccess().getGroup()); 
            // InternalMyDsl.g:119:3: ( rule__Column__Group__0 )
            // InternalMyDsl.g:119:4: rule__Column__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Column__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getColumnAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleColumn"


    // $ANTLR start "entryRuleFilter"
    // InternalMyDsl.g:128:1: entryRuleFilter : ruleFilter EOF ;
    public final void entryRuleFilter() throws RecognitionException {
        try {
            // InternalMyDsl.g:129:1: ( ruleFilter EOF )
            // InternalMyDsl.g:130:1: ruleFilter EOF
            {
             before(grammarAccess.getFilterRule()); 
            pushFollow(FOLLOW_1);
            ruleFilter();

            state._fsp--;

             after(grammarAccess.getFilterRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleFilter"


    // $ANTLR start "ruleFilter"
    // InternalMyDsl.g:137:1: ruleFilter : ( ( rule__Filter__Group__0 ) ) ;
    public final void ruleFilter() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:141:2: ( ( ( rule__Filter__Group__0 ) ) )
            // InternalMyDsl.g:142:2: ( ( rule__Filter__Group__0 ) )
            {
            // InternalMyDsl.g:142:2: ( ( rule__Filter__Group__0 ) )
            // InternalMyDsl.g:143:3: ( rule__Filter__Group__0 )
            {
             before(grammarAccess.getFilterAccess().getGroup()); 
            // InternalMyDsl.g:144:3: ( rule__Filter__Group__0 )
            // InternalMyDsl.g:144:4: rule__Filter__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Filter__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getFilterAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleFilter"


    // $ANTLR start "entryRuleChart"
    // InternalMyDsl.g:153:1: entryRuleChart : ruleChart EOF ;
    public final void entryRuleChart() throws RecognitionException {
        try {
            // InternalMyDsl.g:154:1: ( ruleChart EOF )
            // InternalMyDsl.g:155:1: ruleChart EOF
            {
             before(grammarAccess.getChartRule()); 
            pushFollow(FOLLOW_1);
            ruleChart();

            state._fsp--;

             after(grammarAccess.getChartRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleChart"


    // $ANTLR start "ruleChart"
    // InternalMyDsl.g:162:1: ruleChart : ( ( rule__Chart__Group__0 ) ) ;
    public final void ruleChart() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:166:2: ( ( ( rule__Chart__Group__0 ) ) )
            // InternalMyDsl.g:167:2: ( ( rule__Chart__Group__0 ) )
            {
            // InternalMyDsl.g:167:2: ( ( rule__Chart__Group__0 ) )
            // InternalMyDsl.g:168:3: ( rule__Chart__Group__0 )
            {
             before(grammarAccess.getChartAccess().getGroup()); 
            // InternalMyDsl.g:169:3: ( rule__Chart__Group__0 )
            // InternalMyDsl.g:169:4: rule__Chart__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Chart__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getChartAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleChart"


    // $ANTLR start "entryRuleEInt"
    // InternalMyDsl.g:178:1: entryRuleEInt : ruleEInt EOF ;
    public final void entryRuleEInt() throws RecognitionException {
        try {
            // InternalMyDsl.g:179:1: ( ruleEInt EOF )
            // InternalMyDsl.g:180:1: ruleEInt EOF
            {
             before(grammarAccess.getEIntRule()); 
            pushFollow(FOLLOW_1);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getEIntRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEInt"


    // $ANTLR start "ruleEInt"
    // InternalMyDsl.g:187:1: ruleEInt : ( ( rule__EInt__Group__0 ) ) ;
    public final void ruleEInt() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:191:2: ( ( ( rule__EInt__Group__0 ) ) )
            // InternalMyDsl.g:192:2: ( ( rule__EInt__Group__0 ) )
            {
            // InternalMyDsl.g:192:2: ( ( rule__EInt__Group__0 ) )
            // InternalMyDsl.g:193:3: ( rule__EInt__Group__0 )
            {
             before(grammarAccess.getEIntAccess().getGroup()); 
            // InternalMyDsl.g:194:3: ( rule__EInt__Group__0 )
            // InternalMyDsl.g:194:4: rule__EInt__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__EInt__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEIntAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEInt"


    // $ANTLR start "ruleFilterCompOperator"
    // InternalMyDsl.g:203:1: ruleFilterCompOperator : ( ( rule__FilterCompOperator__Alternatives ) ) ;
    public final void ruleFilterCompOperator() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:207:1: ( ( ( rule__FilterCompOperator__Alternatives ) ) )
            // InternalMyDsl.g:208:2: ( ( rule__FilterCompOperator__Alternatives ) )
            {
            // InternalMyDsl.g:208:2: ( ( rule__FilterCompOperator__Alternatives ) )
            // InternalMyDsl.g:209:3: ( rule__FilterCompOperator__Alternatives )
            {
             before(grammarAccess.getFilterCompOperatorAccess().getAlternatives()); 
            // InternalMyDsl.g:210:3: ( rule__FilterCompOperator__Alternatives )
            // InternalMyDsl.g:210:4: rule__FilterCompOperator__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__FilterCompOperator__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getFilterCompOperatorAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleFilterCompOperator"


    // $ANTLR start "ruleChartType"
    // InternalMyDsl.g:219:1: ruleChartType : ( ( rule__ChartType__Alternatives ) ) ;
    public final void ruleChartType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:223:1: ( ( ( rule__ChartType__Alternatives ) ) )
            // InternalMyDsl.g:224:2: ( ( rule__ChartType__Alternatives ) )
            {
            // InternalMyDsl.g:224:2: ( ( rule__ChartType__Alternatives ) )
            // InternalMyDsl.g:225:3: ( rule__ChartType__Alternatives )
            {
             before(grammarAccess.getChartTypeAccess().getAlternatives()); 
            // InternalMyDsl.g:226:3: ( rule__ChartType__Alternatives )
            // InternalMyDsl.g:226:4: rule__ChartType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__ChartType__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getChartTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleChartType"


    // $ANTLR start "rule__EString__Alternatives"
    // InternalMyDsl.g:234:1: rule__EString__Alternatives : ( ( RULE_STRING ) | ( RULE_ID ) );
    public final void rule__EString__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:238:1: ( ( RULE_STRING ) | ( RULE_ID ) )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==RULE_STRING) ) {
                alt1=1;
            }
            else if ( (LA1_0==RULE_ID) ) {
                alt1=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // InternalMyDsl.g:239:2: ( RULE_STRING )
                    {
                    // InternalMyDsl.g:239:2: ( RULE_STRING )
                    // InternalMyDsl.g:240:3: RULE_STRING
                    {
                     before(grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0()); 
                    match(input,RULE_STRING,FOLLOW_2); 
                     after(grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:245:2: ( RULE_ID )
                    {
                    // InternalMyDsl.g:245:2: ( RULE_ID )
                    // InternalMyDsl.g:246:3: RULE_ID
                    {
                     before(grammarAccess.getEStringAccess().getIDTerminalRuleCall_1()); 
                    match(input,RULE_ID,FOLLOW_2); 
                     after(grammarAccess.getEStringAccess().getIDTerminalRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EString__Alternatives"


    // $ANTLR start "rule__FilterCompOperator__Alternatives"
    // InternalMyDsl.g:255:1: rule__FilterCompOperator__Alternatives : ( ( ( 'EQUAL' ) ) | ( ( 'LESS' ) ) | ( ( 'LESS_OR_EQUAL' ) ) | ( ( 'GREATER_OR_EQUAL' ) ) | ( ( 'GREATER' ) ) );
    public final void rule__FilterCompOperator__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:259:1: ( ( ( 'EQUAL' ) ) | ( ( 'LESS' ) ) | ( ( 'LESS_OR_EQUAL' ) ) | ( ( 'GREATER_OR_EQUAL' ) ) | ( ( 'GREATER' ) ) )
            int alt2=5;
            switch ( input.LA(1) ) {
            case 11:
                {
                alt2=1;
                }
                break;
            case 12:
                {
                alt2=2;
                }
                break;
            case 13:
                {
                alt2=3;
                }
                break;
            case 14:
                {
                alt2=4;
                }
                break;
            case 15:
                {
                alt2=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }

            switch (alt2) {
                case 1 :
                    // InternalMyDsl.g:260:2: ( ( 'EQUAL' ) )
                    {
                    // InternalMyDsl.g:260:2: ( ( 'EQUAL' ) )
                    // InternalMyDsl.g:261:3: ( 'EQUAL' )
                    {
                     before(grammarAccess.getFilterCompOperatorAccess().getEQUALEnumLiteralDeclaration_0()); 
                    // InternalMyDsl.g:262:3: ( 'EQUAL' )
                    // InternalMyDsl.g:262:4: 'EQUAL'
                    {
                    match(input,11,FOLLOW_2); 

                    }

                     after(grammarAccess.getFilterCompOperatorAccess().getEQUALEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:266:2: ( ( 'LESS' ) )
                    {
                    // InternalMyDsl.g:266:2: ( ( 'LESS' ) )
                    // InternalMyDsl.g:267:3: ( 'LESS' )
                    {
                     before(grammarAccess.getFilterCompOperatorAccess().getLESSEnumLiteralDeclaration_1()); 
                    // InternalMyDsl.g:268:3: ( 'LESS' )
                    // InternalMyDsl.g:268:4: 'LESS'
                    {
                    match(input,12,FOLLOW_2); 

                    }

                     after(grammarAccess.getFilterCompOperatorAccess().getLESSEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:272:2: ( ( 'LESS_OR_EQUAL' ) )
                    {
                    // InternalMyDsl.g:272:2: ( ( 'LESS_OR_EQUAL' ) )
                    // InternalMyDsl.g:273:3: ( 'LESS_OR_EQUAL' )
                    {
                     before(grammarAccess.getFilterCompOperatorAccess().getLESS_OR_EQUALEnumLiteralDeclaration_2()); 
                    // InternalMyDsl.g:274:3: ( 'LESS_OR_EQUAL' )
                    // InternalMyDsl.g:274:4: 'LESS_OR_EQUAL'
                    {
                    match(input,13,FOLLOW_2); 

                    }

                     after(grammarAccess.getFilterCompOperatorAccess().getLESS_OR_EQUALEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalMyDsl.g:278:2: ( ( 'GREATER_OR_EQUAL' ) )
                    {
                    // InternalMyDsl.g:278:2: ( ( 'GREATER_OR_EQUAL' ) )
                    // InternalMyDsl.g:279:3: ( 'GREATER_OR_EQUAL' )
                    {
                     before(grammarAccess.getFilterCompOperatorAccess().getGREATER_OR_EQUALEnumLiteralDeclaration_3()); 
                    // InternalMyDsl.g:280:3: ( 'GREATER_OR_EQUAL' )
                    // InternalMyDsl.g:280:4: 'GREATER_OR_EQUAL'
                    {
                    match(input,14,FOLLOW_2); 

                    }

                     after(grammarAccess.getFilterCompOperatorAccess().getGREATER_OR_EQUALEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalMyDsl.g:284:2: ( ( 'GREATER' ) )
                    {
                    // InternalMyDsl.g:284:2: ( ( 'GREATER' ) )
                    // InternalMyDsl.g:285:3: ( 'GREATER' )
                    {
                     before(grammarAccess.getFilterCompOperatorAccess().getGREATEREnumLiteralDeclaration_4()); 
                    // InternalMyDsl.g:286:3: ( 'GREATER' )
                    // InternalMyDsl.g:286:4: 'GREATER'
                    {
                    match(input,15,FOLLOW_2); 

                    }

                     after(grammarAccess.getFilterCompOperatorAccess().getGREATEREnumLiteralDeclaration_4()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FilterCompOperator__Alternatives"


    // $ANTLR start "rule__ChartType__Alternatives"
    // InternalMyDsl.g:294:1: rule__ChartType__Alternatives : ( ( ( 'BAR' ) ) | ( ( 'LINE' ) ) | ( ( 'SCATTER' ) ) );
    public final void rule__ChartType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:298:1: ( ( ( 'BAR' ) ) | ( ( 'LINE' ) ) | ( ( 'SCATTER' ) ) )
            int alt3=3;
            switch ( input.LA(1) ) {
            case 16:
                {
                alt3=1;
                }
                break;
            case 17:
                {
                alt3=2;
                }
                break;
            case 18:
                {
                alt3=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }

            switch (alt3) {
                case 1 :
                    // InternalMyDsl.g:299:2: ( ( 'BAR' ) )
                    {
                    // InternalMyDsl.g:299:2: ( ( 'BAR' ) )
                    // InternalMyDsl.g:300:3: ( 'BAR' )
                    {
                     before(grammarAccess.getChartTypeAccess().getBAREnumLiteralDeclaration_0()); 
                    // InternalMyDsl.g:301:3: ( 'BAR' )
                    // InternalMyDsl.g:301:4: 'BAR'
                    {
                    match(input,16,FOLLOW_2); 

                    }

                     after(grammarAccess.getChartTypeAccess().getBAREnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:305:2: ( ( 'LINE' ) )
                    {
                    // InternalMyDsl.g:305:2: ( ( 'LINE' ) )
                    // InternalMyDsl.g:306:3: ( 'LINE' )
                    {
                     before(grammarAccess.getChartTypeAccess().getLINEEnumLiteralDeclaration_1()); 
                    // InternalMyDsl.g:307:3: ( 'LINE' )
                    // InternalMyDsl.g:307:4: 'LINE'
                    {
                    match(input,17,FOLLOW_2); 

                    }

                     after(grammarAccess.getChartTypeAccess().getLINEEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:311:2: ( ( 'SCATTER' ) )
                    {
                    // InternalMyDsl.g:311:2: ( ( 'SCATTER' ) )
                    // InternalMyDsl.g:312:3: ( 'SCATTER' )
                    {
                     before(grammarAccess.getChartTypeAccess().getSCATTEREnumLiteralDeclaration_2()); 
                    // InternalMyDsl.g:313:3: ( 'SCATTER' )
                    // InternalMyDsl.g:313:4: 'SCATTER'
                    {
                    match(input,18,FOLLOW_2); 

                    }

                     after(grammarAccess.getChartTypeAccess().getSCATTEREnumLiteralDeclaration_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ChartType__Alternatives"


    // $ANTLR start "rule__CsvExtract__Group__0"
    // InternalMyDsl.g:321:1: rule__CsvExtract__Group__0 : rule__CsvExtract__Group__0__Impl rule__CsvExtract__Group__1 ;
    public final void rule__CsvExtract__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:325:1: ( rule__CsvExtract__Group__0__Impl rule__CsvExtract__Group__1 )
            // InternalMyDsl.g:326:2: rule__CsvExtract__Group__0__Impl rule__CsvExtract__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__CsvExtract__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__0"


    // $ANTLR start "rule__CsvExtract__Group__0__Impl"
    // InternalMyDsl.g:333:1: rule__CsvExtract__Group__0__Impl : ( 'CsvExtract' ) ;
    public final void rule__CsvExtract__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:337:1: ( ( 'CsvExtract' ) )
            // InternalMyDsl.g:338:1: ( 'CsvExtract' )
            {
            // InternalMyDsl.g:338:1: ( 'CsvExtract' )
            // InternalMyDsl.g:339:2: 'CsvExtract'
            {
             before(grammarAccess.getCsvExtractAccess().getCsvExtractKeyword_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getCsvExtractAccess().getCsvExtractKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__0__Impl"


    // $ANTLR start "rule__CsvExtract__Group__1"
    // InternalMyDsl.g:348:1: rule__CsvExtract__Group__1 : rule__CsvExtract__Group__1__Impl rule__CsvExtract__Group__2 ;
    public final void rule__CsvExtract__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:352:1: ( rule__CsvExtract__Group__1__Impl rule__CsvExtract__Group__2 )
            // InternalMyDsl.g:353:2: rule__CsvExtract__Group__1__Impl rule__CsvExtract__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__CsvExtract__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__1"


    // $ANTLR start "rule__CsvExtract__Group__1__Impl"
    // InternalMyDsl.g:360:1: rule__CsvExtract__Group__1__Impl : ( '{' ) ;
    public final void rule__CsvExtract__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:364:1: ( ( '{' ) )
            // InternalMyDsl.g:365:1: ( '{' )
            {
            // InternalMyDsl.g:365:1: ( '{' )
            // InternalMyDsl.g:366:2: '{'
            {
             before(grammarAccess.getCsvExtractAccess().getLeftCurlyBracketKeyword_1()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getCsvExtractAccess().getLeftCurlyBracketKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__1__Impl"


    // $ANTLR start "rule__CsvExtract__Group__2"
    // InternalMyDsl.g:375:1: rule__CsvExtract__Group__2 : rule__CsvExtract__Group__2__Impl rule__CsvExtract__Group__3 ;
    public final void rule__CsvExtract__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:379:1: ( rule__CsvExtract__Group__2__Impl rule__CsvExtract__Group__3 )
            // InternalMyDsl.g:380:2: rule__CsvExtract__Group__2__Impl rule__CsvExtract__Group__3
            {
            pushFollow(FOLLOW_4);
            rule__CsvExtract__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__2"


    // $ANTLR start "rule__CsvExtract__Group__2__Impl"
    // InternalMyDsl.g:387:1: rule__CsvExtract__Group__2__Impl : ( ( rule__CsvExtract__Group_2__0 )? ) ;
    public final void rule__CsvExtract__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:391:1: ( ( ( rule__CsvExtract__Group_2__0 )? ) )
            // InternalMyDsl.g:392:1: ( ( rule__CsvExtract__Group_2__0 )? )
            {
            // InternalMyDsl.g:392:1: ( ( rule__CsvExtract__Group_2__0 )? )
            // InternalMyDsl.g:393:2: ( rule__CsvExtract__Group_2__0 )?
            {
             before(grammarAccess.getCsvExtractAccess().getGroup_2()); 
            // InternalMyDsl.g:394:2: ( rule__CsvExtract__Group_2__0 )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==24) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // InternalMyDsl.g:394:3: rule__CsvExtract__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__CsvExtract__Group_2__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getCsvExtractAccess().getGroup_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__2__Impl"


    // $ANTLR start "rule__CsvExtract__Group__3"
    // InternalMyDsl.g:402:1: rule__CsvExtract__Group__3 : rule__CsvExtract__Group__3__Impl rule__CsvExtract__Group__4 ;
    public final void rule__CsvExtract__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:406:1: ( rule__CsvExtract__Group__3__Impl rule__CsvExtract__Group__4 )
            // InternalMyDsl.g:407:2: rule__CsvExtract__Group__3__Impl rule__CsvExtract__Group__4
            {
            pushFollow(FOLLOW_3);
            rule__CsvExtract__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__3"


    // $ANTLR start "rule__CsvExtract__Group__3__Impl"
    // InternalMyDsl.g:414:1: rule__CsvExtract__Group__3__Impl : ( 'column' ) ;
    public final void rule__CsvExtract__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:418:1: ( ( 'column' ) )
            // InternalMyDsl.g:419:1: ( 'column' )
            {
            // InternalMyDsl.g:419:1: ( 'column' )
            // InternalMyDsl.g:420:2: 'column'
            {
             before(grammarAccess.getCsvExtractAccess().getColumnKeyword_3()); 
            match(input,21,FOLLOW_2); 
             after(grammarAccess.getCsvExtractAccess().getColumnKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__3__Impl"


    // $ANTLR start "rule__CsvExtract__Group__4"
    // InternalMyDsl.g:429:1: rule__CsvExtract__Group__4 : rule__CsvExtract__Group__4__Impl rule__CsvExtract__Group__5 ;
    public final void rule__CsvExtract__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:433:1: ( rule__CsvExtract__Group__4__Impl rule__CsvExtract__Group__5 )
            // InternalMyDsl.g:434:2: rule__CsvExtract__Group__4__Impl rule__CsvExtract__Group__5
            {
            pushFollow(FOLLOW_5);
            rule__CsvExtract__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__4"


    // $ANTLR start "rule__CsvExtract__Group__4__Impl"
    // InternalMyDsl.g:441:1: rule__CsvExtract__Group__4__Impl : ( '{' ) ;
    public final void rule__CsvExtract__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:445:1: ( ( '{' ) )
            // InternalMyDsl.g:446:1: ( '{' )
            {
            // InternalMyDsl.g:446:1: ( '{' )
            // InternalMyDsl.g:447:2: '{'
            {
             before(grammarAccess.getCsvExtractAccess().getLeftCurlyBracketKeyword_4()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getCsvExtractAccess().getLeftCurlyBracketKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__4__Impl"


    // $ANTLR start "rule__CsvExtract__Group__5"
    // InternalMyDsl.g:456:1: rule__CsvExtract__Group__5 : rule__CsvExtract__Group__5__Impl rule__CsvExtract__Group__6 ;
    public final void rule__CsvExtract__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:460:1: ( rule__CsvExtract__Group__5__Impl rule__CsvExtract__Group__6 )
            // InternalMyDsl.g:461:2: rule__CsvExtract__Group__5__Impl rule__CsvExtract__Group__6
            {
            pushFollow(FOLLOW_6);
            rule__CsvExtract__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__5"


    // $ANTLR start "rule__CsvExtract__Group__5__Impl"
    // InternalMyDsl.g:468:1: rule__CsvExtract__Group__5__Impl : ( ( rule__CsvExtract__ColumnAssignment_5 ) ) ;
    public final void rule__CsvExtract__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:472:1: ( ( ( rule__CsvExtract__ColumnAssignment_5 ) ) )
            // InternalMyDsl.g:473:1: ( ( rule__CsvExtract__ColumnAssignment_5 ) )
            {
            // InternalMyDsl.g:473:1: ( ( rule__CsvExtract__ColumnAssignment_5 ) )
            // InternalMyDsl.g:474:2: ( rule__CsvExtract__ColumnAssignment_5 )
            {
             before(grammarAccess.getCsvExtractAccess().getColumnAssignment_5()); 
            // InternalMyDsl.g:475:2: ( rule__CsvExtract__ColumnAssignment_5 )
            // InternalMyDsl.g:475:3: rule__CsvExtract__ColumnAssignment_5
            {
            pushFollow(FOLLOW_2);
            rule__CsvExtract__ColumnAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getCsvExtractAccess().getColumnAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__5__Impl"


    // $ANTLR start "rule__CsvExtract__Group__6"
    // InternalMyDsl.g:483:1: rule__CsvExtract__Group__6 : rule__CsvExtract__Group__6__Impl rule__CsvExtract__Group__7 ;
    public final void rule__CsvExtract__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:487:1: ( rule__CsvExtract__Group__6__Impl rule__CsvExtract__Group__7 )
            // InternalMyDsl.g:488:2: rule__CsvExtract__Group__6__Impl rule__CsvExtract__Group__7
            {
            pushFollow(FOLLOW_6);
            rule__CsvExtract__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__6"


    // $ANTLR start "rule__CsvExtract__Group__6__Impl"
    // InternalMyDsl.g:495:1: rule__CsvExtract__Group__6__Impl : ( ( rule__CsvExtract__Group_6__0 )* ) ;
    public final void rule__CsvExtract__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:499:1: ( ( ( rule__CsvExtract__Group_6__0 )* ) )
            // InternalMyDsl.g:500:1: ( ( rule__CsvExtract__Group_6__0 )* )
            {
            // InternalMyDsl.g:500:1: ( ( rule__CsvExtract__Group_6__0 )* )
            // InternalMyDsl.g:501:2: ( rule__CsvExtract__Group_6__0 )*
            {
             before(grammarAccess.getCsvExtractAccess().getGroup_6()); 
            // InternalMyDsl.g:502:2: ( rule__CsvExtract__Group_6__0 )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==25) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // InternalMyDsl.g:502:3: rule__CsvExtract__Group_6__0
            	    {
            	    pushFollow(FOLLOW_7);
            	    rule__CsvExtract__Group_6__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

             after(grammarAccess.getCsvExtractAccess().getGroup_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__6__Impl"


    // $ANTLR start "rule__CsvExtract__Group__7"
    // InternalMyDsl.g:510:1: rule__CsvExtract__Group__7 : rule__CsvExtract__Group__7__Impl rule__CsvExtract__Group__8 ;
    public final void rule__CsvExtract__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:514:1: ( rule__CsvExtract__Group__7__Impl rule__CsvExtract__Group__8 )
            // InternalMyDsl.g:515:2: rule__CsvExtract__Group__7__Impl rule__CsvExtract__Group__8
            {
            pushFollow(FOLLOW_8);
            rule__CsvExtract__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__7"


    // $ANTLR start "rule__CsvExtract__Group__7__Impl"
    // InternalMyDsl.g:522:1: rule__CsvExtract__Group__7__Impl : ( '}' ) ;
    public final void rule__CsvExtract__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:526:1: ( ( '}' ) )
            // InternalMyDsl.g:527:1: ( '}' )
            {
            // InternalMyDsl.g:527:1: ( '}' )
            // InternalMyDsl.g:528:2: '}'
            {
             before(grammarAccess.getCsvExtractAccess().getRightCurlyBracketKeyword_7()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getCsvExtractAccess().getRightCurlyBracketKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__7__Impl"


    // $ANTLR start "rule__CsvExtract__Group__8"
    // InternalMyDsl.g:537:1: rule__CsvExtract__Group__8 : rule__CsvExtract__Group__8__Impl rule__CsvExtract__Group__9 ;
    public final void rule__CsvExtract__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:541:1: ( rule__CsvExtract__Group__8__Impl rule__CsvExtract__Group__9 )
            // InternalMyDsl.g:542:2: rule__CsvExtract__Group__8__Impl rule__CsvExtract__Group__9
            {
            pushFollow(FOLLOW_8);
            rule__CsvExtract__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__8"


    // $ANTLR start "rule__CsvExtract__Group__8__Impl"
    // InternalMyDsl.g:549:1: rule__CsvExtract__Group__8__Impl : ( ( rule__CsvExtract__Group_8__0 )? ) ;
    public final void rule__CsvExtract__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:553:1: ( ( ( rule__CsvExtract__Group_8__0 )? ) )
            // InternalMyDsl.g:554:1: ( ( rule__CsvExtract__Group_8__0 )? )
            {
            // InternalMyDsl.g:554:1: ( ( rule__CsvExtract__Group_8__0 )? )
            // InternalMyDsl.g:555:2: ( rule__CsvExtract__Group_8__0 )?
            {
             before(grammarAccess.getCsvExtractAccess().getGroup_8()); 
            // InternalMyDsl.g:556:2: ( rule__CsvExtract__Group_8__0 )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==26) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // InternalMyDsl.g:556:3: rule__CsvExtract__Group_8__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__CsvExtract__Group_8__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getCsvExtractAccess().getGroup_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__8__Impl"


    // $ANTLR start "rule__CsvExtract__Group__9"
    // InternalMyDsl.g:564:1: rule__CsvExtract__Group__9 : rule__CsvExtract__Group__9__Impl rule__CsvExtract__Group__10 ;
    public final void rule__CsvExtract__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:568:1: ( rule__CsvExtract__Group__9__Impl rule__CsvExtract__Group__10 )
            // InternalMyDsl.g:569:2: rule__CsvExtract__Group__9__Impl rule__CsvExtract__Group__10
            {
            pushFollow(FOLLOW_3);
            rule__CsvExtract__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__9"


    // $ANTLR start "rule__CsvExtract__Group__9__Impl"
    // InternalMyDsl.g:576:1: rule__CsvExtract__Group__9__Impl : ( 'chart' ) ;
    public final void rule__CsvExtract__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:580:1: ( ( 'chart' ) )
            // InternalMyDsl.g:581:1: ( 'chart' )
            {
            // InternalMyDsl.g:581:1: ( 'chart' )
            // InternalMyDsl.g:582:2: 'chart'
            {
             before(grammarAccess.getCsvExtractAccess().getChartKeyword_9()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getCsvExtractAccess().getChartKeyword_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__9__Impl"


    // $ANTLR start "rule__CsvExtract__Group__10"
    // InternalMyDsl.g:591:1: rule__CsvExtract__Group__10 : rule__CsvExtract__Group__10__Impl rule__CsvExtract__Group__11 ;
    public final void rule__CsvExtract__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:595:1: ( rule__CsvExtract__Group__10__Impl rule__CsvExtract__Group__11 )
            // InternalMyDsl.g:596:2: rule__CsvExtract__Group__10__Impl rule__CsvExtract__Group__11
            {
            pushFollow(FOLLOW_9);
            rule__CsvExtract__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__10"


    // $ANTLR start "rule__CsvExtract__Group__10__Impl"
    // InternalMyDsl.g:603:1: rule__CsvExtract__Group__10__Impl : ( '{' ) ;
    public final void rule__CsvExtract__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:607:1: ( ( '{' ) )
            // InternalMyDsl.g:608:1: ( '{' )
            {
            // InternalMyDsl.g:608:1: ( '{' )
            // InternalMyDsl.g:609:2: '{'
            {
             before(grammarAccess.getCsvExtractAccess().getLeftCurlyBracketKeyword_10()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getCsvExtractAccess().getLeftCurlyBracketKeyword_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__10__Impl"


    // $ANTLR start "rule__CsvExtract__Group__11"
    // InternalMyDsl.g:618:1: rule__CsvExtract__Group__11 : rule__CsvExtract__Group__11__Impl rule__CsvExtract__Group__12 ;
    public final void rule__CsvExtract__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:622:1: ( rule__CsvExtract__Group__11__Impl rule__CsvExtract__Group__12 )
            // InternalMyDsl.g:623:2: rule__CsvExtract__Group__11__Impl rule__CsvExtract__Group__12
            {
            pushFollow(FOLLOW_6);
            rule__CsvExtract__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__11"


    // $ANTLR start "rule__CsvExtract__Group__11__Impl"
    // InternalMyDsl.g:630:1: rule__CsvExtract__Group__11__Impl : ( ( rule__CsvExtract__ChartAssignment_11 ) ) ;
    public final void rule__CsvExtract__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:634:1: ( ( ( rule__CsvExtract__ChartAssignment_11 ) ) )
            // InternalMyDsl.g:635:1: ( ( rule__CsvExtract__ChartAssignment_11 ) )
            {
            // InternalMyDsl.g:635:1: ( ( rule__CsvExtract__ChartAssignment_11 ) )
            // InternalMyDsl.g:636:2: ( rule__CsvExtract__ChartAssignment_11 )
            {
             before(grammarAccess.getCsvExtractAccess().getChartAssignment_11()); 
            // InternalMyDsl.g:637:2: ( rule__CsvExtract__ChartAssignment_11 )
            // InternalMyDsl.g:637:3: rule__CsvExtract__ChartAssignment_11
            {
            pushFollow(FOLLOW_2);
            rule__CsvExtract__ChartAssignment_11();

            state._fsp--;


            }

             after(grammarAccess.getCsvExtractAccess().getChartAssignment_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__11__Impl"


    // $ANTLR start "rule__CsvExtract__Group__12"
    // InternalMyDsl.g:645:1: rule__CsvExtract__Group__12 : rule__CsvExtract__Group__12__Impl rule__CsvExtract__Group__13 ;
    public final void rule__CsvExtract__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:649:1: ( rule__CsvExtract__Group__12__Impl rule__CsvExtract__Group__13 )
            // InternalMyDsl.g:650:2: rule__CsvExtract__Group__12__Impl rule__CsvExtract__Group__13
            {
            pushFollow(FOLLOW_6);
            rule__CsvExtract__Group__12__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group__13();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__12"


    // $ANTLR start "rule__CsvExtract__Group__12__Impl"
    // InternalMyDsl.g:657:1: rule__CsvExtract__Group__12__Impl : ( ( rule__CsvExtract__Group_12__0 )* ) ;
    public final void rule__CsvExtract__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:661:1: ( ( ( rule__CsvExtract__Group_12__0 )* ) )
            // InternalMyDsl.g:662:1: ( ( rule__CsvExtract__Group_12__0 )* )
            {
            // InternalMyDsl.g:662:1: ( ( rule__CsvExtract__Group_12__0 )* )
            // InternalMyDsl.g:663:2: ( rule__CsvExtract__Group_12__0 )*
            {
             before(grammarAccess.getCsvExtractAccess().getGroup_12()); 
            // InternalMyDsl.g:664:2: ( rule__CsvExtract__Group_12__0 )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==25) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // InternalMyDsl.g:664:3: rule__CsvExtract__Group_12__0
            	    {
            	    pushFollow(FOLLOW_7);
            	    rule__CsvExtract__Group_12__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);

             after(grammarAccess.getCsvExtractAccess().getGroup_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__12__Impl"


    // $ANTLR start "rule__CsvExtract__Group__13"
    // InternalMyDsl.g:672:1: rule__CsvExtract__Group__13 : rule__CsvExtract__Group__13__Impl rule__CsvExtract__Group__14 ;
    public final void rule__CsvExtract__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:676:1: ( rule__CsvExtract__Group__13__Impl rule__CsvExtract__Group__14 )
            // InternalMyDsl.g:677:2: rule__CsvExtract__Group__13__Impl rule__CsvExtract__Group__14
            {
            pushFollow(FOLLOW_10);
            rule__CsvExtract__Group__13__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group__14();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__13"


    // $ANTLR start "rule__CsvExtract__Group__13__Impl"
    // InternalMyDsl.g:684:1: rule__CsvExtract__Group__13__Impl : ( '}' ) ;
    public final void rule__CsvExtract__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:688:1: ( ( '}' ) )
            // InternalMyDsl.g:689:1: ( '}' )
            {
            // InternalMyDsl.g:689:1: ( '}' )
            // InternalMyDsl.g:690:2: '}'
            {
             before(grammarAccess.getCsvExtractAccess().getRightCurlyBracketKeyword_13()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getCsvExtractAccess().getRightCurlyBracketKeyword_13()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__13__Impl"


    // $ANTLR start "rule__CsvExtract__Group__14"
    // InternalMyDsl.g:699:1: rule__CsvExtract__Group__14 : rule__CsvExtract__Group__14__Impl ;
    public final void rule__CsvExtract__Group__14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:703:1: ( rule__CsvExtract__Group__14__Impl )
            // InternalMyDsl.g:704:2: rule__CsvExtract__Group__14__Impl
            {
            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group__14__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__14"


    // $ANTLR start "rule__CsvExtract__Group__14__Impl"
    // InternalMyDsl.g:710:1: rule__CsvExtract__Group__14__Impl : ( '}' ) ;
    public final void rule__CsvExtract__Group__14__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:714:1: ( ( '}' ) )
            // InternalMyDsl.g:715:1: ( '}' )
            {
            // InternalMyDsl.g:715:1: ( '}' )
            // InternalMyDsl.g:716:2: '}'
            {
             before(grammarAccess.getCsvExtractAccess().getRightCurlyBracketKeyword_14()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getCsvExtractAccess().getRightCurlyBracketKeyword_14()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group__14__Impl"


    // $ANTLR start "rule__CsvExtract__Group_2__0"
    // InternalMyDsl.g:726:1: rule__CsvExtract__Group_2__0 : rule__CsvExtract__Group_2__0__Impl rule__CsvExtract__Group_2__1 ;
    public final void rule__CsvExtract__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:730:1: ( rule__CsvExtract__Group_2__0__Impl rule__CsvExtract__Group_2__1 )
            // InternalMyDsl.g:731:2: rule__CsvExtract__Group_2__0__Impl rule__CsvExtract__Group_2__1
            {
            pushFollow(FOLLOW_11);
            rule__CsvExtract__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group_2__0"


    // $ANTLR start "rule__CsvExtract__Group_2__0__Impl"
    // InternalMyDsl.g:738:1: rule__CsvExtract__Group_2__0__Impl : ( 'nameFile' ) ;
    public final void rule__CsvExtract__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:742:1: ( ( 'nameFile' ) )
            // InternalMyDsl.g:743:1: ( 'nameFile' )
            {
            // InternalMyDsl.g:743:1: ( 'nameFile' )
            // InternalMyDsl.g:744:2: 'nameFile'
            {
             before(grammarAccess.getCsvExtractAccess().getNameFileKeyword_2_0()); 
            match(input,24,FOLLOW_2); 
             after(grammarAccess.getCsvExtractAccess().getNameFileKeyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group_2__0__Impl"


    // $ANTLR start "rule__CsvExtract__Group_2__1"
    // InternalMyDsl.g:753:1: rule__CsvExtract__Group_2__1 : rule__CsvExtract__Group_2__1__Impl ;
    public final void rule__CsvExtract__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:757:1: ( rule__CsvExtract__Group_2__1__Impl )
            // InternalMyDsl.g:758:2: rule__CsvExtract__Group_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group_2__1"


    // $ANTLR start "rule__CsvExtract__Group_2__1__Impl"
    // InternalMyDsl.g:764:1: rule__CsvExtract__Group_2__1__Impl : ( ( rule__CsvExtract__NameFileAssignment_2_1 ) ) ;
    public final void rule__CsvExtract__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:768:1: ( ( ( rule__CsvExtract__NameFileAssignment_2_1 ) ) )
            // InternalMyDsl.g:769:1: ( ( rule__CsvExtract__NameFileAssignment_2_1 ) )
            {
            // InternalMyDsl.g:769:1: ( ( rule__CsvExtract__NameFileAssignment_2_1 ) )
            // InternalMyDsl.g:770:2: ( rule__CsvExtract__NameFileAssignment_2_1 )
            {
             before(grammarAccess.getCsvExtractAccess().getNameFileAssignment_2_1()); 
            // InternalMyDsl.g:771:2: ( rule__CsvExtract__NameFileAssignment_2_1 )
            // InternalMyDsl.g:771:3: rule__CsvExtract__NameFileAssignment_2_1
            {
            pushFollow(FOLLOW_2);
            rule__CsvExtract__NameFileAssignment_2_1();

            state._fsp--;


            }

             after(grammarAccess.getCsvExtractAccess().getNameFileAssignment_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group_2__1__Impl"


    // $ANTLR start "rule__CsvExtract__Group_6__0"
    // InternalMyDsl.g:780:1: rule__CsvExtract__Group_6__0 : rule__CsvExtract__Group_6__0__Impl rule__CsvExtract__Group_6__1 ;
    public final void rule__CsvExtract__Group_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:784:1: ( rule__CsvExtract__Group_6__0__Impl rule__CsvExtract__Group_6__1 )
            // InternalMyDsl.g:785:2: rule__CsvExtract__Group_6__0__Impl rule__CsvExtract__Group_6__1
            {
            pushFollow(FOLLOW_5);
            rule__CsvExtract__Group_6__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group_6__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group_6__0"


    // $ANTLR start "rule__CsvExtract__Group_6__0__Impl"
    // InternalMyDsl.g:792:1: rule__CsvExtract__Group_6__0__Impl : ( ',' ) ;
    public final void rule__CsvExtract__Group_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:796:1: ( ( ',' ) )
            // InternalMyDsl.g:797:1: ( ',' )
            {
            // InternalMyDsl.g:797:1: ( ',' )
            // InternalMyDsl.g:798:2: ','
            {
             before(grammarAccess.getCsvExtractAccess().getCommaKeyword_6_0()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getCsvExtractAccess().getCommaKeyword_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group_6__0__Impl"


    // $ANTLR start "rule__CsvExtract__Group_6__1"
    // InternalMyDsl.g:807:1: rule__CsvExtract__Group_6__1 : rule__CsvExtract__Group_6__1__Impl ;
    public final void rule__CsvExtract__Group_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:811:1: ( rule__CsvExtract__Group_6__1__Impl )
            // InternalMyDsl.g:812:2: rule__CsvExtract__Group_6__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group_6__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group_6__1"


    // $ANTLR start "rule__CsvExtract__Group_6__1__Impl"
    // InternalMyDsl.g:818:1: rule__CsvExtract__Group_6__1__Impl : ( ( rule__CsvExtract__ColumnAssignment_6_1 ) ) ;
    public final void rule__CsvExtract__Group_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:822:1: ( ( ( rule__CsvExtract__ColumnAssignment_6_1 ) ) )
            // InternalMyDsl.g:823:1: ( ( rule__CsvExtract__ColumnAssignment_6_1 ) )
            {
            // InternalMyDsl.g:823:1: ( ( rule__CsvExtract__ColumnAssignment_6_1 ) )
            // InternalMyDsl.g:824:2: ( rule__CsvExtract__ColumnAssignment_6_1 )
            {
             before(grammarAccess.getCsvExtractAccess().getColumnAssignment_6_1()); 
            // InternalMyDsl.g:825:2: ( rule__CsvExtract__ColumnAssignment_6_1 )
            // InternalMyDsl.g:825:3: rule__CsvExtract__ColumnAssignment_6_1
            {
            pushFollow(FOLLOW_2);
            rule__CsvExtract__ColumnAssignment_6_1();

            state._fsp--;


            }

             after(grammarAccess.getCsvExtractAccess().getColumnAssignment_6_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group_6__1__Impl"


    // $ANTLR start "rule__CsvExtract__Group_8__0"
    // InternalMyDsl.g:834:1: rule__CsvExtract__Group_8__0 : rule__CsvExtract__Group_8__0__Impl rule__CsvExtract__Group_8__1 ;
    public final void rule__CsvExtract__Group_8__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:838:1: ( rule__CsvExtract__Group_8__0__Impl rule__CsvExtract__Group_8__1 )
            // InternalMyDsl.g:839:2: rule__CsvExtract__Group_8__0__Impl rule__CsvExtract__Group_8__1
            {
            pushFollow(FOLLOW_3);
            rule__CsvExtract__Group_8__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group_8__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group_8__0"


    // $ANTLR start "rule__CsvExtract__Group_8__0__Impl"
    // InternalMyDsl.g:846:1: rule__CsvExtract__Group_8__0__Impl : ( 'filter' ) ;
    public final void rule__CsvExtract__Group_8__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:850:1: ( ( 'filter' ) )
            // InternalMyDsl.g:851:1: ( 'filter' )
            {
            // InternalMyDsl.g:851:1: ( 'filter' )
            // InternalMyDsl.g:852:2: 'filter'
            {
             before(grammarAccess.getCsvExtractAccess().getFilterKeyword_8_0()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getCsvExtractAccess().getFilterKeyword_8_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group_8__0__Impl"


    // $ANTLR start "rule__CsvExtract__Group_8__1"
    // InternalMyDsl.g:861:1: rule__CsvExtract__Group_8__1 : rule__CsvExtract__Group_8__1__Impl rule__CsvExtract__Group_8__2 ;
    public final void rule__CsvExtract__Group_8__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:865:1: ( rule__CsvExtract__Group_8__1__Impl rule__CsvExtract__Group_8__2 )
            // InternalMyDsl.g:866:2: rule__CsvExtract__Group_8__1__Impl rule__CsvExtract__Group_8__2
            {
            pushFollow(FOLLOW_12);
            rule__CsvExtract__Group_8__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group_8__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group_8__1"


    // $ANTLR start "rule__CsvExtract__Group_8__1__Impl"
    // InternalMyDsl.g:873:1: rule__CsvExtract__Group_8__1__Impl : ( '{' ) ;
    public final void rule__CsvExtract__Group_8__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:877:1: ( ( '{' ) )
            // InternalMyDsl.g:878:1: ( '{' )
            {
            // InternalMyDsl.g:878:1: ( '{' )
            // InternalMyDsl.g:879:2: '{'
            {
             before(grammarAccess.getCsvExtractAccess().getLeftCurlyBracketKeyword_8_1()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getCsvExtractAccess().getLeftCurlyBracketKeyword_8_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group_8__1__Impl"


    // $ANTLR start "rule__CsvExtract__Group_8__2"
    // InternalMyDsl.g:888:1: rule__CsvExtract__Group_8__2 : rule__CsvExtract__Group_8__2__Impl rule__CsvExtract__Group_8__3 ;
    public final void rule__CsvExtract__Group_8__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:892:1: ( rule__CsvExtract__Group_8__2__Impl rule__CsvExtract__Group_8__3 )
            // InternalMyDsl.g:893:2: rule__CsvExtract__Group_8__2__Impl rule__CsvExtract__Group_8__3
            {
            pushFollow(FOLLOW_6);
            rule__CsvExtract__Group_8__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group_8__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group_8__2"


    // $ANTLR start "rule__CsvExtract__Group_8__2__Impl"
    // InternalMyDsl.g:900:1: rule__CsvExtract__Group_8__2__Impl : ( ( rule__CsvExtract__FilterAssignment_8_2 ) ) ;
    public final void rule__CsvExtract__Group_8__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:904:1: ( ( ( rule__CsvExtract__FilterAssignment_8_2 ) ) )
            // InternalMyDsl.g:905:1: ( ( rule__CsvExtract__FilterAssignment_8_2 ) )
            {
            // InternalMyDsl.g:905:1: ( ( rule__CsvExtract__FilterAssignment_8_2 ) )
            // InternalMyDsl.g:906:2: ( rule__CsvExtract__FilterAssignment_8_2 )
            {
             before(grammarAccess.getCsvExtractAccess().getFilterAssignment_8_2()); 
            // InternalMyDsl.g:907:2: ( rule__CsvExtract__FilterAssignment_8_2 )
            // InternalMyDsl.g:907:3: rule__CsvExtract__FilterAssignment_8_2
            {
            pushFollow(FOLLOW_2);
            rule__CsvExtract__FilterAssignment_8_2();

            state._fsp--;


            }

             after(grammarAccess.getCsvExtractAccess().getFilterAssignment_8_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group_8__2__Impl"


    // $ANTLR start "rule__CsvExtract__Group_8__3"
    // InternalMyDsl.g:915:1: rule__CsvExtract__Group_8__3 : rule__CsvExtract__Group_8__3__Impl rule__CsvExtract__Group_8__4 ;
    public final void rule__CsvExtract__Group_8__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:919:1: ( rule__CsvExtract__Group_8__3__Impl rule__CsvExtract__Group_8__4 )
            // InternalMyDsl.g:920:2: rule__CsvExtract__Group_8__3__Impl rule__CsvExtract__Group_8__4
            {
            pushFollow(FOLLOW_6);
            rule__CsvExtract__Group_8__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group_8__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group_8__3"


    // $ANTLR start "rule__CsvExtract__Group_8__3__Impl"
    // InternalMyDsl.g:927:1: rule__CsvExtract__Group_8__3__Impl : ( ( rule__CsvExtract__Group_8_3__0 )* ) ;
    public final void rule__CsvExtract__Group_8__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:931:1: ( ( ( rule__CsvExtract__Group_8_3__0 )* ) )
            // InternalMyDsl.g:932:1: ( ( rule__CsvExtract__Group_8_3__0 )* )
            {
            // InternalMyDsl.g:932:1: ( ( rule__CsvExtract__Group_8_3__0 )* )
            // InternalMyDsl.g:933:2: ( rule__CsvExtract__Group_8_3__0 )*
            {
             before(grammarAccess.getCsvExtractAccess().getGroup_8_3()); 
            // InternalMyDsl.g:934:2: ( rule__CsvExtract__Group_8_3__0 )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0==25) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // InternalMyDsl.g:934:3: rule__CsvExtract__Group_8_3__0
            	    {
            	    pushFollow(FOLLOW_7);
            	    rule__CsvExtract__Group_8_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);

             after(grammarAccess.getCsvExtractAccess().getGroup_8_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group_8__3__Impl"


    // $ANTLR start "rule__CsvExtract__Group_8__4"
    // InternalMyDsl.g:942:1: rule__CsvExtract__Group_8__4 : rule__CsvExtract__Group_8__4__Impl ;
    public final void rule__CsvExtract__Group_8__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:946:1: ( rule__CsvExtract__Group_8__4__Impl )
            // InternalMyDsl.g:947:2: rule__CsvExtract__Group_8__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group_8__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group_8__4"


    // $ANTLR start "rule__CsvExtract__Group_8__4__Impl"
    // InternalMyDsl.g:953:1: rule__CsvExtract__Group_8__4__Impl : ( '}' ) ;
    public final void rule__CsvExtract__Group_8__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:957:1: ( ( '}' ) )
            // InternalMyDsl.g:958:1: ( '}' )
            {
            // InternalMyDsl.g:958:1: ( '}' )
            // InternalMyDsl.g:959:2: '}'
            {
             before(grammarAccess.getCsvExtractAccess().getRightCurlyBracketKeyword_8_4()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getCsvExtractAccess().getRightCurlyBracketKeyword_8_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group_8__4__Impl"


    // $ANTLR start "rule__CsvExtract__Group_8_3__0"
    // InternalMyDsl.g:969:1: rule__CsvExtract__Group_8_3__0 : rule__CsvExtract__Group_8_3__0__Impl rule__CsvExtract__Group_8_3__1 ;
    public final void rule__CsvExtract__Group_8_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:973:1: ( rule__CsvExtract__Group_8_3__0__Impl rule__CsvExtract__Group_8_3__1 )
            // InternalMyDsl.g:974:2: rule__CsvExtract__Group_8_3__0__Impl rule__CsvExtract__Group_8_3__1
            {
            pushFollow(FOLLOW_12);
            rule__CsvExtract__Group_8_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group_8_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group_8_3__0"


    // $ANTLR start "rule__CsvExtract__Group_8_3__0__Impl"
    // InternalMyDsl.g:981:1: rule__CsvExtract__Group_8_3__0__Impl : ( ',' ) ;
    public final void rule__CsvExtract__Group_8_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:985:1: ( ( ',' ) )
            // InternalMyDsl.g:986:1: ( ',' )
            {
            // InternalMyDsl.g:986:1: ( ',' )
            // InternalMyDsl.g:987:2: ','
            {
             before(grammarAccess.getCsvExtractAccess().getCommaKeyword_8_3_0()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getCsvExtractAccess().getCommaKeyword_8_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group_8_3__0__Impl"


    // $ANTLR start "rule__CsvExtract__Group_8_3__1"
    // InternalMyDsl.g:996:1: rule__CsvExtract__Group_8_3__1 : rule__CsvExtract__Group_8_3__1__Impl ;
    public final void rule__CsvExtract__Group_8_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1000:1: ( rule__CsvExtract__Group_8_3__1__Impl )
            // InternalMyDsl.g:1001:2: rule__CsvExtract__Group_8_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group_8_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group_8_3__1"


    // $ANTLR start "rule__CsvExtract__Group_8_3__1__Impl"
    // InternalMyDsl.g:1007:1: rule__CsvExtract__Group_8_3__1__Impl : ( ( rule__CsvExtract__FilterAssignment_8_3_1 ) ) ;
    public final void rule__CsvExtract__Group_8_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1011:1: ( ( ( rule__CsvExtract__FilterAssignment_8_3_1 ) ) )
            // InternalMyDsl.g:1012:1: ( ( rule__CsvExtract__FilterAssignment_8_3_1 ) )
            {
            // InternalMyDsl.g:1012:1: ( ( rule__CsvExtract__FilterAssignment_8_3_1 ) )
            // InternalMyDsl.g:1013:2: ( rule__CsvExtract__FilterAssignment_8_3_1 )
            {
             before(grammarAccess.getCsvExtractAccess().getFilterAssignment_8_3_1()); 
            // InternalMyDsl.g:1014:2: ( rule__CsvExtract__FilterAssignment_8_3_1 )
            // InternalMyDsl.g:1014:3: rule__CsvExtract__FilterAssignment_8_3_1
            {
            pushFollow(FOLLOW_2);
            rule__CsvExtract__FilterAssignment_8_3_1();

            state._fsp--;


            }

             after(grammarAccess.getCsvExtractAccess().getFilterAssignment_8_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group_8_3__1__Impl"


    // $ANTLR start "rule__CsvExtract__Group_12__0"
    // InternalMyDsl.g:1023:1: rule__CsvExtract__Group_12__0 : rule__CsvExtract__Group_12__0__Impl rule__CsvExtract__Group_12__1 ;
    public final void rule__CsvExtract__Group_12__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1027:1: ( rule__CsvExtract__Group_12__0__Impl rule__CsvExtract__Group_12__1 )
            // InternalMyDsl.g:1028:2: rule__CsvExtract__Group_12__0__Impl rule__CsvExtract__Group_12__1
            {
            pushFollow(FOLLOW_9);
            rule__CsvExtract__Group_12__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group_12__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group_12__0"


    // $ANTLR start "rule__CsvExtract__Group_12__0__Impl"
    // InternalMyDsl.g:1035:1: rule__CsvExtract__Group_12__0__Impl : ( ',' ) ;
    public final void rule__CsvExtract__Group_12__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1039:1: ( ( ',' ) )
            // InternalMyDsl.g:1040:1: ( ',' )
            {
            // InternalMyDsl.g:1040:1: ( ',' )
            // InternalMyDsl.g:1041:2: ','
            {
             before(grammarAccess.getCsvExtractAccess().getCommaKeyword_12_0()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getCsvExtractAccess().getCommaKeyword_12_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group_12__0__Impl"


    // $ANTLR start "rule__CsvExtract__Group_12__1"
    // InternalMyDsl.g:1050:1: rule__CsvExtract__Group_12__1 : rule__CsvExtract__Group_12__1__Impl ;
    public final void rule__CsvExtract__Group_12__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1054:1: ( rule__CsvExtract__Group_12__1__Impl )
            // InternalMyDsl.g:1055:2: rule__CsvExtract__Group_12__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__CsvExtract__Group_12__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group_12__1"


    // $ANTLR start "rule__CsvExtract__Group_12__1__Impl"
    // InternalMyDsl.g:1061:1: rule__CsvExtract__Group_12__1__Impl : ( ( rule__CsvExtract__ChartAssignment_12_1 ) ) ;
    public final void rule__CsvExtract__Group_12__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1065:1: ( ( ( rule__CsvExtract__ChartAssignment_12_1 ) ) )
            // InternalMyDsl.g:1066:1: ( ( rule__CsvExtract__ChartAssignment_12_1 ) )
            {
            // InternalMyDsl.g:1066:1: ( ( rule__CsvExtract__ChartAssignment_12_1 ) )
            // InternalMyDsl.g:1067:2: ( rule__CsvExtract__ChartAssignment_12_1 )
            {
             before(grammarAccess.getCsvExtractAccess().getChartAssignment_12_1()); 
            // InternalMyDsl.g:1068:2: ( rule__CsvExtract__ChartAssignment_12_1 )
            // InternalMyDsl.g:1068:3: rule__CsvExtract__ChartAssignment_12_1
            {
            pushFollow(FOLLOW_2);
            rule__CsvExtract__ChartAssignment_12_1();

            state._fsp--;


            }

             after(grammarAccess.getCsvExtractAccess().getChartAssignment_12_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__Group_12__1__Impl"


    // $ANTLR start "rule__Column__Group__0"
    // InternalMyDsl.g:1077:1: rule__Column__Group__0 : rule__Column__Group__0__Impl rule__Column__Group__1 ;
    public final void rule__Column__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1081:1: ( rule__Column__Group__0__Impl rule__Column__Group__1 )
            // InternalMyDsl.g:1082:2: rule__Column__Group__0__Impl rule__Column__Group__1
            {
            pushFollow(FOLLOW_5);
            rule__Column__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Column__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Column__Group__0"


    // $ANTLR start "rule__Column__Group__0__Impl"
    // InternalMyDsl.g:1089:1: rule__Column__Group__0__Impl : ( () ) ;
    public final void rule__Column__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1093:1: ( ( () ) )
            // InternalMyDsl.g:1094:1: ( () )
            {
            // InternalMyDsl.g:1094:1: ( () )
            // InternalMyDsl.g:1095:2: ()
            {
             before(grammarAccess.getColumnAccess().getColumnAction_0()); 
            // InternalMyDsl.g:1096:2: ()
            // InternalMyDsl.g:1096:3: 
            {
            }

             after(grammarAccess.getColumnAccess().getColumnAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Column__Group__0__Impl"


    // $ANTLR start "rule__Column__Group__1"
    // InternalMyDsl.g:1104:1: rule__Column__Group__1 : rule__Column__Group__1__Impl rule__Column__Group__2 ;
    public final void rule__Column__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1108:1: ( rule__Column__Group__1__Impl rule__Column__Group__2 )
            // InternalMyDsl.g:1109:2: rule__Column__Group__1__Impl rule__Column__Group__2
            {
            pushFollow(FOLLOW_11);
            rule__Column__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Column__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Column__Group__1"


    // $ANTLR start "rule__Column__Group__1__Impl"
    // InternalMyDsl.g:1116:1: rule__Column__Group__1__Impl : ( 'Column' ) ;
    public final void rule__Column__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1120:1: ( ( 'Column' ) )
            // InternalMyDsl.g:1121:1: ( 'Column' )
            {
            // InternalMyDsl.g:1121:1: ( 'Column' )
            // InternalMyDsl.g:1122:2: 'Column'
            {
             before(grammarAccess.getColumnAccess().getColumnKeyword_1()); 
            match(input,27,FOLLOW_2); 
             after(grammarAccess.getColumnAccess().getColumnKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Column__Group__1__Impl"


    // $ANTLR start "rule__Column__Group__2"
    // InternalMyDsl.g:1131:1: rule__Column__Group__2 : rule__Column__Group__2__Impl rule__Column__Group__3 ;
    public final void rule__Column__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1135:1: ( rule__Column__Group__2__Impl rule__Column__Group__3 )
            // InternalMyDsl.g:1136:2: rule__Column__Group__2__Impl rule__Column__Group__3
            {
            pushFollow(FOLLOW_3);
            rule__Column__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Column__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Column__Group__2"


    // $ANTLR start "rule__Column__Group__2__Impl"
    // InternalMyDsl.g:1143:1: rule__Column__Group__2__Impl : ( ( rule__Column__NameAssignment_2 ) ) ;
    public final void rule__Column__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1147:1: ( ( ( rule__Column__NameAssignment_2 ) ) )
            // InternalMyDsl.g:1148:1: ( ( rule__Column__NameAssignment_2 ) )
            {
            // InternalMyDsl.g:1148:1: ( ( rule__Column__NameAssignment_2 ) )
            // InternalMyDsl.g:1149:2: ( rule__Column__NameAssignment_2 )
            {
             before(grammarAccess.getColumnAccess().getNameAssignment_2()); 
            // InternalMyDsl.g:1150:2: ( rule__Column__NameAssignment_2 )
            // InternalMyDsl.g:1150:3: rule__Column__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Column__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getColumnAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Column__Group__2__Impl"


    // $ANTLR start "rule__Column__Group__3"
    // InternalMyDsl.g:1158:1: rule__Column__Group__3 : rule__Column__Group__3__Impl rule__Column__Group__4 ;
    public final void rule__Column__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1162:1: ( rule__Column__Group__3__Impl rule__Column__Group__4 )
            // InternalMyDsl.g:1163:2: rule__Column__Group__3__Impl rule__Column__Group__4
            {
            pushFollow(FOLLOW_13);
            rule__Column__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Column__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Column__Group__3"


    // $ANTLR start "rule__Column__Group__3__Impl"
    // InternalMyDsl.g:1170:1: rule__Column__Group__3__Impl : ( '{' ) ;
    public final void rule__Column__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1174:1: ( ( '{' ) )
            // InternalMyDsl.g:1175:1: ( '{' )
            {
            // InternalMyDsl.g:1175:1: ( '{' )
            // InternalMyDsl.g:1176:2: '{'
            {
             before(grammarAccess.getColumnAccess().getLeftCurlyBracketKeyword_3()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getColumnAccess().getLeftCurlyBracketKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Column__Group__3__Impl"


    // $ANTLR start "rule__Column__Group__4"
    // InternalMyDsl.g:1185:1: rule__Column__Group__4 : rule__Column__Group__4__Impl rule__Column__Group__5 ;
    public final void rule__Column__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1189:1: ( rule__Column__Group__4__Impl rule__Column__Group__5 )
            // InternalMyDsl.g:1190:2: rule__Column__Group__4__Impl rule__Column__Group__5
            {
            pushFollow(FOLLOW_13);
            rule__Column__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Column__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Column__Group__4"


    // $ANTLR start "rule__Column__Group__4__Impl"
    // InternalMyDsl.g:1197:1: rule__Column__Group__4__Impl : ( ( rule__Column__Group_4__0 )? ) ;
    public final void rule__Column__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1201:1: ( ( ( rule__Column__Group_4__0 )? ) )
            // InternalMyDsl.g:1202:1: ( ( rule__Column__Group_4__0 )? )
            {
            // InternalMyDsl.g:1202:1: ( ( rule__Column__Group_4__0 )? )
            // InternalMyDsl.g:1203:2: ( rule__Column__Group_4__0 )?
            {
             before(grammarAccess.getColumnAccess().getGroup_4()); 
            // InternalMyDsl.g:1204:2: ( rule__Column__Group_4__0 )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==28) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalMyDsl.g:1204:3: rule__Column__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Column__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getColumnAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Column__Group__4__Impl"


    // $ANTLR start "rule__Column__Group__5"
    // InternalMyDsl.g:1212:1: rule__Column__Group__5 : rule__Column__Group__5__Impl rule__Column__Group__6 ;
    public final void rule__Column__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1216:1: ( rule__Column__Group__5__Impl rule__Column__Group__6 )
            // InternalMyDsl.g:1217:2: rule__Column__Group__5__Impl rule__Column__Group__6
            {
            pushFollow(FOLLOW_13);
            rule__Column__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Column__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Column__Group__5"


    // $ANTLR start "rule__Column__Group__5__Impl"
    // InternalMyDsl.g:1224:1: rule__Column__Group__5__Impl : ( ( rule__Column__Group_5__0 )? ) ;
    public final void rule__Column__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1228:1: ( ( ( rule__Column__Group_5__0 )? ) )
            // InternalMyDsl.g:1229:1: ( ( rule__Column__Group_5__0 )? )
            {
            // InternalMyDsl.g:1229:1: ( ( rule__Column__Group_5__0 )? )
            // InternalMyDsl.g:1230:2: ( rule__Column__Group_5__0 )?
            {
             before(grammarAccess.getColumnAccess().getGroup_5()); 
            // InternalMyDsl.g:1231:2: ( rule__Column__Group_5__0 )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==29) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalMyDsl.g:1231:3: rule__Column__Group_5__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Column__Group_5__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getColumnAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Column__Group__5__Impl"


    // $ANTLR start "rule__Column__Group__6"
    // InternalMyDsl.g:1239:1: rule__Column__Group__6 : rule__Column__Group__6__Impl ;
    public final void rule__Column__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1243:1: ( rule__Column__Group__6__Impl )
            // InternalMyDsl.g:1244:2: rule__Column__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Column__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Column__Group__6"


    // $ANTLR start "rule__Column__Group__6__Impl"
    // InternalMyDsl.g:1250:1: rule__Column__Group__6__Impl : ( '}' ) ;
    public final void rule__Column__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1254:1: ( ( '}' ) )
            // InternalMyDsl.g:1255:1: ( '}' )
            {
            // InternalMyDsl.g:1255:1: ( '}' )
            // InternalMyDsl.g:1256:2: '}'
            {
             before(grammarAccess.getColumnAccess().getRightCurlyBracketKeyword_6()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getColumnAccess().getRightCurlyBracketKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Column__Group__6__Impl"


    // $ANTLR start "rule__Column__Group_4__0"
    // InternalMyDsl.g:1266:1: rule__Column__Group_4__0 : rule__Column__Group_4__0__Impl rule__Column__Group_4__1 ;
    public final void rule__Column__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1270:1: ( rule__Column__Group_4__0__Impl rule__Column__Group_4__1 )
            // InternalMyDsl.g:1271:2: rule__Column__Group_4__0__Impl rule__Column__Group_4__1
            {
            pushFollow(FOLLOW_11);
            rule__Column__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Column__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Column__Group_4__0"


    // $ANTLR start "rule__Column__Group_4__0__Impl"
    // InternalMyDsl.g:1278:1: rule__Column__Group_4__0__Impl : ( 'dataType' ) ;
    public final void rule__Column__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1282:1: ( ( 'dataType' ) )
            // InternalMyDsl.g:1283:1: ( 'dataType' )
            {
            // InternalMyDsl.g:1283:1: ( 'dataType' )
            // InternalMyDsl.g:1284:2: 'dataType'
            {
             before(grammarAccess.getColumnAccess().getDataTypeKeyword_4_0()); 
            match(input,28,FOLLOW_2); 
             after(grammarAccess.getColumnAccess().getDataTypeKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Column__Group_4__0__Impl"


    // $ANTLR start "rule__Column__Group_4__1"
    // InternalMyDsl.g:1293:1: rule__Column__Group_4__1 : rule__Column__Group_4__1__Impl ;
    public final void rule__Column__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1297:1: ( rule__Column__Group_4__1__Impl )
            // InternalMyDsl.g:1298:2: rule__Column__Group_4__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Column__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Column__Group_4__1"


    // $ANTLR start "rule__Column__Group_4__1__Impl"
    // InternalMyDsl.g:1304:1: rule__Column__Group_4__1__Impl : ( ( rule__Column__DataTypeAssignment_4_1 ) ) ;
    public final void rule__Column__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1308:1: ( ( ( rule__Column__DataTypeAssignment_4_1 ) ) )
            // InternalMyDsl.g:1309:1: ( ( rule__Column__DataTypeAssignment_4_1 ) )
            {
            // InternalMyDsl.g:1309:1: ( ( rule__Column__DataTypeAssignment_4_1 ) )
            // InternalMyDsl.g:1310:2: ( rule__Column__DataTypeAssignment_4_1 )
            {
             before(grammarAccess.getColumnAccess().getDataTypeAssignment_4_1()); 
            // InternalMyDsl.g:1311:2: ( rule__Column__DataTypeAssignment_4_1 )
            // InternalMyDsl.g:1311:3: rule__Column__DataTypeAssignment_4_1
            {
            pushFollow(FOLLOW_2);
            rule__Column__DataTypeAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getColumnAccess().getDataTypeAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Column__Group_4__1__Impl"


    // $ANTLR start "rule__Column__Group_5__0"
    // InternalMyDsl.g:1320:1: rule__Column__Group_5__0 : rule__Column__Group_5__0__Impl rule__Column__Group_5__1 ;
    public final void rule__Column__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1324:1: ( rule__Column__Group_5__0__Impl rule__Column__Group_5__1 )
            // InternalMyDsl.g:1325:2: rule__Column__Group_5__0__Impl rule__Column__Group_5__1
            {
            pushFollow(FOLLOW_14);
            rule__Column__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Column__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Column__Group_5__0"


    // $ANTLR start "rule__Column__Group_5__0__Impl"
    // InternalMyDsl.g:1332:1: rule__Column__Group_5__0__Impl : ( 'index' ) ;
    public final void rule__Column__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1336:1: ( ( 'index' ) )
            // InternalMyDsl.g:1337:1: ( 'index' )
            {
            // InternalMyDsl.g:1337:1: ( 'index' )
            // InternalMyDsl.g:1338:2: 'index'
            {
             before(grammarAccess.getColumnAccess().getIndexKeyword_5_0()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getColumnAccess().getIndexKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Column__Group_5__0__Impl"


    // $ANTLR start "rule__Column__Group_5__1"
    // InternalMyDsl.g:1347:1: rule__Column__Group_5__1 : rule__Column__Group_5__1__Impl ;
    public final void rule__Column__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1351:1: ( rule__Column__Group_5__1__Impl )
            // InternalMyDsl.g:1352:2: rule__Column__Group_5__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Column__Group_5__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Column__Group_5__1"


    // $ANTLR start "rule__Column__Group_5__1__Impl"
    // InternalMyDsl.g:1358:1: rule__Column__Group_5__1__Impl : ( ( rule__Column__IndexAssignment_5_1 ) ) ;
    public final void rule__Column__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1362:1: ( ( ( rule__Column__IndexAssignment_5_1 ) ) )
            // InternalMyDsl.g:1363:1: ( ( rule__Column__IndexAssignment_5_1 ) )
            {
            // InternalMyDsl.g:1363:1: ( ( rule__Column__IndexAssignment_5_1 ) )
            // InternalMyDsl.g:1364:2: ( rule__Column__IndexAssignment_5_1 )
            {
             before(grammarAccess.getColumnAccess().getIndexAssignment_5_1()); 
            // InternalMyDsl.g:1365:2: ( rule__Column__IndexAssignment_5_1 )
            // InternalMyDsl.g:1365:3: rule__Column__IndexAssignment_5_1
            {
            pushFollow(FOLLOW_2);
            rule__Column__IndexAssignment_5_1();

            state._fsp--;


            }

             after(grammarAccess.getColumnAccess().getIndexAssignment_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Column__Group_5__1__Impl"


    // $ANTLR start "rule__Filter__Group__0"
    // InternalMyDsl.g:1374:1: rule__Filter__Group__0 : rule__Filter__Group__0__Impl rule__Filter__Group__1 ;
    public final void rule__Filter__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1378:1: ( rule__Filter__Group__0__Impl rule__Filter__Group__1 )
            // InternalMyDsl.g:1379:2: rule__Filter__Group__0__Impl rule__Filter__Group__1
            {
            pushFollow(FOLLOW_12);
            rule__Filter__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Filter__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__Group__0"


    // $ANTLR start "rule__Filter__Group__0__Impl"
    // InternalMyDsl.g:1386:1: rule__Filter__Group__0__Impl : ( () ) ;
    public final void rule__Filter__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1390:1: ( ( () ) )
            // InternalMyDsl.g:1391:1: ( () )
            {
            // InternalMyDsl.g:1391:1: ( () )
            // InternalMyDsl.g:1392:2: ()
            {
             before(grammarAccess.getFilterAccess().getFilterAction_0()); 
            // InternalMyDsl.g:1393:2: ()
            // InternalMyDsl.g:1393:3: 
            {
            }

             after(grammarAccess.getFilterAccess().getFilterAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__Group__0__Impl"


    // $ANTLR start "rule__Filter__Group__1"
    // InternalMyDsl.g:1401:1: rule__Filter__Group__1 : rule__Filter__Group__1__Impl rule__Filter__Group__2 ;
    public final void rule__Filter__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1405:1: ( rule__Filter__Group__1__Impl rule__Filter__Group__2 )
            // InternalMyDsl.g:1406:2: rule__Filter__Group__1__Impl rule__Filter__Group__2
            {
            pushFollow(FOLLOW_3);
            rule__Filter__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Filter__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__Group__1"


    // $ANTLR start "rule__Filter__Group__1__Impl"
    // InternalMyDsl.g:1413:1: rule__Filter__Group__1__Impl : ( 'Filter' ) ;
    public final void rule__Filter__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1417:1: ( ( 'Filter' ) )
            // InternalMyDsl.g:1418:1: ( 'Filter' )
            {
            // InternalMyDsl.g:1418:1: ( 'Filter' )
            // InternalMyDsl.g:1419:2: 'Filter'
            {
             before(grammarAccess.getFilterAccess().getFilterKeyword_1()); 
            match(input,30,FOLLOW_2); 
             after(grammarAccess.getFilterAccess().getFilterKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__Group__1__Impl"


    // $ANTLR start "rule__Filter__Group__2"
    // InternalMyDsl.g:1428:1: rule__Filter__Group__2 : rule__Filter__Group__2__Impl rule__Filter__Group__3 ;
    public final void rule__Filter__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1432:1: ( rule__Filter__Group__2__Impl rule__Filter__Group__3 )
            // InternalMyDsl.g:1433:2: rule__Filter__Group__2__Impl rule__Filter__Group__3
            {
            pushFollow(FOLLOW_15);
            rule__Filter__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Filter__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__Group__2"


    // $ANTLR start "rule__Filter__Group__2__Impl"
    // InternalMyDsl.g:1440:1: rule__Filter__Group__2__Impl : ( '{' ) ;
    public final void rule__Filter__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1444:1: ( ( '{' ) )
            // InternalMyDsl.g:1445:1: ( '{' )
            {
            // InternalMyDsl.g:1445:1: ( '{' )
            // InternalMyDsl.g:1446:2: '{'
            {
             before(grammarAccess.getFilterAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getFilterAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__Group__2__Impl"


    // $ANTLR start "rule__Filter__Group__3"
    // InternalMyDsl.g:1455:1: rule__Filter__Group__3 : rule__Filter__Group__3__Impl rule__Filter__Group__4 ;
    public final void rule__Filter__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1459:1: ( rule__Filter__Group__3__Impl rule__Filter__Group__4 )
            // InternalMyDsl.g:1460:2: rule__Filter__Group__3__Impl rule__Filter__Group__4
            {
            pushFollow(FOLLOW_15);
            rule__Filter__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Filter__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__Group__3"


    // $ANTLR start "rule__Filter__Group__3__Impl"
    // InternalMyDsl.g:1467:1: rule__Filter__Group__3__Impl : ( ( rule__Filter__Group_3__0 )? ) ;
    public final void rule__Filter__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1471:1: ( ( ( rule__Filter__Group_3__0 )? ) )
            // InternalMyDsl.g:1472:1: ( ( rule__Filter__Group_3__0 )? )
            {
            // InternalMyDsl.g:1472:1: ( ( rule__Filter__Group_3__0 )? )
            // InternalMyDsl.g:1473:2: ( rule__Filter__Group_3__0 )?
            {
             before(grammarAccess.getFilterAccess().getGroup_3()); 
            // InternalMyDsl.g:1474:2: ( rule__Filter__Group_3__0 )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==31) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // InternalMyDsl.g:1474:3: rule__Filter__Group_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Filter__Group_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getFilterAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__Group__3__Impl"


    // $ANTLR start "rule__Filter__Group__4"
    // InternalMyDsl.g:1482:1: rule__Filter__Group__4 : rule__Filter__Group__4__Impl rule__Filter__Group__5 ;
    public final void rule__Filter__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1486:1: ( rule__Filter__Group__4__Impl rule__Filter__Group__5 )
            // InternalMyDsl.g:1487:2: rule__Filter__Group__4__Impl rule__Filter__Group__5
            {
            pushFollow(FOLLOW_15);
            rule__Filter__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Filter__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__Group__4"


    // $ANTLR start "rule__Filter__Group__4__Impl"
    // InternalMyDsl.g:1494:1: rule__Filter__Group__4__Impl : ( ( rule__Filter__Group_4__0 )? ) ;
    public final void rule__Filter__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1498:1: ( ( ( rule__Filter__Group_4__0 )? ) )
            // InternalMyDsl.g:1499:1: ( ( rule__Filter__Group_4__0 )? )
            {
            // InternalMyDsl.g:1499:1: ( ( rule__Filter__Group_4__0 )? )
            // InternalMyDsl.g:1500:2: ( rule__Filter__Group_4__0 )?
            {
             before(grammarAccess.getFilterAccess().getGroup_4()); 
            // InternalMyDsl.g:1501:2: ( rule__Filter__Group_4__0 )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==32) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalMyDsl.g:1501:3: rule__Filter__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Filter__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getFilterAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__Group__4__Impl"


    // $ANTLR start "rule__Filter__Group__5"
    // InternalMyDsl.g:1509:1: rule__Filter__Group__5 : rule__Filter__Group__5__Impl rule__Filter__Group__6 ;
    public final void rule__Filter__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1513:1: ( rule__Filter__Group__5__Impl rule__Filter__Group__6 )
            // InternalMyDsl.g:1514:2: rule__Filter__Group__5__Impl rule__Filter__Group__6
            {
            pushFollow(FOLLOW_15);
            rule__Filter__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Filter__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__Group__5"


    // $ANTLR start "rule__Filter__Group__5__Impl"
    // InternalMyDsl.g:1521:1: rule__Filter__Group__5__Impl : ( ( rule__Filter__Group_5__0 )? ) ;
    public final void rule__Filter__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1525:1: ( ( ( rule__Filter__Group_5__0 )? ) )
            // InternalMyDsl.g:1526:1: ( ( rule__Filter__Group_5__0 )? )
            {
            // InternalMyDsl.g:1526:1: ( ( rule__Filter__Group_5__0 )? )
            // InternalMyDsl.g:1527:2: ( rule__Filter__Group_5__0 )?
            {
             before(grammarAccess.getFilterAccess().getGroup_5()); 
            // InternalMyDsl.g:1528:2: ( rule__Filter__Group_5__0 )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==33) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalMyDsl.g:1528:3: rule__Filter__Group_5__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Filter__Group_5__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getFilterAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__Group__5__Impl"


    // $ANTLR start "rule__Filter__Group__6"
    // InternalMyDsl.g:1536:1: rule__Filter__Group__6 : rule__Filter__Group__6__Impl ;
    public final void rule__Filter__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1540:1: ( rule__Filter__Group__6__Impl )
            // InternalMyDsl.g:1541:2: rule__Filter__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Filter__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__Group__6"


    // $ANTLR start "rule__Filter__Group__6__Impl"
    // InternalMyDsl.g:1547:1: rule__Filter__Group__6__Impl : ( '}' ) ;
    public final void rule__Filter__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1551:1: ( ( '}' ) )
            // InternalMyDsl.g:1552:1: ( '}' )
            {
            // InternalMyDsl.g:1552:1: ( '}' )
            // InternalMyDsl.g:1553:2: '}'
            {
             before(grammarAccess.getFilterAccess().getRightCurlyBracketKeyword_6()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getFilterAccess().getRightCurlyBracketKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__Group__6__Impl"


    // $ANTLR start "rule__Filter__Group_3__0"
    // InternalMyDsl.g:1563:1: rule__Filter__Group_3__0 : rule__Filter__Group_3__0__Impl rule__Filter__Group_3__1 ;
    public final void rule__Filter__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1567:1: ( rule__Filter__Group_3__0__Impl rule__Filter__Group_3__1 )
            // InternalMyDsl.g:1568:2: rule__Filter__Group_3__0__Impl rule__Filter__Group_3__1
            {
            pushFollow(FOLLOW_11);
            rule__Filter__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Filter__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__Group_3__0"


    // $ANTLR start "rule__Filter__Group_3__0__Impl"
    // InternalMyDsl.g:1575:1: rule__Filter__Group_3__0__Impl : ( 'columnName' ) ;
    public final void rule__Filter__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1579:1: ( ( 'columnName' ) )
            // InternalMyDsl.g:1580:1: ( 'columnName' )
            {
            // InternalMyDsl.g:1580:1: ( 'columnName' )
            // InternalMyDsl.g:1581:2: 'columnName'
            {
             before(grammarAccess.getFilterAccess().getColumnNameKeyword_3_0()); 
            match(input,31,FOLLOW_2); 
             after(grammarAccess.getFilterAccess().getColumnNameKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__Group_3__0__Impl"


    // $ANTLR start "rule__Filter__Group_3__1"
    // InternalMyDsl.g:1590:1: rule__Filter__Group_3__1 : rule__Filter__Group_3__1__Impl ;
    public final void rule__Filter__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1594:1: ( rule__Filter__Group_3__1__Impl )
            // InternalMyDsl.g:1595:2: rule__Filter__Group_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Filter__Group_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__Group_3__1"


    // $ANTLR start "rule__Filter__Group_3__1__Impl"
    // InternalMyDsl.g:1601:1: rule__Filter__Group_3__1__Impl : ( ( rule__Filter__ColumnNameAssignment_3_1 ) ) ;
    public final void rule__Filter__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1605:1: ( ( ( rule__Filter__ColumnNameAssignment_3_1 ) ) )
            // InternalMyDsl.g:1606:1: ( ( rule__Filter__ColumnNameAssignment_3_1 ) )
            {
            // InternalMyDsl.g:1606:1: ( ( rule__Filter__ColumnNameAssignment_3_1 ) )
            // InternalMyDsl.g:1607:2: ( rule__Filter__ColumnNameAssignment_3_1 )
            {
             before(grammarAccess.getFilterAccess().getColumnNameAssignment_3_1()); 
            // InternalMyDsl.g:1608:2: ( rule__Filter__ColumnNameAssignment_3_1 )
            // InternalMyDsl.g:1608:3: rule__Filter__ColumnNameAssignment_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Filter__ColumnNameAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getFilterAccess().getColumnNameAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__Group_3__1__Impl"


    // $ANTLR start "rule__Filter__Group_4__0"
    // InternalMyDsl.g:1617:1: rule__Filter__Group_4__0 : rule__Filter__Group_4__0__Impl rule__Filter__Group_4__1 ;
    public final void rule__Filter__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1621:1: ( rule__Filter__Group_4__0__Impl rule__Filter__Group_4__1 )
            // InternalMyDsl.g:1622:2: rule__Filter__Group_4__0__Impl rule__Filter__Group_4__1
            {
            pushFollow(FOLLOW_16);
            rule__Filter__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Filter__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__Group_4__0"


    // $ANTLR start "rule__Filter__Group_4__0__Impl"
    // InternalMyDsl.g:1629:1: rule__Filter__Group_4__0__Impl : ( 'rule' ) ;
    public final void rule__Filter__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1633:1: ( ( 'rule' ) )
            // InternalMyDsl.g:1634:1: ( 'rule' )
            {
            // InternalMyDsl.g:1634:1: ( 'rule' )
            // InternalMyDsl.g:1635:2: 'rule'
            {
             before(grammarAccess.getFilterAccess().getRuleKeyword_4_0()); 
            match(input,32,FOLLOW_2); 
             after(grammarAccess.getFilterAccess().getRuleKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__Group_4__0__Impl"


    // $ANTLR start "rule__Filter__Group_4__1"
    // InternalMyDsl.g:1644:1: rule__Filter__Group_4__1 : rule__Filter__Group_4__1__Impl ;
    public final void rule__Filter__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1648:1: ( rule__Filter__Group_4__1__Impl )
            // InternalMyDsl.g:1649:2: rule__Filter__Group_4__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Filter__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__Group_4__1"


    // $ANTLR start "rule__Filter__Group_4__1__Impl"
    // InternalMyDsl.g:1655:1: rule__Filter__Group_4__1__Impl : ( ( rule__Filter__RuleAssignment_4_1 ) ) ;
    public final void rule__Filter__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1659:1: ( ( ( rule__Filter__RuleAssignment_4_1 ) ) )
            // InternalMyDsl.g:1660:1: ( ( rule__Filter__RuleAssignment_4_1 ) )
            {
            // InternalMyDsl.g:1660:1: ( ( rule__Filter__RuleAssignment_4_1 ) )
            // InternalMyDsl.g:1661:2: ( rule__Filter__RuleAssignment_4_1 )
            {
             before(grammarAccess.getFilterAccess().getRuleAssignment_4_1()); 
            // InternalMyDsl.g:1662:2: ( rule__Filter__RuleAssignment_4_1 )
            // InternalMyDsl.g:1662:3: rule__Filter__RuleAssignment_4_1
            {
            pushFollow(FOLLOW_2);
            rule__Filter__RuleAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getFilterAccess().getRuleAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__Group_4__1__Impl"


    // $ANTLR start "rule__Filter__Group_5__0"
    // InternalMyDsl.g:1671:1: rule__Filter__Group_5__0 : rule__Filter__Group_5__0__Impl rule__Filter__Group_5__1 ;
    public final void rule__Filter__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1675:1: ( rule__Filter__Group_5__0__Impl rule__Filter__Group_5__1 )
            // InternalMyDsl.g:1676:2: rule__Filter__Group_5__0__Impl rule__Filter__Group_5__1
            {
            pushFollow(FOLLOW_11);
            rule__Filter__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Filter__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__Group_5__0"


    // $ANTLR start "rule__Filter__Group_5__0__Impl"
    // InternalMyDsl.g:1683:1: rule__Filter__Group_5__0__Impl : ( 'value' ) ;
    public final void rule__Filter__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1687:1: ( ( 'value' ) )
            // InternalMyDsl.g:1688:1: ( 'value' )
            {
            // InternalMyDsl.g:1688:1: ( 'value' )
            // InternalMyDsl.g:1689:2: 'value'
            {
             before(grammarAccess.getFilterAccess().getValueKeyword_5_0()); 
            match(input,33,FOLLOW_2); 
             after(grammarAccess.getFilterAccess().getValueKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__Group_5__0__Impl"


    // $ANTLR start "rule__Filter__Group_5__1"
    // InternalMyDsl.g:1698:1: rule__Filter__Group_5__1 : rule__Filter__Group_5__1__Impl ;
    public final void rule__Filter__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1702:1: ( rule__Filter__Group_5__1__Impl )
            // InternalMyDsl.g:1703:2: rule__Filter__Group_5__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Filter__Group_5__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__Group_5__1"


    // $ANTLR start "rule__Filter__Group_5__1__Impl"
    // InternalMyDsl.g:1709:1: rule__Filter__Group_5__1__Impl : ( ( rule__Filter__ValueAssignment_5_1 ) ) ;
    public final void rule__Filter__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1713:1: ( ( ( rule__Filter__ValueAssignment_5_1 ) ) )
            // InternalMyDsl.g:1714:1: ( ( rule__Filter__ValueAssignment_5_1 ) )
            {
            // InternalMyDsl.g:1714:1: ( ( rule__Filter__ValueAssignment_5_1 ) )
            // InternalMyDsl.g:1715:2: ( rule__Filter__ValueAssignment_5_1 )
            {
             before(grammarAccess.getFilterAccess().getValueAssignment_5_1()); 
            // InternalMyDsl.g:1716:2: ( rule__Filter__ValueAssignment_5_1 )
            // InternalMyDsl.g:1716:3: rule__Filter__ValueAssignment_5_1
            {
            pushFollow(FOLLOW_2);
            rule__Filter__ValueAssignment_5_1();

            state._fsp--;


            }

             after(grammarAccess.getFilterAccess().getValueAssignment_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__Group_5__1__Impl"


    // $ANTLR start "rule__Chart__Group__0"
    // InternalMyDsl.g:1725:1: rule__Chart__Group__0 : rule__Chart__Group__0__Impl rule__Chart__Group__1 ;
    public final void rule__Chart__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1729:1: ( rule__Chart__Group__0__Impl rule__Chart__Group__1 )
            // InternalMyDsl.g:1730:2: rule__Chart__Group__0__Impl rule__Chart__Group__1
            {
            pushFollow(FOLLOW_9);
            rule__Chart__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Chart__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group__0"


    // $ANTLR start "rule__Chart__Group__0__Impl"
    // InternalMyDsl.g:1737:1: rule__Chart__Group__0__Impl : ( () ) ;
    public final void rule__Chart__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1741:1: ( ( () ) )
            // InternalMyDsl.g:1742:1: ( () )
            {
            // InternalMyDsl.g:1742:1: ( () )
            // InternalMyDsl.g:1743:2: ()
            {
             before(grammarAccess.getChartAccess().getChartAction_0()); 
            // InternalMyDsl.g:1744:2: ()
            // InternalMyDsl.g:1744:3: 
            {
            }

             after(grammarAccess.getChartAccess().getChartAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group__0__Impl"


    // $ANTLR start "rule__Chart__Group__1"
    // InternalMyDsl.g:1752:1: rule__Chart__Group__1 : rule__Chart__Group__1__Impl rule__Chart__Group__2 ;
    public final void rule__Chart__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1756:1: ( rule__Chart__Group__1__Impl rule__Chart__Group__2 )
            // InternalMyDsl.g:1757:2: rule__Chart__Group__1__Impl rule__Chart__Group__2
            {
            pushFollow(FOLLOW_9);
            rule__Chart__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Chart__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group__1"


    // $ANTLR start "rule__Chart__Group__1__Impl"
    // InternalMyDsl.g:1764:1: rule__Chart__Group__1__Impl : ( ( rule__Chart__LegendAssignment_1 )? ) ;
    public final void rule__Chart__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1768:1: ( ( ( rule__Chart__LegendAssignment_1 )? ) )
            // InternalMyDsl.g:1769:1: ( ( rule__Chart__LegendAssignment_1 )? )
            {
            // InternalMyDsl.g:1769:1: ( ( rule__Chart__LegendAssignment_1 )? )
            // InternalMyDsl.g:1770:2: ( rule__Chart__LegendAssignment_1 )?
            {
             before(grammarAccess.getChartAccess().getLegendAssignment_1()); 
            // InternalMyDsl.g:1771:2: ( rule__Chart__LegendAssignment_1 )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==42) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalMyDsl.g:1771:3: rule__Chart__LegendAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Chart__LegendAssignment_1();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getChartAccess().getLegendAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group__1__Impl"


    // $ANTLR start "rule__Chart__Group__2"
    // InternalMyDsl.g:1779:1: rule__Chart__Group__2 : rule__Chart__Group__2__Impl rule__Chart__Group__3 ;
    public final void rule__Chart__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1783:1: ( rule__Chart__Group__2__Impl rule__Chart__Group__3 )
            // InternalMyDsl.g:1784:2: rule__Chart__Group__2__Impl rule__Chart__Group__3
            {
            pushFollow(FOLLOW_3);
            rule__Chart__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Chart__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group__2"


    // $ANTLR start "rule__Chart__Group__2__Impl"
    // InternalMyDsl.g:1791:1: rule__Chart__Group__2__Impl : ( 'Chart' ) ;
    public final void rule__Chart__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1795:1: ( ( 'Chart' ) )
            // InternalMyDsl.g:1796:1: ( 'Chart' )
            {
            // InternalMyDsl.g:1796:1: ( 'Chart' )
            // InternalMyDsl.g:1797:2: 'Chart'
            {
             before(grammarAccess.getChartAccess().getChartKeyword_2()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getChartAccess().getChartKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group__2__Impl"


    // $ANTLR start "rule__Chart__Group__3"
    // InternalMyDsl.g:1806:1: rule__Chart__Group__3 : rule__Chart__Group__3__Impl rule__Chart__Group__4 ;
    public final void rule__Chart__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1810:1: ( rule__Chart__Group__3__Impl rule__Chart__Group__4 )
            // InternalMyDsl.g:1811:2: rule__Chart__Group__3__Impl rule__Chart__Group__4
            {
            pushFollow(FOLLOW_17);
            rule__Chart__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Chart__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group__3"


    // $ANTLR start "rule__Chart__Group__3__Impl"
    // InternalMyDsl.g:1818:1: rule__Chart__Group__3__Impl : ( '{' ) ;
    public final void rule__Chart__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1822:1: ( ( '{' ) )
            // InternalMyDsl.g:1823:1: ( '{' )
            {
            // InternalMyDsl.g:1823:1: ( '{' )
            // InternalMyDsl.g:1824:2: '{'
            {
             before(grammarAccess.getChartAccess().getLeftCurlyBracketKeyword_3()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getChartAccess().getLeftCurlyBracketKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group__3__Impl"


    // $ANTLR start "rule__Chart__Group__4"
    // InternalMyDsl.g:1833:1: rule__Chart__Group__4 : rule__Chart__Group__4__Impl rule__Chart__Group__5 ;
    public final void rule__Chart__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1837:1: ( rule__Chart__Group__4__Impl rule__Chart__Group__5 )
            // InternalMyDsl.g:1838:2: rule__Chart__Group__4__Impl rule__Chart__Group__5
            {
            pushFollow(FOLLOW_17);
            rule__Chart__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Chart__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group__4"


    // $ANTLR start "rule__Chart__Group__4__Impl"
    // InternalMyDsl.g:1845:1: rule__Chart__Group__4__Impl : ( ( rule__Chart__Group_4__0 )? ) ;
    public final void rule__Chart__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1849:1: ( ( ( rule__Chart__Group_4__0 )? ) )
            // InternalMyDsl.g:1850:1: ( ( rule__Chart__Group_4__0 )? )
            {
            // InternalMyDsl.g:1850:1: ( ( rule__Chart__Group_4__0 )? )
            // InternalMyDsl.g:1851:2: ( rule__Chart__Group_4__0 )?
            {
             before(grammarAccess.getChartAccess().getGroup_4()); 
            // InternalMyDsl.g:1852:2: ( rule__Chart__Group_4__0 )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==35) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalMyDsl.g:1852:3: rule__Chart__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Chart__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getChartAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group__4__Impl"


    // $ANTLR start "rule__Chart__Group__5"
    // InternalMyDsl.g:1860:1: rule__Chart__Group__5 : rule__Chart__Group__5__Impl rule__Chart__Group__6 ;
    public final void rule__Chart__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1864:1: ( rule__Chart__Group__5__Impl rule__Chart__Group__6 )
            // InternalMyDsl.g:1865:2: rule__Chart__Group__5__Impl rule__Chart__Group__6
            {
            pushFollow(FOLLOW_17);
            rule__Chart__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Chart__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group__5"


    // $ANTLR start "rule__Chart__Group__5__Impl"
    // InternalMyDsl.g:1872:1: rule__Chart__Group__5__Impl : ( ( rule__Chart__Group_5__0 )? ) ;
    public final void rule__Chart__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1876:1: ( ( ( rule__Chart__Group_5__0 )? ) )
            // InternalMyDsl.g:1877:1: ( ( rule__Chart__Group_5__0 )? )
            {
            // InternalMyDsl.g:1877:1: ( ( rule__Chart__Group_5__0 )? )
            // InternalMyDsl.g:1878:2: ( rule__Chart__Group_5__0 )?
            {
             before(grammarAccess.getChartAccess().getGroup_5()); 
            // InternalMyDsl.g:1879:2: ( rule__Chart__Group_5__0 )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==36) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalMyDsl.g:1879:3: rule__Chart__Group_5__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Chart__Group_5__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getChartAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group__5__Impl"


    // $ANTLR start "rule__Chart__Group__6"
    // InternalMyDsl.g:1887:1: rule__Chart__Group__6 : rule__Chart__Group__6__Impl rule__Chart__Group__7 ;
    public final void rule__Chart__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1891:1: ( rule__Chart__Group__6__Impl rule__Chart__Group__7 )
            // InternalMyDsl.g:1892:2: rule__Chart__Group__6__Impl rule__Chart__Group__7
            {
            pushFollow(FOLLOW_17);
            rule__Chart__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Chart__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group__6"


    // $ANTLR start "rule__Chart__Group__6__Impl"
    // InternalMyDsl.g:1899:1: rule__Chart__Group__6__Impl : ( ( rule__Chart__Group_6__0 )? ) ;
    public final void rule__Chart__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1903:1: ( ( ( rule__Chart__Group_6__0 )? ) )
            // InternalMyDsl.g:1904:1: ( ( rule__Chart__Group_6__0 )? )
            {
            // InternalMyDsl.g:1904:1: ( ( rule__Chart__Group_6__0 )? )
            // InternalMyDsl.g:1905:2: ( rule__Chart__Group_6__0 )?
            {
             before(grammarAccess.getChartAccess().getGroup_6()); 
            // InternalMyDsl.g:1906:2: ( rule__Chart__Group_6__0 )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==37) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalMyDsl.g:1906:3: rule__Chart__Group_6__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Chart__Group_6__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getChartAccess().getGroup_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group__6__Impl"


    // $ANTLR start "rule__Chart__Group__7"
    // InternalMyDsl.g:1914:1: rule__Chart__Group__7 : rule__Chart__Group__7__Impl rule__Chart__Group__8 ;
    public final void rule__Chart__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1918:1: ( rule__Chart__Group__7__Impl rule__Chart__Group__8 )
            // InternalMyDsl.g:1919:2: rule__Chart__Group__7__Impl rule__Chart__Group__8
            {
            pushFollow(FOLLOW_17);
            rule__Chart__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Chart__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group__7"


    // $ANTLR start "rule__Chart__Group__7__Impl"
    // InternalMyDsl.g:1926:1: rule__Chart__Group__7__Impl : ( ( rule__Chart__Group_7__0 )? ) ;
    public final void rule__Chart__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1930:1: ( ( ( rule__Chart__Group_7__0 )? ) )
            // InternalMyDsl.g:1931:1: ( ( rule__Chart__Group_7__0 )? )
            {
            // InternalMyDsl.g:1931:1: ( ( rule__Chart__Group_7__0 )? )
            // InternalMyDsl.g:1932:2: ( rule__Chart__Group_7__0 )?
            {
             before(grammarAccess.getChartAccess().getGroup_7()); 
            // InternalMyDsl.g:1933:2: ( rule__Chart__Group_7__0 )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==38) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // InternalMyDsl.g:1933:3: rule__Chart__Group_7__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Chart__Group_7__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getChartAccess().getGroup_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group__7__Impl"


    // $ANTLR start "rule__Chart__Group__8"
    // InternalMyDsl.g:1941:1: rule__Chart__Group__8 : rule__Chart__Group__8__Impl rule__Chart__Group__9 ;
    public final void rule__Chart__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1945:1: ( rule__Chart__Group__8__Impl rule__Chart__Group__9 )
            // InternalMyDsl.g:1946:2: rule__Chart__Group__8__Impl rule__Chart__Group__9
            {
            pushFollow(FOLLOW_17);
            rule__Chart__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Chart__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group__8"


    // $ANTLR start "rule__Chart__Group__8__Impl"
    // InternalMyDsl.g:1953:1: rule__Chart__Group__8__Impl : ( ( rule__Chart__Group_8__0 )? ) ;
    public final void rule__Chart__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1957:1: ( ( ( rule__Chart__Group_8__0 )? ) )
            // InternalMyDsl.g:1958:1: ( ( rule__Chart__Group_8__0 )? )
            {
            // InternalMyDsl.g:1958:1: ( ( rule__Chart__Group_8__0 )? )
            // InternalMyDsl.g:1959:2: ( rule__Chart__Group_8__0 )?
            {
             before(grammarAccess.getChartAccess().getGroup_8()); 
            // InternalMyDsl.g:1960:2: ( rule__Chart__Group_8__0 )?
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==39) ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // InternalMyDsl.g:1960:3: rule__Chart__Group_8__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Chart__Group_8__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getChartAccess().getGroup_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group__8__Impl"


    // $ANTLR start "rule__Chart__Group__9"
    // InternalMyDsl.g:1968:1: rule__Chart__Group__9 : rule__Chart__Group__9__Impl rule__Chart__Group__10 ;
    public final void rule__Chart__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1972:1: ( rule__Chart__Group__9__Impl rule__Chart__Group__10 )
            // InternalMyDsl.g:1973:2: rule__Chart__Group__9__Impl rule__Chart__Group__10
            {
            pushFollow(FOLLOW_17);
            rule__Chart__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Chart__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group__9"


    // $ANTLR start "rule__Chart__Group__9__Impl"
    // InternalMyDsl.g:1980:1: rule__Chart__Group__9__Impl : ( ( rule__Chart__Group_9__0 )? ) ;
    public final void rule__Chart__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1984:1: ( ( ( rule__Chart__Group_9__0 )? ) )
            // InternalMyDsl.g:1985:1: ( ( rule__Chart__Group_9__0 )? )
            {
            // InternalMyDsl.g:1985:1: ( ( rule__Chart__Group_9__0 )? )
            // InternalMyDsl.g:1986:2: ( rule__Chart__Group_9__0 )?
            {
             before(grammarAccess.getChartAccess().getGroup_9()); 
            // InternalMyDsl.g:1987:2: ( rule__Chart__Group_9__0 )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==40) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // InternalMyDsl.g:1987:3: rule__Chart__Group_9__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Chart__Group_9__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getChartAccess().getGroup_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group__9__Impl"


    // $ANTLR start "rule__Chart__Group__10"
    // InternalMyDsl.g:1995:1: rule__Chart__Group__10 : rule__Chart__Group__10__Impl ;
    public final void rule__Chart__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1999:1: ( rule__Chart__Group__10__Impl )
            // InternalMyDsl.g:2000:2: rule__Chart__Group__10__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Chart__Group__10__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group__10"


    // $ANTLR start "rule__Chart__Group__10__Impl"
    // InternalMyDsl.g:2006:1: rule__Chart__Group__10__Impl : ( '}' ) ;
    public final void rule__Chart__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2010:1: ( ( '}' ) )
            // InternalMyDsl.g:2011:1: ( '}' )
            {
            // InternalMyDsl.g:2011:1: ( '}' )
            // InternalMyDsl.g:2012:2: '}'
            {
             before(grammarAccess.getChartAccess().getRightCurlyBracketKeyword_10()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getChartAccess().getRightCurlyBracketKeyword_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group__10__Impl"


    // $ANTLR start "rule__Chart__Group_4__0"
    // InternalMyDsl.g:2022:1: rule__Chart__Group_4__0 : rule__Chart__Group_4__0__Impl rule__Chart__Group_4__1 ;
    public final void rule__Chart__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2026:1: ( rule__Chart__Group_4__0__Impl rule__Chart__Group_4__1 )
            // InternalMyDsl.g:2027:2: rule__Chart__Group_4__0__Impl rule__Chart__Group_4__1
            {
            pushFollow(FOLLOW_18);
            rule__Chart__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Chart__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group_4__0"


    // $ANTLR start "rule__Chart__Group_4__0__Impl"
    // InternalMyDsl.g:2034:1: rule__Chart__Group_4__0__Impl : ( 'chartType' ) ;
    public final void rule__Chart__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2038:1: ( ( 'chartType' ) )
            // InternalMyDsl.g:2039:1: ( 'chartType' )
            {
            // InternalMyDsl.g:2039:1: ( 'chartType' )
            // InternalMyDsl.g:2040:2: 'chartType'
            {
             before(grammarAccess.getChartAccess().getChartTypeKeyword_4_0()); 
            match(input,35,FOLLOW_2); 
             after(grammarAccess.getChartAccess().getChartTypeKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group_4__0__Impl"


    // $ANTLR start "rule__Chart__Group_4__1"
    // InternalMyDsl.g:2049:1: rule__Chart__Group_4__1 : rule__Chart__Group_4__1__Impl ;
    public final void rule__Chart__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2053:1: ( rule__Chart__Group_4__1__Impl )
            // InternalMyDsl.g:2054:2: rule__Chart__Group_4__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Chart__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group_4__1"


    // $ANTLR start "rule__Chart__Group_4__1__Impl"
    // InternalMyDsl.g:2060:1: rule__Chart__Group_4__1__Impl : ( ( rule__Chart__ChartTypeAssignment_4_1 ) ) ;
    public final void rule__Chart__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2064:1: ( ( ( rule__Chart__ChartTypeAssignment_4_1 ) ) )
            // InternalMyDsl.g:2065:1: ( ( rule__Chart__ChartTypeAssignment_4_1 ) )
            {
            // InternalMyDsl.g:2065:1: ( ( rule__Chart__ChartTypeAssignment_4_1 ) )
            // InternalMyDsl.g:2066:2: ( rule__Chart__ChartTypeAssignment_4_1 )
            {
             before(grammarAccess.getChartAccess().getChartTypeAssignment_4_1()); 
            // InternalMyDsl.g:2067:2: ( rule__Chart__ChartTypeAssignment_4_1 )
            // InternalMyDsl.g:2067:3: rule__Chart__ChartTypeAssignment_4_1
            {
            pushFollow(FOLLOW_2);
            rule__Chart__ChartTypeAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getChartAccess().getChartTypeAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group_4__1__Impl"


    // $ANTLR start "rule__Chart__Group_5__0"
    // InternalMyDsl.g:2076:1: rule__Chart__Group_5__0 : rule__Chart__Group_5__0__Impl rule__Chart__Group_5__1 ;
    public final void rule__Chart__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2080:1: ( rule__Chart__Group_5__0__Impl rule__Chart__Group_5__1 )
            // InternalMyDsl.g:2081:2: rule__Chart__Group_5__0__Impl rule__Chart__Group_5__1
            {
            pushFollow(FOLLOW_11);
            rule__Chart__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Chart__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group_5__0"


    // $ANTLR start "rule__Chart__Group_5__0__Impl"
    // InternalMyDsl.g:2088:1: rule__Chart__Group_5__0__Impl : ( 'xLabel' ) ;
    public final void rule__Chart__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2092:1: ( ( 'xLabel' ) )
            // InternalMyDsl.g:2093:1: ( 'xLabel' )
            {
            // InternalMyDsl.g:2093:1: ( 'xLabel' )
            // InternalMyDsl.g:2094:2: 'xLabel'
            {
             before(grammarAccess.getChartAccess().getXLabelKeyword_5_0()); 
            match(input,36,FOLLOW_2); 
             after(grammarAccess.getChartAccess().getXLabelKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group_5__0__Impl"


    // $ANTLR start "rule__Chart__Group_5__1"
    // InternalMyDsl.g:2103:1: rule__Chart__Group_5__1 : rule__Chart__Group_5__1__Impl ;
    public final void rule__Chart__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2107:1: ( rule__Chart__Group_5__1__Impl )
            // InternalMyDsl.g:2108:2: rule__Chart__Group_5__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Chart__Group_5__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group_5__1"


    // $ANTLR start "rule__Chart__Group_5__1__Impl"
    // InternalMyDsl.g:2114:1: rule__Chart__Group_5__1__Impl : ( ( rule__Chart__XLabelAssignment_5_1 ) ) ;
    public final void rule__Chart__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2118:1: ( ( ( rule__Chart__XLabelAssignment_5_1 ) ) )
            // InternalMyDsl.g:2119:1: ( ( rule__Chart__XLabelAssignment_5_1 ) )
            {
            // InternalMyDsl.g:2119:1: ( ( rule__Chart__XLabelAssignment_5_1 ) )
            // InternalMyDsl.g:2120:2: ( rule__Chart__XLabelAssignment_5_1 )
            {
             before(grammarAccess.getChartAccess().getXLabelAssignment_5_1()); 
            // InternalMyDsl.g:2121:2: ( rule__Chart__XLabelAssignment_5_1 )
            // InternalMyDsl.g:2121:3: rule__Chart__XLabelAssignment_5_1
            {
            pushFollow(FOLLOW_2);
            rule__Chart__XLabelAssignment_5_1();

            state._fsp--;


            }

             after(grammarAccess.getChartAccess().getXLabelAssignment_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group_5__1__Impl"


    // $ANTLR start "rule__Chart__Group_6__0"
    // InternalMyDsl.g:2130:1: rule__Chart__Group_6__0 : rule__Chart__Group_6__0__Impl rule__Chart__Group_6__1 ;
    public final void rule__Chart__Group_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2134:1: ( rule__Chart__Group_6__0__Impl rule__Chart__Group_6__1 )
            // InternalMyDsl.g:2135:2: rule__Chart__Group_6__0__Impl rule__Chart__Group_6__1
            {
            pushFollow(FOLLOW_11);
            rule__Chart__Group_6__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Chart__Group_6__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group_6__0"


    // $ANTLR start "rule__Chart__Group_6__0__Impl"
    // InternalMyDsl.g:2142:1: rule__Chart__Group_6__0__Impl : ( 'yLabel' ) ;
    public final void rule__Chart__Group_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2146:1: ( ( 'yLabel' ) )
            // InternalMyDsl.g:2147:1: ( 'yLabel' )
            {
            // InternalMyDsl.g:2147:1: ( 'yLabel' )
            // InternalMyDsl.g:2148:2: 'yLabel'
            {
             before(grammarAccess.getChartAccess().getYLabelKeyword_6_0()); 
            match(input,37,FOLLOW_2); 
             after(grammarAccess.getChartAccess().getYLabelKeyword_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group_6__0__Impl"


    // $ANTLR start "rule__Chart__Group_6__1"
    // InternalMyDsl.g:2157:1: rule__Chart__Group_6__1 : rule__Chart__Group_6__1__Impl ;
    public final void rule__Chart__Group_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2161:1: ( rule__Chart__Group_6__1__Impl )
            // InternalMyDsl.g:2162:2: rule__Chart__Group_6__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Chart__Group_6__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group_6__1"


    // $ANTLR start "rule__Chart__Group_6__1__Impl"
    // InternalMyDsl.g:2168:1: rule__Chart__Group_6__1__Impl : ( ( rule__Chart__YLabelAssignment_6_1 ) ) ;
    public final void rule__Chart__Group_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2172:1: ( ( ( rule__Chart__YLabelAssignment_6_1 ) ) )
            // InternalMyDsl.g:2173:1: ( ( rule__Chart__YLabelAssignment_6_1 ) )
            {
            // InternalMyDsl.g:2173:1: ( ( rule__Chart__YLabelAssignment_6_1 ) )
            // InternalMyDsl.g:2174:2: ( rule__Chart__YLabelAssignment_6_1 )
            {
             before(grammarAccess.getChartAccess().getYLabelAssignment_6_1()); 
            // InternalMyDsl.g:2175:2: ( rule__Chart__YLabelAssignment_6_1 )
            // InternalMyDsl.g:2175:3: rule__Chart__YLabelAssignment_6_1
            {
            pushFollow(FOLLOW_2);
            rule__Chart__YLabelAssignment_6_1();

            state._fsp--;


            }

             after(grammarAccess.getChartAccess().getYLabelAssignment_6_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group_6__1__Impl"


    // $ANTLR start "rule__Chart__Group_7__0"
    // InternalMyDsl.g:2184:1: rule__Chart__Group_7__0 : rule__Chart__Group_7__0__Impl rule__Chart__Group_7__1 ;
    public final void rule__Chart__Group_7__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2188:1: ( rule__Chart__Group_7__0__Impl rule__Chart__Group_7__1 )
            // InternalMyDsl.g:2189:2: rule__Chart__Group_7__0__Impl rule__Chart__Group_7__1
            {
            pushFollow(FOLLOW_11);
            rule__Chart__Group_7__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Chart__Group_7__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group_7__0"


    // $ANTLR start "rule__Chart__Group_7__0__Impl"
    // InternalMyDsl.g:2196:1: rule__Chart__Group_7__0__Impl : ( 'title' ) ;
    public final void rule__Chart__Group_7__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2200:1: ( ( 'title' ) )
            // InternalMyDsl.g:2201:1: ( 'title' )
            {
            // InternalMyDsl.g:2201:1: ( 'title' )
            // InternalMyDsl.g:2202:2: 'title'
            {
             before(grammarAccess.getChartAccess().getTitleKeyword_7_0()); 
            match(input,38,FOLLOW_2); 
             after(grammarAccess.getChartAccess().getTitleKeyword_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group_7__0__Impl"


    // $ANTLR start "rule__Chart__Group_7__1"
    // InternalMyDsl.g:2211:1: rule__Chart__Group_7__1 : rule__Chart__Group_7__1__Impl ;
    public final void rule__Chart__Group_7__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2215:1: ( rule__Chart__Group_7__1__Impl )
            // InternalMyDsl.g:2216:2: rule__Chart__Group_7__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Chart__Group_7__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group_7__1"


    // $ANTLR start "rule__Chart__Group_7__1__Impl"
    // InternalMyDsl.g:2222:1: rule__Chart__Group_7__1__Impl : ( ( rule__Chart__TitleAssignment_7_1 ) ) ;
    public final void rule__Chart__Group_7__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2226:1: ( ( ( rule__Chart__TitleAssignment_7_1 ) ) )
            // InternalMyDsl.g:2227:1: ( ( rule__Chart__TitleAssignment_7_1 ) )
            {
            // InternalMyDsl.g:2227:1: ( ( rule__Chart__TitleAssignment_7_1 ) )
            // InternalMyDsl.g:2228:2: ( rule__Chart__TitleAssignment_7_1 )
            {
             before(grammarAccess.getChartAccess().getTitleAssignment_7_1()); 
            // InternalMyDsl.g:2229:2: ( rule__Chart__TitleAssignment_7_1 )
            // InternalMyDsl.g:2229:3: rule__Chart__TitleAssignment_7_1
            {
            pushFollow(FOLLOW_2);
            rule__Chart__TitleAssignment_7_1();

            state._fsp--;


            }

             after(grammarAccess.getChartAccess().getTitleAssignment_7_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group_7__1__Impl"


    // $ANTLR start "rule__Chart__Group_8__0"
    // InternalMyDsl.g:2238:1: rule__Chart__Group_8__0 : rule__Chart__Group_8__0__Impl rule__Chart__Group_8__1 ;
    public final void rule__Chart__Group_8__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2242:1: ( rule__Chart__Group_8__0__Impl rule__Chart__Group_8__1 )
            // InternalMyDsl.g:2243:2: rule__Chart__Group_8__0__Impl rule__Chart__Group_8__1
            {
            pushFollow(FOLLOW_11);
            rule__Chart__Group_8__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Chart__Group_8__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group_8__0"


    // $ANTLR start "rule__Chart__Group_8__0__Impl"
    // InternalMyDsl.g:2250:1: rule__Chart__Group_8__0__Impl : ( 'color' ) ;
    public final void rule__Chart__Group_8__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2254:1: ( ( 'color' ) )
            // InternalMyDsl.g:2255:1: ( 'color' )
            {
            // InternalMyDsl.g:2255:1: ( 'color' )
            // InternalMyDsl.g:2256:2: 'color'
            {
             before(grammarAccess.getChartAccess().getColorKeyword_8_0()); 
            match(input,39,FOLLOW_2); 
             after(grammarAccess.getChartAccess().getColorKeyword_8_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group_8__0__Impl"


    // $ANTLR start "rule__Chart__Group_8__1"
    // InternalMyDsl.g:2265:1: rule__Chart__Group_8__1 : rule__Chart__Group_8__1__Impl ;
    public final void rule__Chart__Group_8__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2269:1: ( rule__Chart__Group_8__1__Impl )
            // InternalMyDsl.g:2270:2: rule__Chart__Group_8__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Chart__Group_8__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group_8__1"


    // $ANTLR start "rule__Chart__Group_8__1__Impl"
    // InternalMyDsl.g:2276:1: rule__Chart__Group_8__1__Impl : ( ( rule__Chart__ColorAssignment_8_1 ) ) ;
    public final void rule__Chart__Group_8__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2280:1: ( ( ( rule__Chart__ColorAssignment_8_1 ) ) )
            // InternalMyDsl.g:2281:1: ( ( rule__Chart__ColorAssignment_8_1 ) )
            {
            // InternalMyDsl.g:2281:1: ( ( rule__Chart__ColorAssignment_8_1 ) )
            // InternalMyDsl.g:2282:2: ( rule__Chart__ColorAssignment_8_1 )
            {
             before(grammarAccess.getChartAccess().getColorAssignment_8_1()); 
            // InternalMyDsl.g:2283:2: ( rule__Chart__ColorAssignment_8_1 )
            // InternalMyDsl.g:2283:3: rule__Chart__ColorAssignment_8_1
            {
            pushFollow(FOLLOW_2);
            rule__Chart__ColorAssignment_8_1();

            state._fsp--;


            }

             after(grammarAccess.getChartAccess().getColorAssignment_8_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group_8__1__Impl"


    // $ANTLR start "rule__Chart__Group_9__0"
    // InternalMyDsl.g:2292:1: rule__Chart__Group_9__0 : rule__Chart__Group_9__0__Impl rule__Chart__Group_9__1 ;
    public final void rule__Chart__Group_9__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2296:1: ( rule__Chart__Group_9__0__Impl rule__Chart__Group_9__1 )
            // InternalMyDsl.g:2297:2: rule__Chart__Group_9__0__Impl rule__Chart__Group_9__1
            {
            pushFollow(FOLLOW_11);
            rule__Chart__Group_9__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Chart__Group_9__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group_9__0"


    // $ANTLR start "rule__Chart__Group_9__0__Impl"
    // InternalMyDsl.g:2304:1: rule__Chart__Group_9__0__Impl : ( 'variable' ) ;
    public final void rule__Chart__Group_9__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2308:1: ( ( 'variable' ) )
            // InternalMyDsl.g:2309:1: ( 'variable' )
            {
            // InternalMyDsl.g:2309:1: ( 'variable' )
            // InternalMyDsl.g:2310:2: 'variable'
            {
             before(grammarAccess.getChartAccess().getVariableKeyword_9_0()); 
            match(input,40,FOLLOW_2); 
             after(grammarAccess.getChartAccess().getVariableKeyword_9_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group_9__0__Impl"


    // $ANTLR start "rule__Chart__Group_9__1"
    // InternalMyDsl.g:2319:1: rule__Chart__Group_9__1 : rule__Chart__Group_9__1__Impl ;
    public final void rule__Chart__Group_9__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2323:1: ( rule__Chart__Group_9__1__Impl )
            // InternalMyDsl.g:2324:2: rule__Chart__Group_9__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Chart__Group_9__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group_9__1"


    // $ANTLR start "rule__Chart__Group_9__1__Impl"
    // InternalMyDsl.g:2330:1: rule__Chart__Group_9__1__Impl : ( ( rule__Chart__VariableAssignment_9_1 ) ) ;
    public final void rule__Chart__Group_9__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2334:1: ( ( ( rule__Chart__VariableAssignment_9_1 ) ) )
            // InternalMyDsl.g:2335:1: ( ( rule__Chart__VariableAssignment_9_1 ) )
            {
            // InternalMyDsl.g:2335:1: ( ( rule__Chart__VariableAssignment_9_1 ) )
            // InternalMyDsl.g:2336:2: ( rule__Chart__VariableAssignment_9_1 )
            {
             before(grammarAccess.getChartAccess().getVariableAssignment_9_1()); 
            // InternalMyDsl.g:2337:2: ( rule__Chart__VariableAssignment_9_1 )
            // InternalMyDsl.g:2337:3: rule__Chart__VariableAssignment_9_1
            {
            pushFollow(FOLLOW_2);
            rule__Chart__VariableAssignment_9_1();

            state._fsp--;


            }

             after(grammarAccess.getChartAccess().getVariableAssignment_9_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__Group_9__1__Impl"


    // $ANTLR start "rule__EInt__Group__0"
    // InternalMyDsl.g:2346:1: rule__EInt__Group__0 : rule__EInt__Group__0__Impl rule__EInt__Group__1 ;
    public final void rule__EInt__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2350:1: ( rule__EInt__Group__0__Impl rule__EInt__Group__1 )
            // InternalMyDsl.g:2351:2: rule__EInt__Group__0__Impl rule__EInt__Group__1
            {
            pushFollow(FOLLOW_14);
            rule__EInt__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EInt__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EInt__Group__0"


    // $ANTLR start "rule__EInt__Group__0__Impl"
    // InternalMyDsl.g:2358:1: rule__EInt__Group__0__Impl : ( ( '-' )? ) ;
    public final void rule__EInt__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2362:1: ( ( ( '-' )? ) )
            // InternalMyDsl.g:2363:1: ( ( '-' )? )
            {
            // InternalMyDsl.g:2363:1: ( ( '-' )? )
            // InternalMyDsl.g:2364:2: ( '-' )?
            {
             before(grammarAccess.getEIntAccess().getHyphenMinusKeyword_0()); 
            // InternalMyDsl.g:2365:2: ( '-' )?
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( (LA21_0==41) ) {
                alt21=1;
            }
            switch (alt21) {
                case 1 :
                    // InternalMyDsl.g:2365:3: '-'
                    {
                    match(input,41,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getEIntAccess().getHyphenMinusKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EInt__Group__0__Impl"


    // $ANTLR start "rule__EInt__Group__1"
    // InternalMyDsl.g:2373:1: rule__EInt__Group__1 : rule__EInt__Group__1__Impl ;
    public final void rule__EInt__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2377:1: ( rule__EInt__Group__1__Impl )
            // InternalMyDsl.g:2378:2: rule__EInt__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__EInt__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EInt__Group__1"


    // $ANTLR start "rule__EInt__Group__1__Impl"
    // InternalMyDsl.g:2384:1: rule__EInt__Group__1__Impl : ( RULE_INT ) ;
    public final void rule__EInt__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2388:1: ( ( RULE_INT ) )
            // InternalMyDsl.g:2389:1: ( RULE_INT )
            {
            // InternalMyDsl.g:2389:1: ( RULE_INT )
            // InternalMyDsl.g:2390:2: RULE_INT
            {
             before(grammarAccess.getEIntAccess().getINTTerminalRuleCall_1()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getEIntAccess().getINTTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EInt__Group__1__Impl"


    // $ANTLR start "rule__CsvExtract__NameFileAssignment_2_1"
    // InternalMyDsl.g:2400:1: rule__CsvExtract__NameFileAssignment_2_1 : ( ruleEString ) ;
    public final void rule__CsvExtract__NameFileAssignment_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2404:1: ( ( ruleEString ) )
            // InternalMyDsl.g:2405:2: ( ruleEString )
            {
            // InternalMyDsl.g:2405:2: ( ruleEString )
            // InternalMyDsl.g:2406:3: ruleEString
            {
             before(grammarAccess.getCsvExtractAccess().getNameFileEStringParserRuleCall_2_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getCsvExtractAccess().getNameFileEStringParserRuleCall_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__NameFileAssignment_2_1"


    // $ANTLR start "rule__CsvExtract__ColumnAssignment_5"
    // InternalMyDsl.g:2415:1: rule__CsvExtract__ColumnAssignment_5 : ( ruleColumn ) ;
    public final void rule__CsvExtract__ColumnAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2419:1: ( ( ruleColumn ) )
            // InternalMyDsl.g:2420:2: ( ruleColumn )
            {
            // InternalMyDsl.g:2420:2: ( ruleColumn )
            // InternalMyDsl.g:2421:3: ruleColumn
            {
             before(grammarAccess.getCsvExtractAccess().getColumnColumnParserRuleCall_5_0()); 
            pushFollow(FOLLOW_2);
            ruleColumn();

            state._fsp--;

             after(grammarAccess.getCsvExtractAccess().getColumnColumnParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__ColumnAssignment_5"


    // $ANTLR start "rule__CsvExtract__ColumnAssignment_6_1"
    // InternalMyDsl.g:2430:1: rule__CsvExtract__ColumnAssignment_6_1 : ( ruleColumn ) ;
    public final void rule__CsvExtract__ColumnAssignment_6_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2434:1: ( ( ruleColumn ) )
            // InternalMyDsl.g:2435:2: ( ruleColumn )
            {
            // InternalMyDsl.g:2435:2: ( ruleColumn )
            // InternalMyDsl.g:2436:3: ruleColumn
            {
             before(grammarAccess.getCsvExtractAccess().getColumnColumnParserRuleCall_6_1_0()); 
            pushFollow(FOLLOW_2);
            ruleColumn();

            state._fsp--;

             after(grammarAccess.getCsvExtractAccess().getColumnColumnParserRuleCall_6_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__ColumnAssignment_6_1"


    // $ANTLR start "rule__CsvExtract__FilterAssignment_8_2"
    // InternalMyDsl.g:2445:1: rule__CsvExtract__FilterAssignment_8_2 : ( ruleFilter ) ;
    public final void rule__CsvExtract__FilterAssignment_8_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2449:1: ( ( ruleFilter ) )
            // InternalMyDsl.g:2450:2: ( ruleFilter )
            {
            // InternalMyDsl.g:2450:2: ( ruleFilter )
            // InternalMyDsl.g:2451:3: ruleFilter
            {
             before(grammarAccess.getCsvExtractAccess().getFilterFilterParserRuleCall_8_2_0()); 
            pushFollow(FOLLOW_2);
            ruleFilter();

            state._fsp--;

             after(grammarAccess.getCsvExtractAccess().getFilterFilterParserRuleCall_8_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__FilterAssignment_8_2"


    // $ANTLR start "rule__CsvExtract__FilterAssignment_8_3_1"
    // InternalMyDsl.g:2460:1: rule__CsvExtract__FilterAssignment_8_3_1 : ( ruleFilter ) ;
    public final void rule__CsvExtract__FilterAssignment_8_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2464:1: ( ( ruleFilter ) )
            // InternalMyDsl.g:2465:2: ( ruleFilter )
            {
            // InternalMyDsl.g:2465:2: ( ruleFilter )
            // InternalMyDsl.g:2466:3: ruleFilter
            {
             before(grammarAccess.getCsvExtractAccess().getFilterFilterParserRuleCall_8_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleFilter();

            state._fsp--;

             after(grammarAccess.getCsvExtractAccess().getFilterFilterParserRuleCall_8_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__FilterAssignment_8_3_1"


    // $ANTLR start "rule__CsvExtract__ChartAssignment_11"
    // InternalMyDsl.g:2475:1: rule__CsvExtract__ChartAssignment_11 : ( ruleChart ) ;
    public final void rule__CsvExtract__ChartAssignment_11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2479:1: ( ( ruleChart ) )
            // InternalMyDsl.g:2480:2: ( ruleChart )
            {
            // InternalMyDsl.g:2480:2: ( ruleChart )
            // InternalMyDsl.g:2481:3: ruleChart
            {
             before(grammarAccess.getCsvExtractAccess().getChartChartParserRuleCall_11_0()); 
            pushFollow(FOLLOW_2);
            ruleChart();

            state._fsp--;

             after(grammarAccess.getCsvExtractAccess().getChartChartParserRuleCall_11_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__ChartAssignment_11"


    // $ANTLR start "rule__CsvExtract__ChartAssignment_12_1"
    // InternalMyDsl.g:2490:1: rule__CsvExtract__ChartAssignment_12_1 : ( ruleChart ) ;
    public final void rule__CsvExtract__ChartAssignment_12_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2494:1: ( ( ruleChart ) )
            // InternalMyDsl.g:2495:2: ( ruleChart )
            {
            // InternalMyDsl.g:2495:2: ( ruleChart )
            // InternalMyDsl.g:2496:3: ruleChart
            {
             before(grammarAccess.getCsvExtractAccess().getChartChartParserRuleCall_12_1_0()); 
            pushFollow(FOLLOW_2);
            ruleChart();

            state._fsp--;

             after(grammarAccess.getCsvExtractAccess().getChartChartParserRuleCall_12_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CsvExtract__ChartAssignment_12_1"


    // $ANTLR start "rule__Column__NameAssignment_2"
    // InternalMyDsl.g:2505:1: rule__Column__NameAssignment_2 : ( ruleEString ) ;
    public final void rule__Column__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2509:1: ( ( ruleEString ) )
            // InternalMyDsl.g:2510:2: ( ruleEString )
            {
            // InternalMyDsl.g:2510:2: ( ruleEString )
            // InternalMyDsl.g:2511:3: ruleEString
            {
             before(grammarAccess.getColumnAccess().getNameEStringParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getColumnAccess().getNameEStringParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Column__NameAssignment_2"


    // $ANTLR start "rule__Column__DataTypeAssignment_4_1"
    // InternalMyDsl.g:2520:1: rule__Column__DataTypeAssignment_4_1 : ( ruleEString ) ;
    public final void rule__Column__DataTypeAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2524:1: ( ( ruleEString ) )
            // InternalMyDsl.g:2525:2: ( ruleEString )
            {
            // InternalMyDsl.g:2525:2: ( ruleEString )
            // InternalMyDsl.g:2526:3: ruleEString
            {
             before(grammarAccess.getColumnAccess().getDataTypeEStringParserRuleCall_4_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getColumnAccess().getDataTypeEStringParserRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Column__DataTypeAssignment_4_1"


    // $ANTLR start "rule__Column__IndexAssignment_5_1"
    // InternalMyDsl.g:2535:1: rule__Column__IndexAssignment_5_1 : ( ruleEInt ) ;
    public final void rule__Column__IndexAssignment_5_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2539:1: ( ( ruleEInt ) )
            // InternalMyDsl.g:2540:2: ( ruleEInt )
            {
            // InternalMyDsl.g:2540:2: ( ruleEInt )
            // InternalMyDsl.g:2541:3: ruleEInt
            {
             before(grammarAccess.getColumnAccess().getIndexEIntParserRuleCall_5_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getColumnAccess().getIndexEIntParserRuleCall_5_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Column__IndexAssignment_5_1"


    // $ANTLR start "rule__Filter__ColumnNameAssignment_3_1"
    // InternalMyDsl.g:2550:1: rule__Filter__ColumnNameAssignment_3_1 : ( ruleEString ) ;
    public final void rule__Filter__ColumnNameAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2554:1: ( ( ruleEString ) )
            // InternalMyDsl.g:2555:2: ( ruleEString )
            {
            // InternalMyDsl.g:2555:2: ( ruleEString )
            // InternalMyDsl.g:2556:3: ruleEString
            {
             before(grammarAccess.getFilterAccess().getColumnNameEStringParserRuleCall_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getFilterAccess().getColumnNameEStringParserRuleCall_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__ColumnNameAssignment_3_1"


    // $ANTLR start "rule__Filter__RuleAssignment_4_1"
    // InternalMyDsl.g:2565:1: rule__Filter__RuleAssignment_4_1 : ( ruleFilterCompOperator ) ;
    public final void rule__Filter__RuleAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2569:1: ( ( ruleFilterCompOperator ) )
            // InternalMyDsl.g:2570:2: ( ruleFilterCompOperator )
            {
            // InternalMyDsl.g:2570:2: ( ruleFilterCompOperator )
            // InternalMyDsl.g:2571:3: ruleFilterCompOperator
            {
             before(grammarAccess.getFilterAccess().getRuleFilterCompOperatorEnumRuleCall_4_1_0()); 
            pushFollow(FOLLOW_2);
            ruleFilterCompOperator();

            state._fsp--;

             after(grammarAccess.getFilterAccess().getRuleFilterCompOperatorEnumRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__RuleAssignment_4_1"


    // $ANTLR start "rule__Filter__ValueAssignment_5_1"
    // InternalMyDsl.g:2580:1: rule__Filter__ValueAssignment_5_1 : ( ruleEString ) ;
    public final void rule__Filter__ValueAssignment_5_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2584:1: ( ( ruleEString ) )
            // InternalMyDsl.g:2585:2: ( ruleEString )
            {
            // InternalMyDsl.g:2585:2: ( ruleEString )
            // InternalMyDsl.g:2586:3: ruleEString
            {
             before(grammarAccess.getFilterAccess().getValueEStringParserRuleCall_5_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getFilterAccess().getValueEStringParserRuleCall_5_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Filter__ValueAssignment_5_1"


    // $ANTLR start "rule__Chart__LegendAssignment_1"
    // InternalMyDsl.g:2595:1: rule__Chart__LegendAssignment_1 : ( ( 'legend' ) ) ;
    public final void rule__Chart__LegendAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2599:1: ( ( ( 'legend' ) ) )
            // InternalMyDsl.g:2600:2: ( ( 'legend' ) )
            {
            // InternalMyDsl.g:2600:2: ( ( 'legend' ) )
            // InternalMyDsl.g:2601:3: ( 'legend' )
            {
             before(grammarAccess.getChartAccess().getLegendLegendKeyword_1_0()); 
            // InternalMyDsl.g:2602:3: ( 'legend' )
            // InternalMyDsl.g:2603:4: 'legend'
            {
             before(grammarAccess.getChartAccess().getLegendLegendKeyword_1_0()); 
            match(input,42,FOLLOW_2); 
             after(grammarAccess.getChartAccess().getLegendLegendKeyword_1_0()); 

            }

             after(grammarAccess.getChartAccess().getLegendLegendKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__LegendAssignment_1"


    // $ANTLR start "rule__Chart__ChartTypeAssignment_4_1"
    // InternalMyDsl.g:2614:1: rule__Chart__ChartTypeAssignment_4_1 : ( ruleChartType ) ;
    public final void rule__Chart__ChartTypeAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2618:1: ( ( ruleChartType ) )
            // InternalMyDsl.g:2619:2: ( ruleChartType )
            {
            // InternalMyDsl.g:2619:2: ( ruleChartType )
            // InternalMyDsl.g:2620:3: ruleChartType
            {
             before(grammarAccess.getChartAccess().getChartTypeChartTypeEnumRuleCall_4_1_0()); 
            pushFollow(FOLLOW_2);
            ruleChartType();

            state._fsp--;

             after(grammarAccess.getChartAccess().getChartTypeChartTypeEnumRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__ChartTypeAssignment_4_1"


    // $ANTLR start "rule__Chart__XLabelAssignment_5_1"
    // InternalMyDsl.g:2629:1: rule__Chart__XLabelAssignment_5_1 : ( ruleEString ) ;
    public final void rule__Chart__XLabelAssignment_5_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2633:1: ( ( ruleEString ) )
            // InternalMyDsl.g:2634:2: ( ruleEString )
            {
            // InternalMyDsl.g:2634:2: ( ruleEString )
            // InternalMyDsl.g:2635:3: ruleEString
            {
             before(grammarAccess.getChartAccess().getXLabelEStringParserRuleCall_5_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getChartAccess().getXLabelEStringParserRuleCall_5_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__XLabelAssignment_5_1"


    // $ANTLR start "rule__Chart__YLabelAssignment_6_1"
    // InternalMyDsl.g:2644:1: rule__Chart__YLabelAssignment_6_1 : ( ruleEString ) ;
    public final void rule__Chart__YLabelAssignment_6_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2648:1: ( ( ruleEString ) )
            // InternalMyDsl.g:2649:2: ( ruleEString )
            {
            // InternalMyDsl.g:2649:2: ( ruleEString )
            // InternalMyDsl.g:2650:3: ruleEString
            {
             before(grammarAccess.getChartAccess().getYLabelEStringParserRuleCall_6_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getChartAccess().getYLabelEStringParserRuleCall_6_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__YLabelAssignment_6_1"


    // $ANTLR start "rule__Chart__TitleAssignment_7_1"
    // InternalMyDsl.g:2659:1: rule__Chart__TitleAssignment_7_1 : ( ruleEString ) ;
    public final void rule__Chart__TitleAssignment_7_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2663:1: ( ( ruleEString ) )
            // InternalMyDsl.g:2664:2: ( ruleEString )
            {
            // InternalMyDsl.g:2664:2: ( ruleEString )
            // InternalMyDsl.g:2665:3: ruleEString
            {
             before(grammarAccess.getChartAccess().getTitleEStringParserRuleCall_7_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getChartAccess().getTitleEStringParserRuleCall_7_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__TitleAssignment_7_1"


    // $ANTLR start "rule__Chart__ColorAssignment_8_1"
    // InternalMyDsl.g:2674:1: rule__Chart__ColorAssignment_8_1 : ( ruleEString ) ;
    public final void rule__Chart__ColorAssignment_8_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2678:1: ( ( ruleEString ) )
            // InternalMyDsl.g:2679:2: ( ruleEString )
            {
            // InternalMyDsl.g:2679:2: ( ruleEString )
            // InternalMyDsl.g:2680:3: ruleEString
            {
             before(grammarAccess.getChartAccess().getColorEStringParserRuleCall_8_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getChartAccess().getColorEStringParserRuleCall_8_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__ColorAssignment_8_1"


    // $ANTLR start "rule__Chart__VariableAssignment_9_1"
    // InternalMyDsl.g:2689:1: rule__Chart__VariableAssignment_9_1 : ( ruleEString ) ;
    public final void rule__Chart__VariableAssignment_9_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2693:1: ( ( ruleEString ) )
            // InternalMyDsl.g:2694:2: ( ruleEString )
            {
            // InternalMyDsl.g:2694:2: ( ruleEString )
            // InternalMyDsl.g:2695:3: ruleEString
            {
             before(grammarAccess.getChartAccess().getVariableEStringParserRuleCall_9_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getChartAccess().getVariableEStringParserRuleCall_9_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Chart__VariableAssignment_9_1"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000001200000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000002400000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000002000002L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000004800000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000040400000000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000030400000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000020000000040L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000380400000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x000000000000F800L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x000001F800400000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000070000L});

}