package org.xtext.example.mydsl3.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.example.mydsl3.services.MyDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalMyDslParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'CsvExtract'", "'{'", "'nameFile'", "'column'", "','", "'}'", "'filter'", "'chart'", "'Column'", "'dataType'", "'index'", "'Filter'", "'columnName'", "'rule'", "'value'", "'legend'", "'Chart'", "'chartType'", "'xLabel'", "'yLabel'", "'title'", "'color'", "'variable'", "'-'", "'EQUAL'", "'LESS'", "'LESS_OR_EQUAL'", "'GREATER_OR_EQUAL'", "'GREATER'", "'BAR'", "'LINE'", "'SCATTER'"
    };
    public static final int RULE_STRING=4;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__37=37;
    public static final int T__16=16;
    public static final int T__38=38;
    public static final int T__17=17;
    public static final int T__39=39;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__33=33;
    public static final int T__12=12;
    public static final int T__34=34;
    public static final int T__13=13;
    public static final int T__35=35;
    public static final int T__14=14;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_ID=5;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__20=20;
    public static final int T__42=42;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalMyDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalMyDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalMyDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalMyDsl.g"; }



     	private MyDslGrammarAccess grammarAccess;

        public InternalMyDslParser(TokenStream input, MyDslGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "CsvExtract";
       	}

       	@Override
       	protected MyDslGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleCsvExtract"
    // InternalMyDsl.g:65:1: entryRuleCsvExtract returns [EObject current=null] : iv_ruleCsvExtract= ruleCsvExtract EOF ;
    public final EObject entryRuleCsvExtract() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCsvExtract = null;


        try {
            // InternalMyDsl.g:65:51: (iv_ruleCsvExtract= ruleCsvExtract EOF )
            // InternalMyDsl.g:66:2: iv_ruleCsvExtract= ruleCsvExtract EOF
            {
             newCompositeNode(grammarAccess.getCsvExtractRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCsvExtract=ruleCsvExtract();

            state._fsp--;

             current =iv_ruleCsvExtract; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCsvExtract"


    // $ANTLR start "ruleCsvExtract"
    // InternalMyDsl.g:72:1: ruleCsvExtract returns [EObject current=null] : (otherlv_0= 'CsvExtract' otherlv_1= '{' (otherlv_2= 'nameFile' ( (lv_nameFile_3_0= ruleEString ) ) )? otherlv_4= 'column' otherlv_5= '{' ( (lv_column_6_0= ruleColumn ) ) (otherlv_7= ',' ( (lv_column_8_0= ruleColumn ) ) )* otherlv_9= '}' (otherlv_10= 'filter' otherlv_11= '{' ( (lv_filter_12_0= ruleFilter ) ) (otherlv_13= ',' ( (lv_filter_14_0= ruleFilter ) ) )* otherlv_15= '}' )? otherlv_16= 'chart' otherlv_17= '{' ( (lv_chart_18_0= ruleChart ) ) (otherlv_19= ',' ( (lv_chart_20_0= ruleChart ) ) )* otherlv_21= '}' otherlv_22= '}' ) ;
    public final EObject ruleCsvExtract() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Token otherlv_13=null;
        Token otherlv_15=null;
        Token otherlv_16=null;
        Token otherlv_17=null;
        Token otherlv_19=null;
        Token otherlv_21=null;
        Token otherlv_22=null;
        AntlrDatatypeRuleToken lv_nameFile_3_0 = null;

        EObject lv_column_6_0 = null;

        EObject lv_column_8_0 = null;

        EObject lv_filter_12_0 = null;

        EObject lv_filter_14_0 = null;

        EObject lv_chart_18_0 = null;

        EObject lv_chart_20_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:78:2: ( (otherlv_0= 'CsvExtract' otherlv_1= '{' (otherlv_2= 'nameFile' ( (lv_nameFile_3_0= ruleEString ) ) )? otherlv_4= 'column' otherlv_5= '{' ( (lv_column_6_0= ruleColumn ) ) (otherlv_7= ',' ( (lv_column_8_0= ruleColumn ) ) )* otherlv_9= '}' (otherlv_10= 'filter' otherlv_11= '{' ( (lv_filter_12_0= ruleFilter ) ) (otherlv_13= ',' ( (lv_filter_14_0= ruleFilter ) ) )* otherlv_15= '}' )? otherlv_16= 'chart' otherlv_17= '{' ( (lv_chart_18_0= ruleChart ) ) (otherlv_19= ',' ( (lv_chart_20_0= ruleChart ) ) )* otherlv_21= '}' otherlv_22= '}' ) )
            // InternalMyDsl.g:79:2: (otherlv_0= 'CsvExtract' otherlv_1= '{' (otherlv_2= 'nameFile' ( (lv_nameFile_3_0= ruleEString ) ) )? otherlv_4= 'column' otherlv_5= '{' ( (lv_column_6_0= ruleColumn ) ) (otherlv_7= ',' ( (lv_column_8_0= ruleColumn ) ) )* otherlv_9= '}' (otherlv_10= 'filter' otherlv_11= '{' ( (lv_filter_12_0= ruleFilter ) ) (otherlv_13= ',' ( (lv_filter_14_0= ruleFilter ) ) )* otherlv_15= '}' )? otherlv_16= 'chart' otherlv_17= '{' ( (lv_chart_18_0= ruleChart ) ) (otherlv_19= ',' ( (lv_chart_20_0= ruleChart ) ) )* otherlv_21= '}' otherlv_22= '}' )
            {
            // InternalMyDsl.g:79:2: (otherlv_0= 'CsvExtract' otherlv_1= '{' (otherlv_2= 'nameFile' ( (lv_nameFile_3_0= ruleEString ) ) )? otherlv_4= 'column' otherlv_5= '{' ( (lv_column_6_0= ruleColumn ) ) (otherlv_7= ',' ( (lv_column_8_0= ruleColumn ) ) )* otherlv_9= '}' (otherlv_10= 'filter' otherlv_11= '{' ( (lv_filter_12_0= ruleFilter ) ) (otherlv_13= ',' ( (lv_filter_14_0= ruleFilter ) ) )* otherlv_15= '}' )? otherlv_16= 'chart' otherlv_17= '{' ( (lv_chart_18_0= ruleChart ) ) (otherlv_19= ',' ( (lv_chart_20_0= ruleChart ) ) )* otherlv_21= '}' otherlv_22= '}' )
            // InternalMyDsl.g:80:3: otherlv_0= 'CsvExtract' otherlv_1= '{' (otherlv_2= 'nameFile' ( (lv_nameFile_3_0= ruleEString ) ) )? otherlv_4= 'column' otherlv_5= '{' ( (lv_column_6_0= ruleColumn ) ) (otherlv_7= ',' ( (lv_column_8_0= ruleColumn ) ) )* otherlv_9= '}' (otherlv_10= 'filter' otherlv_11= '{' ( (lv_filter_12_0= ruleFilter ) ) (otherlv_13= ',' ( (lv_filter_14_0= ruleFilter ) ) )* otherlv_15= '}' )? otherlv_16= 'chart' otherlv_17= '{' ( (lv_chart_18_0= ruleChart ) ) (otherlv_19= ',' ( (lv_chart_20_0= ruleChart ) ) )* otherlv_21= '}' otherlv_22= '}'
            {
            otherlv_0=(Token)match(input,11,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getCsvExtractAccess().getCsvExtractKeyword_0());
            		
            otherlv_1=(Token)match(input,12,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getCsvExtractAccess().getLeftCurlyBracketKeyword_1());
            		
            // InternalMyDsl.g:88:3: (otherlv_2= 'nameFile' ( (lv_nameFile_3_0= ruleEString ) ) )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==13) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // InternalMyDsl.g:89:4: otherlv_2= 'nameFile' ( (lv_nameFile_3_0= ruleEString ) )
                    {
                    otherlv_2=(Token)match(input,13,FOLLOW_5); 

                    				newLeafNode(otherlv_2, grammarAccess.getCsvExtractAccess().getNameFileKeyword_2_0());
                    			
                    // InternalMyDsl.g:93:4: ( (lv_nameFile_3_0= ruleEString ) )
                    // InternalMyDsl.g:94:5: (lv_nameFile_3_0= ruleEString )
                    {
                    // InternalMyDsl.g:94:5: (lv_nameFile_3_0= ruleEString )
                    // InternalMyDsl.g:95:6: lv_nameFile_3_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getCsvExtractAccess().getNameFileEStringParserRuleCall_2_1_0());
                    					
                    pushFollow(FOLLOW_6);
                    lv_nameFile_3_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getCsvExtractRule());
                    						}
                    						set(
                    							current,
                    							"nameFile",
                    							lv_nameFile_3_0,
                    							"org.xtext.example.mydsl3.MyDsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_4=(Token)match(input,14,FOLLOW_3); 

            			newLeafNode(otherlv_4, grammarAccess.getCsvExtractAccess().getColumnKeyword_3());
            		
            otherlv_5=(Token)match(input,12,FOLLOW_7); 

            			newLeafNode(otherlv_5, grammarAccess.getCsvExtractAccess().getLeftCurlyBracketKeyword_4());
            		
            // InternalMyDsl.g:121:3: ( (lv_column_6_0= ruleColumn ) )
            // InternalMyDsl.g:122:4: (lv_column_6_0= ruleColumn )
            {
            // InternalMyDsl.g:122:4: (lv_column_6_0= ruleColumn )
            // InternalMyDsl.g:123:5: lv_column_6_0= ruleColumn
            {

            					newCompositeNode(grammarAccess.getCsvExtractAccess().getColumnColumnParserRuleCall_5_0());
            				
            pushFollow(FOLLOW_8);
            lv_column_6_0=ruleColumn();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getCsvExtractRule());
            					}
            					add(
            						current,
            						"column",
            						lv_column_6_0,
            						"org.xtext.example.mydsl3.MyDsl.Column");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMyDsl.g:140:3: (otherlv_7= ',' ( (lv_column_8_0= ruleColumn ) ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==15) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalMyDsl.g:141:4: otherlv_7= ',' ( (lv_column_8_0= ruleColumn ) )
            	    {
            	    otherlv_7=(Token)match(input,15,FOLLOW_7); 

            	    				newLeafNode(otherlv_7, grammarAccess.getCsvExtractAccess().getCommaKeyword_6_0());
            	    			
            	    // InternalMyDsl.g:145:4: ( (lv_column_8_0= ruleColumn ) )
            	    // InternalMyDsl.g:146:5: (lv_column_8_0= ruleColumn )
            	    {
            	    // InternalMyDsl.g:146:5: (lv_column_8_0= ruleColumn )
            	    // InternalMyDsl.g:147:6: lv_column_8_0= ruleColumn
            	    {

            	    						newCompositeNode(grammarAccess.getCsvExtractAccess().getColumnColumnParserRuleCall_6_1_0());
            	    					
            	    pushFollow(FOLLOW_8);
            	    lv_column_8_0=ruleColumn();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getCsvExtractRule());
            	    						}
            	    						add(
            	    							current,
            	    							"column",
            	    							lv_column_8_0,
            	    							"org.xtext.example.mydsl3.MyDsl.Column");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

            otherlv_9=(Token)match(input,16,FOLLOW_9); 

            			newLeafNode(otherlv_9, grammarAccess.getCsvExtractAccess().getRightCurlyBracketKeyword_7());
            		
            // InternalMyDsl.g:169:3: (otherlv_10= 'filter' otherlv_11= '{' ( (lv_filter_12_0= ruleFilter ) ) (otherlv_13= ',' ( (lv_filter_14_0= ruleFilter ) ) )* otherlv_15= '}' )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==17) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // InternalMyDsl.g:170:4: otherlv_10= 'filter' otherlv_11= '{' ( (lv_filter_12_0= ruleFilter ) ) (otherlv_13= ',' ( (lv_filter_14_0= ruleFilter ) ) )* otherlv_15= '}'
                    {
                    otherlv_10=(Token)match(input,17,FOLLOW_3); 

                    				newLeafNode(otherlv_10, grammarAccess.getCsvExtractAccess().getFilterKeyword_8_0());
                    			
                    otherlv_11=(Token)match(input,12,FOLLOW_10); 

                    				newLeafNode(otherlv_11, grammarAccess.getCsvExtractAccess().getLeftCurlyBracketKeyword_8_1());
                    			
                    // InternalMyDsl.g:178:4: ( (lv_filter_12_0= ruleFilter ) )
                    // InternalMyDsl.g:179:5: (lv_filter_12_0= ruleFilter )
                    {
                    // InternalMyDsl.g:179:5: (lv_filter_12_0= ruleFilter )
                    // InternalMyDsl.g:180:6: lv_filter_12_0= ruleFilter
                    {

                    						newCompositeNode(grammarAccess.getCsvExtractAccess().getFilterFilterParserRuleCall_8_2_0());
                    					
                    pushFollow(FOLLOW_8);
                    lv_filter_12_0=ruleFilter();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getCsvExtractRule());
                    						}
                    						add(
                    							current,
                    							"filter",
                    							lv_filter_12_0,
                    							"org.xtext.example.mydsl3.MyDsl.Filter");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMyDsl.g:197:4: (otherlv_13= ',' ( (lv_filter_14_0= ruleFilter ) ) )*
                    loop3:
                    do {
                        int alt3=2;
                        int LA3_0 = input.LA(1);

                        if ( (LA3_0==15) ) {
                            alt3=1;
                        }


                        switch (alt3) {
                    	case 1 :
                    	    // InternalMyDsl.g:198:5: otherlv_13= ',' ( (lv_filter_14_0= ruleFilter ) )
                    	    {
                    	    otherlv_13=(Token)match(input,15,FOLLOW_10); 

                    	    					newLeafNode(otherlv_13, grammarAccess.getCsvExtractAccess().getCommaKeyword_8_3_0());
                    	    				
                    	    // InternalMyDsl.g:202:5: ( (lv_filter_14_0= ruleFilter ) )
                    	    // InternalMyDsl.g:203:6: (lv_filter_14_0= ruleFilter )
                    	    {
                    	    // InternalMyDsl.g:203:6: (lv_filter_14_0= ruleFilter )
                    	    // InternalMyDsl.g:204:7: lv_filter_14_0= ruleFilter
                    	    {

                    	    							newCompositeNode(grammarAccess.getCsvExtractAccess().getFilterFilterParserRuleCall_8_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_8);
                    	    lv_filter_14_0=ruleFilter();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getCsvExtractRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"filter",
                    	    								lv_filter_14_0,
                    	    								"org.xtext.example.mydsl3.MyDsl.Filter");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop3;
                        }
                    } while (true);

                    otherlv_15=(Token)match(input,16,FOLLOW_11); 

                    				newLeafNode(otherlv_15, grammarAccess.getCsvExtractAccess().getRightCurlyBracketKeyword_8_4());
                    			

                    }
                    break;

            }

            otherlv_16=(Token)match(input,18,FOLLOW_3); 

            			newLeafNode(otherlv_16, grammarAccess.getCsvExtractAccess().getChartKeyword_9());
            		
            otherlv_17=(Token)match(input,12,FOLLOW_12); 

            			newLeafNode(otherlv_17, grammarAccess.getCsvExtractAccess().getLeftCurlyBracketKeyword_10());
            		
            // InternalMyDsl.g:235:3: ( (lv_chart_18_0= ruleChart ) )
            // InternalMyDsl.g:236:4: (lv_chart_18_0= ruleChart )
            {
            // InternalMyDsl.g:236:4: (lv_chart_18_0= ruleChart )
            // InternalMyDsl.g:237:5: lv_chart_18_0= ruleChart
            {

            					newCompositeNode(grammarAccess.getCsvExtractAccess().getChartChartParserRuleCall_11_0());
            				
            pushFollow(FOLLOW_8);
            lv_chart_18_0=ruleChart();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getCsvExtractRule());
            					}
            					add(
            						current,
            						"chart",
            						lv_chart_18_0,
            						"org.xtext.example.mydsl3.MyDsl.Chart");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMyDsl.g:254:3: (otherlv_19= ',' ( (lv_chart_20_0= ruleChart ) ) )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==15) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // InternalMyDsl.g:255:4: otherlv_19= ',' ( (lv_chart_20_0= ruleChart ) )
            	    {
            	    otherlv_19=(Token)match(input,15,FOLLOW_12); 

            	    				newLeafNode(otherlv_19, grammarAccess.getCsvExtractAccess().getCommaKeyword_12_0());
            	    			
            	    // InternalMyDsl.g:259:4: ( (lv_chart_20_0= ruleChart ) )
            	    // InternalMyDsl.g:260:5: (lv_chart_20_0= ruleChart )
            	    {
            	    // InternalMyDsl.g:260:5: (lv_chart_20_0= ruleChart )
            	    // InternalMyDsl.g:261:6: lv_chart_20_0= ruleChart
            	    {

            	    						newCompositeNode(grammarAccess.getCsvExtractAccess().getChartChartParserRuleCall_12_1_0());
            	    					
            	    pushFollow(FOLLOW_8);
            	    lv_chart_20_0=ruleChart();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getCsvExtractRule());
            	    						}
            	    						add(
            	    							current,
            	    							"chart",
            	    							lv_chart_20_0,
            	    							"org.xtext.example.mydsl3.MyDsl.Chart");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

            otherlv_21=(Token)match(input,16,FOLLOW_13); 

            			newLeafNode(otherlv_21, grammarAccess.getCsvExtractAccess().getRightCurlyBracketKeyword_13());
            		
            otherlv_22=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_22, grammarAccess.getCsvExtractAccess().getRightCurlyBracketKeyword_14());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCsvExtract"


    // $ANTLR start "entryRuleEString"
    // InternalMyDsl.g:291:1: entryRuleEString returns [String current=null] : iv_ruleEString= ruleEString EOF ;
    public final String entryRuleEString() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEString = null;


        try {
            // InternalMyDsl.g:291:47: (iv_ruleEString= ruleEString EOF )
            // InternalMyDsl.g:292:2: iv_ruleEString= ruleEString EOF
            {
             newCompositeNode(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEString=ruleEString();

            state._fsp--;

             current =iv_ruleEString.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalMyDsl.g:298:1: ruleEString returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) ;
    public final AntlrDatatypeRuleToken ruleEString() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;
        Token this_ID_1=null;


        	enterRule();

        try {
            // InternalMyDsl.g:304:2: ( (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) )
            // InternalMyDsl.g:305:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            {
            // InternalMyDsl.g:305:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==RULE_STRING) ) {
                alt6=1;
            }
            else if ( (LA6_0==RULE_ID) ) {
                alt6=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // InternalMyDsl.g:306:3: this_STRING_0= RULE_STRING
                    {
                    this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    			current.merge(this_STRING_0);
                    		

                    			newLeafNode(this_STRING_0, grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:314:3: this_ID_1= RULE_ID
                    {
                    this_ID_1=(Token)match(input,RULE_ID,FOLLOW_2); 

                    			current.merge(this_ID_1);
                    		

                    			newLeafNode(this_ID_1, grammarAccess.getEStringAccess().getIDTerminalRuleCall_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEString"


    // $ANTLR start "entryRuleColumn"
    // InternalMyDsl.g:325:1: entryRuleColumn returns [EObject current=null] : iv_ruleColumn= ruleColumn EOF ;
    public final EObject entryRuleColumn() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleColumn = null;


        try {
            // InternalMyDsl.g:325:47: (iv_ruleColumn= ruleColumn EOF )
            // InternalMyDsl.g:326:2: iv_ruleColumn= ruleColumn EOF
            {
             newCompositeNode(grammarAccess.getColumnRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleColumn=ruleColumn();

            state._fsp--;

             current =iv_ruleColumn; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleColumn"


    // $ANTLR start "ruleColumn"
    // InternalMyDsl.g:332:1: ruleColumn returns [EObject current=null] : ( () otherlv_1= 'Column' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'dataType' ( (lv_dataType_5_0= ruleEString ) ) )? (otherlv_6= 'index' ( (lv_index_7_0= ruleEInt ) ) )? otherlv_8= '}' ) ;
    public final EObject ruleColumn() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        AntlrDatatypeRuleToken lv_name_2_0 = null;

        AntlrDatatypeRuleToken lv_dataType_5_0 = null;

        AntlrDatatypeRuleToken lv_index_7_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:338:2: ( ( () otherlv_1= 'Column' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'dataType' ( (lv_dataType_5_0= ruleEString ) ) )? (otherlv_6= 'index' ( (lv_index_7_0= ruleEInt ) ) )? otherlv_8= '}' ) )
            // InternalMyDsl.g:339:2: ( () otherlv_1= 'Column' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'dataType' ( (lv_dataType_5_0= ruleEString ) ) )? (otherlv_6= 'index' ( (lv_index_7_0= ruleEInt ) ) )? otherlv_8= '}' )
            {
            // InternalMyDsl.g:339:2: ( () otherlv_1= 'Column' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'dataType' ( (lv_dataType_5_0= ruleEString ) ) )? (otherlv_6= 'index' ( (lv_index_7_0= ruleEInt ) ) )? otherlv_8= '}' )
            // InternalMyDsl.g:340:3: () otherlv_1= 'Column' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'dataType' ( (lv_dataType_5_0= ruleEString ) ) )? (otherlv_6= 'index' ( (lv_index_7_0= ruleEInt ) ) )? otherlv_8= '}'
            {
            // InternalMyDsl.g:340:3: ()
            // InternalMyDsl.g:341:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getColumnAccess().getColumnAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,19,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getColumnAccess().getColumnKeyword_1());
            		
            // InternalMyDsl.g:351:3: ( (lv_name_2_0= ruleEString ) )
            // InternalMyDsl.g:352:4: (lv_name_2_0= ruleEString )
            {
            // InternalMyDsl.g:352:4: (lv_name_2_0= ruleEString )
            // InternalMyDsl.g:353:5: lv_name_2_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getColumnAccess().getNameEStringParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_3);
            lv_name_2_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getColumnRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_2_0,
            						"org.xtext.example.mydsl3.MyDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,12,FOLLOW_14); 

            			newLeafNode(otherlv_3, grammarAccess.getColumnAccess().getLeftCurlyBracketKeyword_3());
            		
            // InternalMyDsl.g:374:3: (otherlv_4= 'dataType' ( (lv_dataType_5_0= ruleEString ) ) )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==20) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalMyDsl.g:375:4: otherlv_4= 'dataType' ( (lv_dataType_5_0= ruleEString ) )
                    {
                    otherlv_4=(Token)match(input,20,FOLLOW_5); 

                    				newLeafNode(otherlv_4, grammarAccess.getColumnAccess().getDataTypeKeyword_4_0());
                    			
                    // InternalMyDsl.g:379:4: ( (lv_dataType_5_0= ruleEString ) )
                    // InternalMyDsl.g:380:5: (lv_dataType_5_0= ruleEString )
                    {
                    // InternalMyDsl.g:380:5: (lv_dataType_5_0= ruleEString )
                    // InternalMyDsl.g:381:6: lv_dataType_5_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getColumnAccess().getDataTypeEStringParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_15);
                    lv_dataType_5_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getColumnRule());
                    						}
                    						set(
                    							current,
                    							"dataType",
                    							lv_dataType_5_0,
                    							"org.xtext.example.mydsl3.MyDsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyDsl.g:399:3: (otherlv_6= 'index' ( (lv_index_7_0= ruleEInt ) ) )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==21) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalMyDsl.g:400:4: otherlv_6= 'index' ( (lv_index_7_0= ruleEInt ) )
                    {
                    otherlv_6=(Token)match(input,21,FOLLOW_16); 

                    				newLeafNode(otherlv_6, grammarAccess.getColumnAccess().getIndexKeyword_5_0());
                    			
                    // InternalMyDsl.g:404:4: ( (lv_index_7_0= ruleEInt ) )
                    // InternalMyDsl.g:405:5: (lv_index_7_0= ruleEInt )
                    {
                    // InternalMyDsl.g:405:5: (lv_index_7_0= ruleEInt )
                    // InternalMyDsl.g:406:6: lv_index_7_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getColumnAccess().getIndexEIntParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_13);
                    lv_index_7_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getColumnRule());
                    						}
                    						set(
                    							current,
                    							"index",
                    							lv_index_7_0,
                    							"org.xtext.example.mydsl3.MyDsl.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_8=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_8, grammarAccess.getColumnAccess().getRightCurlyBracketKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleColumn"


    // $ANTLR start "entryRuleFilter"
    // InternalMyDsl.g:432:1: entryRuleFilter returns [EObject current=null] : iv_ruleFilter= ruleFilter EOF ;
    public final EObject entryRuleFilter() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFilter = null;


        try {
            // InternalMyDsl.g:432:47: (iv_ruleFilter= ruleFilter EOF )
            // InternalMyDsl.g:433:2: iv_ruleFilter= ruleFilter EOF
            {
             newCompositeNode(grammarAccess.getFilterRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFilter=ruleFilter();

            state._fsp--;

             current =iv_ruleFilter; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFilter"


    // $ANTLR start "ruleFilter"
    // InternalMyDsl.g:439:1: ruleFilter returns [EObject current=null] : ( () otherlv_1= 'Filter' otherlv_2= '{' (otherlv_3= 'columnName' ( (lv_columnName_4_0= ruleEString ) ) )? (otherlv_5= 'rule' ( (lv_rule_6_0= ruleFilterCompOperator ) ) )? (otherlv_7= 'value' ( (lv_value_8_0= ruleEString ) ) )? otherlv_9= '}' ) ;
    public final EObject ruleFilter() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        AntlrDatatypeRuleToken lv_columnName_4_0 = null;

        Enumerator lv_rule_6_0 = null;

        AntlrDatatypeRuleToken lv_value_8_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:445:2: ( ( () otherlv_1= 'Filter' otherlv_2= '{' (otherlv_3= 'columnName' ( (lv_columnName_4_0= ruleEString ) ) )? (otherlv_5= 'rule' ( (lv_rule_6_0= ruleFilterCompOperator ) ) )? (otherlv_7= 'value' ( (lv_value_8_0= ruleEString ) ) )? otherlv_9= '}' ) )
            // InternalMyDsl.g:446:2: ( () otherlv_1= 'Filter' otherlv_2= '{' (otherlv_3= 'columnName' ( (lv_columnName_4_0= ruleEString ) ) )? (otherlv_5= 'rule' ( (lv_rule_6_0= ruleFilterCompOperator ) ) )? (otherlv_7= 'value' ( (lv_value_8_0= ruleEString ) ) )? otherlv_9= '}' )
            {
            // InternalMyDsl.g:446:2: ( () otherlv_1= 'Filter' otherlv_2= '{' (otherlv_3= 'columnName' ( (lv_columnName_4_0= ruleEString ) ) )? (otherlv_5= 'rule' ( (lv_rule_6_0= ruleFilterCompOperator ) ) )? (otherlv_7= 'value' ( (lv_value_8_0= ruleEString ) ) )? otherlv_9= '}' )
            // InternalMyDsl.g:447:3: () otherlv_1= 'Filter' otherlv_2= '{' (otherlv_3= 'columnName' ( (lv_columnName_4_0= ruleEString ) ) )? (otherlv_5= 'rule' ( (lv_rule_6_0= ruleFilterCompOperator ) ) )? (otherlv_7= 'value' ( (lv_value_8_0= ruleEString ) ) )? otherlv_9= '}'
            {
            // InternalMyDsl.g:447:3: ()
            // InternalMyDsl.g:448:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getFilterAccess().getFilterAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,22,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getFilterAccess().getFilterKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_17); 

            			newLeafNode(otherlv_2, grammarAccess.getFilterAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalMyDsl.g:462:3: (otherlv_3= 'columnName' ( (lv_columnName_4_0= ruleEString ) ) )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==23) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalMyDsl.g:463:4: otherlv_3= 'columnName' ( (lv_columnName_4_0= ruleEString ) )
                    {
                    otherlv_3=(Token)match(input,23,FOLLOW_5); 

                    				newLeafNode(otherlv_3, grammarAccess.getFilterAccess().getColumnNameKeyword_3_0());
                    			
                    // InternalMyDsl.g:467:4: ( (lv_columnName_4_0= ruleEString ) )
                    // InternalMyDsl.g:468:5: (lv_columnName_4_0= ruleEString )
                    {
                    // InternalMyDsl.g:468:5: (lv_columnName_4_0= ruleEString )
                    // InternalMyDsl.g:469:6: lv_columnName_4_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getFilterAccess().getColumnNameEStringParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_18);
                    lv_columnName_4_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getFilterRule());
                    						}
                    						set(
                    							current,
                    							"columnName",
                    							lv_columnName_4_0,
                    							"org.xtext.example.mydsl3.MyDsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyDsl.g:487:3: (otherlv_5= 'rule' ( (lv_rule_6_0= ruleFilterCompOperator ) ) )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==24) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalMyDsl.g:488:4: otherlv_5= 'rule' ( (lv_rule_6_0= ruleFilterCompOperator ) )
                    {
                    otherlv_5=(Token)match(input,24,FOLLOW_19); 

                    				newLeafNode(otherlv_5, grammarAccess.getFilterAccess().getRuleKeyword_4_0());
                    			
                    // InternalMyDsl.g:492:4: ( (lv_rule_6_0= ruleFilterCompOperator ) )
                    // InternalMyDsl.g:493:5: (lv_rule_6_0= ruleFilterCompOperator )
                    {
                    // InternalMyDsl.g:493:5: (lv_rule_6_0= ruleFilterCompOperator )
                    // InternalMyDsl.g:494:6: lv_rule_6_0= ruleFilterCompOperator
                    {

                    						newCompositeNode(grammarAccess.getFilterAccess().getRuleFilterCompOperatorEnumRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_20);
                    lv_rule_6_0=ruleFilterCompOperator();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getFilterRule());
                    						}
                    						set(
                    							current,
                    							"rule",
                    							lv_rule_6_0,
                    							"org.xtext.example.mydsl3.MyDsl.FilterCompOperator");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyDsl.g:512:3: (otherlv_7= 'value' ( (lv_value_8_0= ruleEString ) ) )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==25) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // InternalMyDsl.g:513:4: otherlv_7= 'value' ( (lv_value_8_0= ruleEString ) )
                    {
                    otherlv_7=(Token)match(input,25,FOLLOW_5); 

                    				newLeafNode(otherlv_7, grammarAccess.getFilterAccess().getValueKeyword_5_0());
                    			
                    // InternalMyDsl.g:517:4: ( (lv_value_8_0= ruleEString ) )
                    // InternalMyDsl.g:518:5: (lv_value_8_0= ruleEString )
                    {
                    // InternalMyDsl.g:518:5: (lv_value_8_0= ruleEString )
                    // InternalMyDsl.g:519:6: lv_value_8_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getFilterAccess().getValueEStringParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_13);
                    lv_value_8_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getFilterRule());
                    						}
                    						set(
                    							current,
                    							"value",
                    							lv_value_8_0,
                    							"org.xtext.example.mydsl3.MyDsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_9=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_9, grammarAccess.getFilterAccess().getRightCurlyBracketKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFilter"


    // $ANTLR start "entryRuleChart"
    // InternalMyDsl.g:545:1: entryRuleChart returns [EObject current=null] : iv_ruleChart= ruleChart EOF ;
    public final EObject entryRuleChart() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleChart = null;


        try {
            // InternalMyDsl.g:545:46: (iv_ruleChart= ruleChart EOF )
            // InternalMyDsl.g:546:2: iv_ruleChart= ruleChart EOF
            {
             newCompositeNode(grammarAccess.getChartRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleChart=ruleChart();

            state._fsp--;

             current =iv_ruleChart; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleChart"


    // $ANTLR start "ruleChart"
    // InternalMyDsl.g:552:1: ruleChart returns [EObject current=null] : ( () ( (lv_legend_1_0= 'legend' ) )? otherlv_2= 'Chart' otherlv_3= '{' (otherlv_4= 'chartType' ( (lv_chartType_5_0= ruleChartType ) ) )? (otherlv_6= 'xLabel' ( (lv_xLabel_7_0= ruleEString ) ) )? (otherlv_8= 'yLabel' ( (lv_yLabel_9_0= ruleEString ) ) )? (otherlv_10= 'title' ( (lv_title_11_0= ruleEString ) ) )? (otherlv_12= 'color' ( (lv_color_13_0= ruleEString ) ) )? (otherlv_14= 'variable' ( (lv_variable_15_0= ruleEString ) ) )? otherlv_16= '}' ) ;
    public final EObject ruleChart() throws RecognitionException {
        EObject current = null;

        Token lv_legend_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        Token otherlv_16=null;
        Enumerator lv_chartType_5_0 = null;

        AntlrDatatypeRuleToken lv_xLabel_7_0 = null;

        AntlrDatatypeRuleToken lv_yLabel_9_0 = null;

        AntlrDatatypeRuleToken lv_title_11_0 = null;

        AntlrDatatypeRuleToken lv_color_13_0 = null;

        AntlrDatatypeRuleToken lv_variable_15_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:558:2: ( ( () ( (lv_legend_1_0= 'legend' ) )? otherlv_2= 'Chart' otherlv_3= '{' (otherlv_4= 'chartType' ( (lv_chartType_5_0= ruleChartType ) ) )? (otherlv_6= 'xLabel' ( (lv_xLabel_7_0= ruleEString ) ) )? (otherlv_8= 'yLabel' ( (lv_yLabel_9_0= ruleEString ) ) )? (otherlv_10= 'title' ( (lv_title_11_0= ruleEString ) ) )? (otherlv_12= 'color' ( (lv_color_13_0= ruleEString ) ) )? (otherlv_14= 'variable' ( (lv_variable_15_0= ruleEString ) ) )? otherlv_16= '}' ) )
            // InternalMyDsl.g:559:2: ( () ( (lv_legend_1_0= 'legend' ) )? otherlv_2= 'Chart' otherlv_3= '{' (otherlv_4= 'chartType' ( (lv_chartType_5_0= ruleChartType ) ) )? (otherlv_6= 'xLabel' ( (lv_xLabel_7_0= ruleEString ) ) )? (otherlv_8= 'yLabel' ( (lv_yLabel_9_0= ruleEString ) ) )? (otherlv_10= 'title' ( (lv_title_11_0= ruleEString ) ) )? (otherlv_12= 'color' ( (lv_color_13_0= ruleEString ) ) )? (otherlv_14= 'variable' ( (lv_variable_15_0= ruleEString ) ) )? otherlv_16= '}' )
            {
            // InternalMyDsl.g:559:2: ( () ( (lv_legend_1_0= 'legend' ) )? otherlv_2= 'Chart' otherlv_3= '{' (otherlv_4= 'chartType' ( (lv_chartType_5_0= ruleChartType ) ) )? (otherlv_6= 'xLabel' ( (lv_xLabel_7_0= ruleEString ) ) )? (otherlv_8= 'yLabel' ( (lv_yLabel_9_0= ruleEString ) ) )? (otherlv_10= 'title' ( (lv_title_11_0= ruleEString ) ) )? (otherlv_12= 'color' ( (lv_color_13_0= ruleEString ) ) )? (otherlv_14= 'variable' ( (lv_variable_15_0= ruleEString ) ) )? otherlv_16= '}' )
            // InternalMyDsl.g:560:3: () ( (lv_legend_1_0= 'legend' ) )? otherlv_2= 'Chart' otherlv_3= '{' (otherlv_4= 'chartType' ( (lv_chartType_5_0= ruleChartType ) ) )? (otherlv_6= 'xLabel' ( (lv_xLabel_7_0= ruleEString ) ) )? (otherlv_8= 'yLabel' ( (lv_yLabel_9_0= ruleEString ) ) )? (otherlv_10= 'title' ( (lv_title_11_0= ruleEString ) ) )? (otherlv_12= 'color' ( (lv_color_13_0= ruleEString ) ) )? (otherlv_14= 'variable' ( (lv_variable_15_0= ruleEString ) ) )? otherlv_16= '}'
            {
            // InternalMyDsl.g:560:3: ()
            // InternalMyDsl.g:561:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getChartAccess().getChartAction_0(),
            					current);
            			

            }

            // InternalMyDsl.g:567:3: ( (lv_legend_1_0= 'legend' ) )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==26) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalMyDsl.g:568:4: (lv_legend_1_0= 'legend' )
                    {
                    // InternalMyDsl.g:568:4: (lv_legend_1_0= 'legend' )
                    // InternalMyDsl.g:569:5: lv_legend_1_0= 'legend'
                    {
                    lv_legend_1_0=(Token)match(input,26,FOLLOW_21); 

                    					newLeafNode(lv_legend_1_0, grammarAccess.getChartAccess().getLegendLegendKeyword_1_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getChartRule());
                    					}
                    					setWithLastConsumed(current, "legend", lv_legend_1_0 != null, "legend");
                    				

                    }


                    }
                    break;

            }

            otherlv_2=(Token)match(input,27,FOLLOW_3); 

            			newLeafNode(otherlv_2, grammarAccess.getChartAccess().getChartKeyword_2());
            		
            otherlv_3=(Token)match(input,12,FOLLOW_22); 

            			newLeafNode(otherlv_3, grammarAccess.getChartAccess().getLeftCurlyBracketKeyword_3());
            		
            // InternalMyDsl.g:589:3: (otherlv_4= 'chartType' ( (lv_chartType_5_0= ruleChartType ) ) )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==28) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalMyDsl.g:590:4: otherlv_4= 'chartType' ( (lv_chartType_5_0= ruleChartType ) )
                    {
                    otherlv_4=(Token)match(input,28,FOLLOW_23); 

                    				newLeafNode(otherlv_4, grammarAccess.getChartAccess().getChartTypeKeyword_4_0());
                    			
                    // InternalMyDsl.g:594:4: ( (lv_chartType_5_0= ruleChartType ) )
                    // InternalMyDsl.g:595:5: (lv_chartType_5_0= ruleChartType )
                    {
                    // InternalMyDsl.g:595:5: (lv_chartType_5_0= ruleChartType )
                    // InternalMyDsl.g:596:6: lv_chartType_5_0= ruleChartType
                    {

                    						newCompositeNode(grammarAccess.getChartAccess().getChartTypeChartTypeEnumRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_24);
                    lv_chartType_5_0=ruleChartType();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getChartRule());
                    						}
                    						set(
                    							current,
                    							"chartType",
                    							lv_chartType_5_0,
                    							"org.xtext.example.mydsl3.MyDsl.ChartType");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyDsl.g:614:3: (otherlv_6= 'xLabel' ( (lv_xLabel_7_0= ruleEString ) ) )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==29) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalMyDsl.g:615:4: otherlv_6= 'xLabel' ( (lv_xLabel_7_0= ruleEString ) )
                    {
                    otherlv_6=(Token)match(input,29,FOLLOW_5); 

                    				newLeafNode(otherlv_6, grammarAccess.getChartAccess().getXLabelKeyword_5_0());
                    			
                    // InternalMyDsl.g:619:4: ( (lv_xLabel_7_0= ruleEString ) )
                    // InternalMyDsl.g:620:5: (lv_xLabel_7_0= ruleEString )
                    {
                    // InternalMyDsl.g:620:5: (lv_xLabel_7_0= ruleEString )
                    // InternalMyDsl.g:621:6: lv_xLabel_7_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getChartAccess().getXLabelEStringParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_25);
                    lv_xLabel_7_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getChartRule());
                    						}
                    						set(
                    							current,
                    							"xLabel",
                    							lv_xLabel_7_0,
                    							"org.xtext.example.mydsl3.MyDsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyDsl.g:639:3: (otherlv_8= 'yLabel' ( (lv_yLabel_9_0= ruleEString ) ) )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==30) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalMyDsl.g:640:4: otherlv_8= 'yLabel' ( (lv_yLabel_9_0= ruleEString ) )
                    {
                    otherlv_8=(Token)match(input,30,FOLLOW_5); 

                    				newLeafNode(otherlv_8, grammarAccess.getChartAccess().getYLabelKeyword_6_0());
                    			
                    // InternalMyDsl.g:644:4: ( (lv_yLabel_9_0= ruleEString ) )
                    // InternalMyDsl.g:645:5: (lv_yLabel_9_0= ruleEString )
                    {
                    // InternalMyDsl.g:645:5: (lv_yLabel_9_0= ruleEString )
                    // InternalMyDsl.g:646:6: lv_yLabel_9_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getChartAccess().getYLabelEStringParserRuleCall_6_1_0());
                    					
                    pushFollow(FOLLOW_26);
                    lv_yLabel_9_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getChartRule());
                    						}
                    						set(
                    							current,
                    							"yLabel",
                    							lv_yLabel_9_0,
                    							"org.xtext.example.mydsl3.MyDsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyDsl.g:664:3: (otherlv_10= 'title' ( (lv_title_11_0= ruleEString ) ) )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==31) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalMyDsl.g:665:4: otherlv_10= 'title' ( (lv_title_11_0= ruleEString ) )
                    {
                    otherlv_10=(Token)match(input,31,FOLLOW_5); 

                    				newLeafNode(otherlv_10, grammarAccess.getChartAccess().getTitleKeyword_7_0());
                    			
                    // InternalMyDsl.g:669:4: ( (lv_title_11_0= ruleEString ) )
                    // InternalMyDsl.g:670:5: (lv_title_11_0= ruleEString )
                    {
                    // InternalMyDsl.g:670:5: (lv_title_11_0= ruleEString )
                    // InternalMyDsl.g:671:6: lv_title_11_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getChartAccess().getTitleEStringParserRuleCall_7_1_0());
                    					
                    pushFollow(FOLLOW_27);
                    lv_title_11_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getChartRule());
                    						}
                    						set(
                    							current,
                    							"title",
                    							lv_title_11_0,
                    							"org.xtext.example.mydsl3.MyDsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyDsl.g:689:3: (otherlv_12= 'color' ( (lv_color_13_0= ruleEString ) ) )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==32) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalMyDsl.g:690:4: otherlv_12= 'color' ( (lv_color_13_0= ruleEString ) )
                    {
                    otherlv_12=(Token)match(input,32,FOLLOW_5); 

                    				newLeafNode(otherlv_12, grammarAccess.getChartAccess().getColorKeyword_8_0());
                    			
                    // InternalMyDsl.g:694:4: ( (lv_color_13_0= ruleEString ) )
                    // InternalMyDsl.g:695:5: (lv_color_13_0= ruleEString )
                    {
                    // InternalMyDsl.g:695:5: (lv_color_13_0= ruleEString )
                    // InternalMyDsl.g:696:6: lv_color_13_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getChartAccess().getColorEStringParserRuleCall_8_1_0());
                    					
                    pushFollow(FOLLOW_28);
                    lv_color_13_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getChartRule());
                    						}
                    						set(
                    							current,
                    							"color",
                    							lv_color_13_0,
                    							"org.xtext.example.mydsl3.MyDsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyDsl.g:714:3: (otherlv_14= 'variable' ( (lv_variable_15_0= ruleEString ) ) )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==33) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // InternalMyDsl.g:715:4: otherlv_14= 'variable' ( (lv_variable_15_0= ruleEString ) )
                    {
                    otherlv_14=(Token)match(input,33,FOLLOW_5); 

                    				newLeafNode(otherlv_14, grammarAccess.getChartAccess().getVariableKeyword_9_0());
                    			
                    // InternalMyDsl.g:719:4: ( (lv_variable_15_0= ruleEString ) )
                    // InternalMyDsl.g:720:5: (lv_variable_15_0= ruleEString )
                    {
                    // InternalMyDsl.g:720:5: (lv_variable_15_0= ruleEString )
                    // InternalMyDsl.g:721:6: lv_variable_15_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getChartAccess().getVariableEStringParserRuleCall_9_1_0());
                    					
                    pushFollow(FOLLOW_13);
                    lv_variable_15_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getChartRule());
                    						}
                    						set(
                    							current,
                    							"variable",
                    							lv_variable_15_0,
                    							"org.xtext.example.mydsl3.MyDsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_16=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_16, grammarAccess.getChartAccess().getRightCurlyBracketKeyword_10());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleChart"


    // $ANTLR start "entryRuleEInt"
    // InternalMyDsl.g:747:1: entryRuleEInt returns [String current=null] : iv_ruleEInt= ruleEInt EOF ;
    public final String entryRuleEInt() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEInt = null;


        try {
            // InternalMyDsl.g:747:44: (iv_ruleEInt= ruleEInt EOF )
            // InternalMyDsl.g:748:2: iv_ruleEInt= ruleEInt EOF
            {
             newCompositeNode(grammarAccess.getEIntRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEInt=ruleEInt();

            state._fsp--;

             current =iv_ruleEInt.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEInt"


    // $ANTLR start "ruleEInt"
    // InternalMyDsl.g:754:1: ruleEInt returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (kw= '-' )? this_INT_1= RULE_INT ) ;
    public final AntlrDatatypeRuleToken ruleEInt() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_INT_1=null;


        	enterRule();

        try {
            // InternalMyDsl.g:760:2: ( ( (kw= '-' )? this_INT_1= RULE_INT ) )
            // InternalMyDsl.g:761:2: ( (kw= '-' )? this_INT_1= RULE_INT )
            {
            // InternalMyDsl.g:761:2: ( (kw= '-' )? this_INT_1= RULE_INT )
            // InternalMyDsl.g:762:3: (kw= '-' )? this_INT_1= RULE_INT
            {
            // InternalMyDsl.g:762:3: (kw= '-' )?
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==34) ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // InternalMyDsl.g:763:4: kw= '-'
                    {
                    kw=(Token)match(input,34,FOLLOW_29); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getEIntAccess().getHyphenMinusKeyword_0());
                    			

                    }
                    break;

            }

            this_INT_1=(Token)match(input,RULE_INT,FOLLOW_2); 

            			current.merge(this_INT_1);
            		

            			newLeafNode(this_INT_1, grammarAccess.getEIntAccess().getINTTerminalRuleCall_1());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEInt"


    // $ANTLR start "ruleFilterCompOperator"
    // InternalMyDsl.g:780:1: ruleFilterCompOperator returns [Enumerator current=null] : ( (enumLiteral_0= 'EQUAL' ) | (enumLiteral_1= 'LESS' ) | (enumLiteral_2= 'LESS_OR_EQUAL' ) | (enumLiteral_3= 'GREATER_OR_EQUAL' ) | (enumLiteral_4= 'GREATER' ) ) ;
    public final Enumerator ruleFilterCompOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;


        	enterRule();

        try {
            // InternalMyDsl.g:786:2: ( ( (enumLiteral_0= 'EQUAL' ) | (enumLiteral_1= 'LESS' ) | (enumLiteral_2= 'LESS_OR_EQUAL' ) | (enumLiteral_3= 'GREATER_OR_EQUAL' ) | (enumLiteral_4= 'GREATER' ) ) )
            // InternalMyDsl.g:787:2: ( (enumLiteral_0= 'EQUAL' ) | (enumLiteral_1= 'LESS' ) | (enumLiteral_2= 'LESS_OR_EQUAL' ) | (enumLiteral_3= 'GREATER_OR_EQUAL' ) | (enumLiteral_4= 'GREATER' ) )
            {
            // InternalMyDsl.g:787:2: ( (enumLiteral_0= 'EQUAL' ) | (enumLiteral_1= 'LESS' ) | (enumLiteral_2= 'LESS_OR_EQUAL' ) | (enumLiteral_3= 'GREATER_OR_EQUAL' ) | (enumLiteral_4= 'GREATER' ) )
            int alt20=5;
            switch ( input.LA(1) ) {
            case 35:
                {
                alt20=1;
                }
                break;
            case 36:
                {
                alt20=2;
                }
                break;
            case 37:
                {
                alt20=3;
                }
                break;
            case 38:
                {
                alt20=4;
                }
                break;
            case 39:
                {
                alt20=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 20, 0, input);

                throw nvae;
            }

            switch (alt20) {
                case 1 :
                    // InternalMyDsl.g:788:3: (enumLiteral_0= 'EQUAL' )
                    {
                    // InternalMyDsl.g:788:3: (enumLiteral_0= 'EQUAL' )
                    // InternalMyDsl.g:789:4: enumLiteral_0= 'EQUAL'
                    {
                    enumLiteral_0=(Token)match(input,35,FOLLOW_2); 

                    				current = grammarAccess.getFilterCompOperatorAccess().getEQUALEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getFilterCompOperatorAccess().getEQUALEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:796:3: (enumLiteral_1= 'LESS' )
                    {
                    // InternalMyDsl.g:796:3: (enumLiteral_1= 'LESS' )
                    // InternalMyDsl.g:797:4: enumLiteral_1= 'LESS'
                    {
                    enumLiteral_1=(Token)match(input,36,FOLLOW_2); 

                    				current = grammarAccess.getFilterCompOperatorAccess().getLESSEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getFilterCompOperatorAccess().getLESSEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:804:3: (enumLiteral_2= 'LESS_OR_EQUAL' )
                    {
                    // InternalMyDsl.g:804:3: (enumLiteral_2= 'LESS_OR_EQUAL' )
                    // InternalMyDsl.g:805:4: enumLiteral_2= 'LESS_OR_EQUAL'
                    {
                    enumLiteral_2=(Token)match(input,37,FOLLOW_2); 

                    				current = grammarAccess.getFilterCompOperatorAccess().getLESS_OR_EQUALEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getFilterCompOperatorAccess().getLESS_OR_EQUALEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalMyDsl.g:812:3: (enumLiteral_3= 'GREATER_OR_EQUAL' )
                    {
                    // InternalMyDsl.g:812:3: (enumLiteral_3= 'GREATER_OR_EQUAL' )
                    // InternalMyDsl.g:813:4: enumLiteral_3= 'GREATER_OR_EQUAL'
                    {
                    enumLiteral_3=(Token)match(input,38,FOLLOW_2); 

                    				current = grammarAccess.getFilterCompOperatorAccess().getGREATER_OR_EQUALEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getFilterCompOperatorAccess().getGREATER_OR_EQUALEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalMyDsl.g:820:3: (enumLiteral_4= 'GREATER' )
                    {
                    // InternalMyDsl.g:820:3: (enumLiteral_4= 'GREATER' )
                    // InternalMyDsl.g:821:4: enumLiteral_4= 'GREATER'
                    {
                    enumLiteral_4=(Token)match(input,39,FOLLOW_2); 

                    				current = grammarAccess.getFilterCompOperatorAccess().getGREATEREnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getFilterCompOperatorAccess().getGREATEREnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFilterCompOperator"


    // $ANTLR start "ruleChartType"
    // InternalMyDsl.g:831:1: ruleChartType returns [Enumerator current=null] : ( (enumLiteral_0= 'BAR' ) | (enumLiteral_1= 'LINE' ) | (enumLiteral_2= 'SCATTER' ) ) ;
    public final Enumerator ruleChartType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;


        	enterRule();

        try {
            // InternalMyDsl.g:837:2: ( ( (enumLiteral_0= 'BAR' ) | (enumLiteral_1= 'LINE' ) | (enumLiteral_2= 'SCATTER' ) ) )
            // InternalMyDsl.g:838:2: ( (enumLiteral_0= 'BAR' ) | (enumLiteral_1= 'LINE' ) | (enumLiteral_2= 'SCATTER' ) )
            {
            // InternalMyDsl.g:838:2: ( (enumLiteral_0= 'BAR' ) | (enumLiteral_1= 'LINE' ) | (enumLiteral_2= 'SCATTER' ) )
            int alt21=3;
            switch ( input.LA(1) ) {
            case 40:
                {
                alt21=1;
                }
                break;
            case 41:
                {
                alt21=2;
                }
                break;
            case 42:
                {
                alt21=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 21, 0, input);

                throw nvae;
            }

            switch (alt21) {
                case 1 :
                    // InternalMyDsl.g:839:3: (enumLiteral_0= 'BAR' )
                    {
                    // InternalMyDsl.g:839:3: (enumLiteral_0= 'BAR' )
                    // InternalMyDsl.g:840:4: enumLiteral_0= 'BAR'
                    {
                    enumLiteral_0=(Token)match(input,40,FOLLOW_2); 

                    				current = grammarAccess.getChartTypeAccess().getBAREnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getChartTypeAccess().getBAREnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:847:3: (enumLiteral_1= 'LINE' )
                    {
                    // InternalMyDsl.g:847:3: (enumLiteral_1= 'LINE' )
                    // InternalMyDsl.g:848:4: enumLiteral_1= 'LINE'
                    {
                    enumLiteral_1=(Token)match(input,41,FOLLOW_2); 

                    				current = grammarAccess.getChartTypeAccess().getLINEEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getChartTypeAccess().getLINEEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:855:3: (enumLiteral_2= 'SCATTER' )
                    {
                    // InternalMyDsl.g:855:3: (enumLiteral_2= 'SCATTER' )
                    // InternalMyDsl.g:856:4: enumLiteral_2= 'SCATTER'
                    {
                    enumLiteral_2=(Token)match(input,42,FOLLOW_2); 

                    				current = grammarAccess.getChartTypeAccess().getSCATTEREnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getChartTypeAccess().getSCATTEREnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleChartType"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000006000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000018000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000060000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x000000000C000000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000310000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000210000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000400000040L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000003810000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000003010000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x000000F800000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000002010000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x00000003F0010000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000070000000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x00000003E0010000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x00000003C0010000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000380010000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000300010000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000200010000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000000000000040L});

}