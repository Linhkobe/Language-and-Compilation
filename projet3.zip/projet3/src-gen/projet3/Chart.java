/**
 */
package projet3;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Chart</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link projet3.Chart#getChartType <em>Chart Type</em>}</li>
 *   <li>{@link projet3.Chart#getXLabel <em>XLabel</em>}</li>
 *   <li>{@link projet3.Chart#getYLabel <em>YLabel</em>}</li>
 *   <li>{@link projet3.Chart#getTitle <em>Title</em>}</li>
 *   <li>{@link projet3.Chart#getColor <em>Color</em>}</li>
 *   <li>{@link projet3.Chart#getVariable <em>Variable</em>}</li>
 *   <li>{@link projet3.Chart#isLegend <em>Legend</em>}</li>
 * </ul>
 *
 * @see projet3.Projet3Package#getChart()
 * @model
 * @generated
 */
public interface Chart extends EObject {
	/**
	 * Returns the value of the '<em><b>Chart Type</b></em>' attribute.
	 * The literals are from the enumeration {@link projet3.ChartType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Chart Type</em>' attribute.
	 * @see projet3.ChartType
	 * @see #setChartType(ChartType)
	 * @see projet3.Projet3Package#getChart_ChartType()
	 * @model
	 * @generated
	 */
	ChartType getChartType();

	/**
	 * Sets the value of the '{@link projet3.Chart#getChartType <em>Chart Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Chart Type</em>' attribute.
	 * @see projet3.ChartType
	 * @see #getChartType()
	 * @generated
	 */
	void setChartType(ChartType value);

	/**
	 * Returns the value of the '<em><b>XLabel</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>XLabel</em>' attribute.
	 * @see #setXLabel(String)
	 * @see projet3.Projet3Package#getChart_XLabel()
	 * @model
	 * @generated
	 */
	String getXLabel();

	/**
	 * Sets the value of the '{@link projet3.Chart#getXLabel <em>XLabel</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>XLabel</em>' attribute.
	 * @see #getXLabel()
	 * @generated
	 */
	void setXLabel(String value);

	/**
	 * Returns the value of the '<em><b>YLabel</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>YLabel</em>' attribute.
	 * @see #setYLabel(String)
	 * @see projet3.Projet3Package#getChart_YLabel()
	 * @model
	 * @generated
	 */
	String getYLabel();

	/**
	 * Sets the value of the '{@link projet3.Chart#getYLabel <em>YLabel</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>YLabel</em>' attribute.
	 * @see #getYLabel()
	 * @generated
	 */
	void setYLabel(String value);

	/**
	 * Returns the value of the '<em><b>Title</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Title</em>' attribute.
	 * @see #setTitle(String)
	 * @see projet3.Projet3Package#getChart_Title()
	 * @model
	 * @generated
	 */
	String getTitle();

	/**
	 * Sets the value of the '{@link projet3.Chart#getTitle <em>Title</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Title</em>' attribute.
	 * @see #getTitle()
	 * @generated
	 */
	void setTitle(String value);

	/**
	 * Returns the value of the '<em><b>Color</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Color</em>' attribute.
	 * @see #setColor(String)
	 * @see projet3.Projet3Package#getChart_Color()
	 * @model
	 * @generated
	 */
	String getColor();

	/**
	 * Sets the value of the '{@link projet3.Chart#getColor <em>Color</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Color</em>' attribute.
	 * @see #getColor()
	 * @generated
	 */
	void setColor(String value);

	/**
	 * Returns the value of the '<em><b>Variable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Variable</em>' attribute.
	 * @see #setVariable(String)
	 * @see projet3.Projet3Package#getChart_Variable()
	 * @model
	 * @generated
	 */
	String getVariable();

	/**
	 * Sets the value of the '{@link projet3.Chart#getVariable <em>Variable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Variable</em>' attribute.
	 * @see #getVariable()
	 * @generated
	 */
	void setVariable(String value);

	/**
	 * Returns the value of the '<em><b>Legend</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Legend</em>' attribute.
	 * @see #setLegend(boolean)
	 * @see projet3.Projet3Package#getChart_Legend()
	 * @model
	 * @generated
	 */
	boolean isLegend();

	/**
	 * Sets the value of the '{@link projet3.Chart#isLegend <em>Legend</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Legend</em>' attribute.
	 * @see #isLegend()
	 * @generated
	 */
	void setLegend(boolean value);

} // Chart
