/**
 */
package projet3;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Csv Extract</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link projet3.CsvExtract#getNameFile <em>Name File</em>}</li>
 *   <li>{@link projet3.CsvExtract#getColumn <em>Column</em>}</li>
 *   <li>{@link projet3.CsvExtract#getFilter <em>Filter</em>}</li>
 *   <li>{@link projet3.CsvExtract#getChart <em>Chart</em>}</li>
 * </ul>
 *
 * @see projet3.Projet3Package#getCsvExtract()
 * @model
 * @generated
 */
public interface CsvExtract extends EObject {
	/**
	 * Returns the value of the '<em><b>Name File</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name File</em>' attribute.
	 * @see #setNameFile(String)
	 * @see projet3.Projet3Package#getCsvExtract_NameFile()
	 * @model
	 * @generated
	 */
	String getNameFile();

	/**
	 * Sets the value of the '{@link projet3.CsvExtract#getNameFile <em>Name File</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name File</em>' attribute.
	 * @see #getNameFile()
	 * @generated
	 */
	void setNameFile(String value);

	/**
	 * Returns the value of the '<em><b>Column</b></em>' containment reference list.
	 * The list contents are of type {@link projet3.Column}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Column</em>' containment reference list.
	 * @see projet3.Projet3Package#getCsvExtract_Column()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Column> getColumn();

	/**
	 * Returns the value of the '<em><b>Filter</b></em>' containment reference list.
	 * The list contents are of type {@link projet3.Filter}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Filter</em>' containment reference list.
	 * @see projet3.Projet3Package#getCsvExtract_Filter()
	 * @model containment="true"
	 * @generated
	 */
	EList<Filter> getFilter();

	/**
	 * Returns the value of the '<em><b>Chart</b></em>' containment reference list.
	 * The list contents are of type {@link projet3.Chart}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Chart</em>' containment reference list.
	 * @see projet3.Projet3Package#getCsvExtract_Chart()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Chart> getChart();

} // CsvExtract
