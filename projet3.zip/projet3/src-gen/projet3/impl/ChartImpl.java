/**
 */
package projet3.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import projet3.Chart;
import projet3.ChartType;
import projet3.Projet3Package;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Chart</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link projet3.impl.ChartImpl#getChartType <em>Chart Type</em>}</li>
 *   <li>{@link projet3.impl.ChartImpl#getXLabel <em>XLabel</em>}</li>
 *   <li>{@link projet3.impl.ChartImpl#getYLabel <em>YLabel</em>}</li>
 *   <li>{@link projet3.impl.ChartImpl#getTitle <em>Title</em>}</li>
 *   <li>{@link projet3.impl.ChartImpl#getColor <em>Color</em>}</li>
 *   <li>{@link projet3.impl.ChartImpl#getVariable <em>Variable</em>}</li>
 *   <li>{@link projet3.impl.ChartImpl#isLegend <em>Legend</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ChartImpl extends MinimalEObjectImpl.Container implements Chart {
	/**
	 * The default value of the '{@link #getChartType() <em>Chart Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getChartType()
	 * @generated
	 * @ordered
	 */
	protected static final ChartType CHART_TYPE_EDEFAULT = ChartType.BAR;

	/**
	 * The cached value of the '{@link #getChartType() <em>Chart Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getChartType()
	 * @generated
	 * @ordered
	 */
	protected ChartType chartType = CHART_TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getXLabel() <em>XLabel</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getXLabel()
	 * @generated
	 * @ordered
	 */
	protected static final String XLABEL_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getXLabel() <em>XLabel</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getXLabel()
	 * @generated
	 * @ordered
	 */
	protected String xLabel = XLABEL_EDEFAULT;

	/**
	 * The default value of the '{@link #getYLabel() <em>YLabel</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getYLabel()
	 * @generated
	 * @ordered
	 */
	protected static final String YLABEL_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getYLabel() <em>YLabel</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getYLabel()
	 * @generated
	 * @ordered
	 */
	protected String yLabel = YLABEL_EDEFAULT;

	/**
	 * The default value of the '{@link #getTitle() <em>Title</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTitle()
	 * @generated
	 * @ordered
	 */
	protected static final String TITLE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTitle() <em>Title</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTitle()
	 * @generated
	 * @ordered
	 */
	protected String title = TITLE_EDEFAULT;

	/**
	 * The default value of the '{@link #getColor() <em>Color</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getColor()
	 * @generated
	 * @ordered
	 */
	protected static final String COLOR_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getColor() <em>Color</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getColor()
	 * @generated
	 * @ordered
	 */
	protected String color = COLOR_EDEFAULT;

	/**
	 * The default value of the '{@link #getVariable() <em>Variable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVariable()
	 * @generated
	 * @ordered
	 */
	protected static final String VARIABLE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getVariable() <em>Variable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVariable()
	 * @generated
	 * @ordered
	 */
	protected String variable = VARIABLE_EDEFAULT;

	/**
	 * The default value of the '{@link #isLegend() <em>Legend</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isLegend()
	 * @generated
	 * @ordered
	 */
	protected static final boolean LEGEND_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isLegend() <em>Legend</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isLegend()
	 * @generated
	 * @ordered
	 */
	protected boolean legend = LEGEND_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ChartImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Projet3Package.Literals.CHART;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ChartType getChartType() {
		return chartType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setChartType(ChartType newChartType) {
		ChartType oldChartType = chartType;
		chartType = newChartType == null ? CHART_TYPE_EDEFAULT : newChartType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Projet3Package.CHART__CHART_TYPE, oldChartType,
					chartType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getXLabel() {
		return xLabel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setXLabel(String newXLabel) {
		String oldXLabel = xLabel;
		xLabel = newXLabel;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Projet3Package.CHART__XLABEL, oldXLabel, xLabel));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getYLabel() {
		return yLabel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setYLabel(String newYLabel) {
		String oldYLabel = yLabel;
		yLabel = newYLabel;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Projet3Package.CHART__YLABEL, oldYLabel, yLabel));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTitle(String newTitle) {
		String oldTitle = title;
		title = newTitle;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Projet3Package.CHART__TITLE, oldTitle, title));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getColor() {
		return color;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setColor(String newColor) {
		String oldColor = color;
		color = newColor;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Projet3Package.CHART__COLOR, oldColor, color));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getVariable() {
		return variable;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVariable(String newVariable) {
		String oldVariable = variable;
		variable = newVariable;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Projet3Package.CHART__VARIABLE, oldVariable,
					variable));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isLegend() {
		return legend;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLegend(boolean newLegend) {
		boolean oldLegend = legend;
		legend = newLegend;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Projet3Package.CHART__LEGEND, oldLegend, legend));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Projet3Package.CHART__CHART_TYPE:
			return getChartType();
		case Projet3Package.CHART__XLABEL:
			return getXLabel();
		case Projet3Package.CHART__YLABEL:
			return getYLabel();
		case Projet3Package.CHART__TITLE:
			return getTitle();
		case Projet3Package.CHART__COLOR:
			return getColor();
		case Projet3Package.CHART__VARIABLE:
			return getVariable();
		case Projet3Package.CHART__LEGEND:
			return isLegend();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Projet3Package.CHART__CHART_TYPE:
			setChartType((ChartType) newValue);
			return;
		case Projet3Package.CHART__XLABEL:
			setXLabel((String) newValue);
			return;
		case Projet3Package.CHART__YLABEL:
			setYLabel((String) newValue);
			return;
		case Projet3Package.CHART__TITLE:
			setTitle((String) newValue);
			return;
		case Projet3Package.CHART__COLOR:
			setColor((String) newValue);
			return;
		case Projet3Package.CHART__VARIABLE:
			setVariable((String) newValue);
			return;
		case Projet3Package.CHART__LEGEND:
			setLegend((Boolean) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Projet3Package.CHART__CHART_TYPE:
			setChartType(CHART_TYPE_EDEFAULT);
			return;
		case Projet3Package.CHART__XLABEL:
			setXLabel(XLABEL_EDEFAULT);
			return;
		case Projet3Package.CHART__YLABEL:
			setYLabel(YLABEL_EDEFAULT);
			return;
		case Projet3Package.CHART__TITLE:
			setTitle(TITLE_EDEFAULT);
			return;
		case Projet3Package.CHART__COLOR:
			setColor(COLOR_EDEFAULT);
			return;
		case Projet3Package.CHART__VARIABLE:
			setVariable(VARIABLE_EDEFAULT);
			return;
		case Projet3Package.CHART__LEGEND:
			setLegend(LEGEND_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Projet3Package.CHART__CHART_TYPE:
			return chartType != CHART_TYPE_EDEFAULT;
		case Projet3Package.CHART__XLABEL:
			return XLABEL_EDEFAULT == null ? xLabel != null : !XLABEL_EDEFAULT.equals(xLabel);
		case Projet3Package.CHART__YLABEL:
			return YLABEL_EDEFAULT == null ? yLabel != null : !YLABEL_EDEFAULT.equals(yLabel);
		case Projet3Package.CHART__TITLE:
			return TITLE_EDEFAULT == null ? title != null : !TITLE_EDEFAULT.equals(title);
		case Projet3Package.CHART__COLOR:
			return COLOR_EDEFAULT == null ? color != null : !COLOR_EDEFAULT.equals(color);
		case Projet3Package.CHART__VARIABLE:
			return VARIABLE_EDEFAULT == null ? variable != null : !VARIABLE_EDEFAULT.equals(variable);
		case Projet3Package.CHART__LEGEND:
			return legend != LEGEND_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (chartType: ");
		result.append(chartType);
		result.append(", xLabel: ");
		result.append(xLabel);
		result.append(", yLabel: ");
		result.append(yLabel);
		result.append(", title: ");
		result.append(title);
		result.append(", color: ");
		result.append(color);
		result.append(", variable: ");
		result.append(variable);
		result.append(", legend: ");
		result.append(legend);
		result.append(')');
		return result.toString();
	}

} //ChartImpl
