/**
 */
package projet3.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import projet3.Chart;
import projet3.Column;
import projet3.CsvExtract;
import projet3.Filter;
import projet3.Projet3Package;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Csv Extract</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link projet3.impl.CsvExtractImpl#getNameFile <em>Name File</em>}</li>
 *   <li>{@link projet3.impl.CsvExtractImpl#getColumn <em>Column</em>}</li>
 *   <li>{@link projet3.impl.CsvExtractImpl#getFilter <em>Filter</em>}</li>
 *   <li>{@link projet3.impl.CsvExtractImpl#getChart <em>Chart</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CsvExtractImpl extends MinimalEObjectImpl.Container implements CsvExtract {
	/**
	 * The default value of the '{@link #getNameFile() <em>Name File</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNameFile()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_FILE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNameFile() <em>Name File</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNameFile()
	 * @generated
	 * @ordered
	 */
	protected String nameFile = NAME_FILE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getColumn() <em>Column</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getColumn()
	 * @generated
	 * @ordered
	 */
	protected EList<Column> column;

	/**
	 * The cached value of the '{@link #getFilter() <em>Filter</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFilter()
	 * @generated
	 * @ordered
	 */
	protected EList<Filter> filter;

	/**
	 * The cached value of the '{@link #getChart() <em>Chart</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getChart()
	 * @generated
	 * @ordered
	 */
	protected EList<Chart> chart;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CsvExtractImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Projet3Package.Literals.CSV_EXTRACT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNameFile() {
		return nameFile;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNameFile(String newNameFile) {
		String oldNameFile = nameFile;
		nameFile = newNameFile;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Projet3Package.CSV_EXTRACT__NAME_FILE, oldNameFile,
					nameFile));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Column> getColumn() {
		if (column == null) {
			column = new EObjectContainmentEList<Column>(Column.class, this, Projet3Package.CSV_EXTRACT__COLUMN);
		}
		return column;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Filter> getFilter() {
		if (filter == null) {
			filter = new EObjectContainmentEList<Filter>(Filter.class, this, Projet3Package.CSV_EXTRACT__FILTER);
		}
		return filter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Chart> getChart() {
		if (chart == null) {
			chart = new EObjectContainmentEList<Chart>(Chart.class, this, Projet3Package.CSV_EXTRACT__CHART);
		}
		return chart;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Projet3Package.CSV_EXTRACT__COLUMN:
			return ((InternalEList<?>) getColumn()).basicRemove(otherEnd, msgs);
		case Projet3Package.CSV_EXTRACT__FILTER:
			return ((InternalEList<?>) getFilter()).basicRemove(otherEnd, msgs);
		case Projet3Package.CSV_EXTRACT__CHART:
			return ((InternalEList<?>) getChart()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Projet3Package.CSV_EXTRACT__NAME_FILE:
			return getNameFile();
		case Projet3Package.CSV_EXTRACT__COLUMN:
			return getColumn();
		case Projet3Package.CSV_EXTRACT__FILTER:
			return getFilter();
		case Projet3Package.CSV_EXTRACT__CHART:
			return getChart();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Projet3Package.CSV_EXTRACT__NAME_FILE:
			setNameFile((String) newValue);
			return;
		case Projet3Package.CSV_EXTRACT__COLUMN:
			getColumn().clear();
			getColumn().addAll((Collection<? extends Column>) newValue);
			return;
		case Projet3Package.CSV_EXTRACT__FILTER:
			getFilter().clear();
			getFilter().addAll((Collection<? extends Filter>) newValue);
			return;
		case Projet3Package.CSV_EXTRACT__CHART:
			getChart().clear();
			getChart().addAll((Collection<? extends Chart>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Projet3Package.CSV_EXTRACT__NAME_FILE:
			setNameFile(NAME_FILE_EDEFAULT);
			return;
		case Projet3Package.CSV_EXTRACT__COLUMN:
			getColumn().clear();
			return;
		case Projet3Package.CSV_EXTRACT__FILTER:
			getFilter().clear();
			return;
		case Projet3Package.CSV_EXTRACT__CHART:
			getChart().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Projet3Package.CSV_EXTRACT__NAME_FILE:
			return NAME_FILE_EDEFAULT == null ? nameFile != null : !NAME_FILE_EDEFAULT.equals(nameFile);
		case Projet3Package.CSV_EXTRACT__COLUMN:
			return column != null && !column.isEmpty();
		case Projet3Package.CSV_EXTRACT__FILTER:
			return filter != null && !filter.isEmpty();
		case Projet3Package.CSV_EXTRACT__CHART:
			return chart != null && !chart.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (nameFile: ");
		result.append(nameFile);
		result.append(')');
		return result.toString();
	}

} //CsvExtractImpl
